
> 💡 Agent Skill para encontrar os prompts que você quer com um clique 👉 [nano-banana-pro-prompts-recommend-skill](https://github.com/YouMind-OpenLab/nano-banana-pro-prompts-recommend-skill)
# 🚀 Prompts Incríveis do Nano Banana Pro

[![Awesome](https://awesome.re/badge.svg)](https://github.com/sindresorhus/awesome)
[![GitHub stars](https://img.shields.io/github/stars/YouMind-OpenLab/awesome-nano-banana-pro-prompts?style=social)](https://github.com/YouMind-OpenLab/awesome-nano-banana-pro-prompts)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![Update README](https://github.com/YouMind-OpenLab/awesome-nano-banana-pro-prompts/actions/workflows/update-readme.yml/badge.svg)](https://github.com/YouMind-OpenLab/awesome-nano-banana-pro-prompts/actions)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](docs/CONTRIBUTING.md)

> 🎨 Uma coleção curada de prompts criativos para o Nano Banana Pro do Google

> ⚠️ **Aviso de Direitos Autorais**: Todos os prompts são coletados da comunidade para fins educacionais. Se você acredita que algum conteúdo infringe seus direitos, por favor [abra uma issue](https://github.com/YouMind-OpenLab/awesome-nano-banana-pro-prompts/issues/new?template=bug-report.yml) e nós o removeremos prontamente.

---

[![English](https://img.shields.io/badge/English-Click%20to%20View-lightgrey)](README.md) [![简体中文](https://img.shields.io/badge/%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87-Click%20to%20View-lightgrey)](README_zh.md) [![繁體中文](https://img.shields.io/badge/%E7%B9%81%E9%AB%94%E4%B8%AD%E6%96%87-Click%20to%20View-lightgrey)](README_zh-TW.md) [![日本語](https://img.shields.io/badge/%E6%97%A5%E6%9C%AC%E8%AA%9E-Click%20to%20View-lightgrey)](README_ja-JP.md) [![한국어](https://img.shields.io/badge/%ED%95%9C%EA%B5%AD%EC%96%B4-Click%20to%20View-lightgrey)](README_ko-KR.md) [![ไทย](https://img.shields.io/badge/%E0%B9%84%E0%B8%97%E0%B8%A2-Click%20to%20View-lightgrey)](README_th-TH.md) [![Tiếng Việt](https://img.shields.io/badge/Ti%E1%BA%BFng%20Vi%E1%BB%87t-Click%20to%20View-lightgrey)](README_vi-VN.md) [![हिन्दी](https://img.shields.io/badge/%E0%A4%B9%E0%A4%BF%E0%A4%A8%E0%A5%8D%E0%A4%A6%E0%A5%80-Click%20to%20View-lightgrey)](README_hi-IN.md) [![Español](https://img.shields.io/badge/Espa%C3%B1ol-Click%20to%20View-lightgrey)](README_es-ES.md) [![Español (Latinoamérica)](https://img.shields.io/badge/Espa%C3%B1ol%20(Latinoam%C3%A9rica)-Click%20to%20View-lightgrey)](README_es-419.md) [![Deutsch](https://img.shields.io/badge/Deutsch-Click%20to%20View-lightgrey)](README_de-DE.md) [![Français](https://img.shields.io/badge/Fran%C3%A7ais-Click%20to%20View-lightgrey)](README_fr-FR.md) [![Italiano](https://img.shields.io/badge/Italiano-Click%20to%20View-lightgrey)](README_it-IT.md) [![Português (Brasil)](https://img.shields.io/badge/Portugu%C3%AAs%20(Brasil)-Current-brightgreen)](README_pt-BR.md) [![Português](https://img.shields.io/badge/Portugu%C3%AAs-Click%20to%20View-lightgrey)](README_pt-PT.md) [![Türkçe](https://img.shields.io/badge/T%C3%BCrk%C3%A7e-Click%20to%20View-lightgrey)](README_tr-TR.md)

---

## 🌐 Ver na galeria web

<div align="center">

![Cover](public/images/nano-banana-pro-prompts-cover-en.png)

</div>

**[👉 Navegar na galeria YouMind Nano Banana Pro](https://youmind.com/pt-BR/nano-banana-pro-prompts)**

Por que usar nossa galeria?

| Feature | GitHub README | Galeria youmind.com |
|---------|--------------|---------------------|
| 🎨 Layout visual | Lista linear | Bela grade Masonry |
| 🔍 Buscar | Apenas Ctrl+F | Busca de texto completo com filtros |
| 🤖 Geração IA com um clique | - | Geração IA com um clique |
| 📱 Móvel | Básico | Totalmente responsivo |
| 🏷️ Categorias | - | Navegação por categoria |


### 🏷️ Explorar por categoria

- **Casos de Uso**
  - [Perfil / Avatar](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=profile-avatar)
  - [Publicação em Mídias Sociais](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=social-media-post)
  - [Infográfico / Edu Visual](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=infographic-edu-visual)
  - [Miniatura do YouTube](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=youtube-thumbnail)
  - [Quadrinhos / Storyboard](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=comic-storyboard)
  - [Marketing de Produto](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=product-marketing)
  - [Imagem Principal de E-commerce](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=ecommerce-main-image)
  - [Ativo de Jogo](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=game-asset)
  - [Pôster / Flyer](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=poster-flyer)
  - [Design de Aplicativos / Web](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=app-web-design)
- **Estilo**
  - [Fotografia](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=photography)
  - [Cinematográfico / Imagem de Filme](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=cinematic-film-still)
  - [Anime / Mangá](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=anime-manga)
  - [Ilustração](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=illustration)
  - [Esboço / Arte Linear](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=sketch-line-art)
  - [Quadrinhos / Graphic Novel](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=comic-graphic-novel)
  - [Renderização 3D](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=3d-render)
  - [Chibi / Estilo Q](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=chibi-q-style)
  - [Isométrico](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=isometric)
  - [Pixel Art](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=pixel-art)
  - [Pintura a Óleo](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=oil-painting)
  - [Aquarela](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=watercolor)
  - [Tinta / Estilo Chinês](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=ink-chinese-style)
  - [Retrô / Vintage](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=retro-vintage)
  - [Cyberpunk / Ficção Científica](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=cyberpunk-sci-fi)
  - [Minimalismo](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=minimalism)
- **Corpo principal**
  - [Retrato / Selfie](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=portrait-selfie)
  - [Influenciador(a) / Modelo](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=influencer-model)
  - [Personagem](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=character)
  - [Grupo / Casal](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=group-couple)
  - [Produto](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=product)
  - [Alimentos / Bebidas](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=food-drink)
  - [Item de Moda](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=fashion-item)
  - [Animal / Criatura](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=animal-creature)
  - [Veículo](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=vehicle)
  - [Arquitetura / Interiores](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=architecture-interior)
  - [Paisagem / Natureza](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=landscape-nature)
  - [Paisagem Urbana / Rua](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=cityscape-street)
  - [Diagrama / Gráfico](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=diagram-chart)
  - [Texto / Tipografia](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=text-typography)
  - [Resumo / Contexto](https://youmind.com/pt-BR/nano-banana-pro-prompts?categories=abstract-background)

---

## 📖 Índice

- [🌐 Ver na galeria web](#-view-in-web-gallery)
- [🤔 O que é Nano Banana Pro?](#-what-is-nano-banana-pro)
- [📊 Estatísticas](#-statistics)
- [🔥 Prompts em destaque](#-featured-prompts)
- [📋 Todos os prompts](#-all-prompts)
- [🤝 Como contribuir](#-how-to-contribute)
- [📄 Licença](#-license)
- [🙏 Agradecimentos](#-acknowledgements)
- [⭐ Histórico de estrelas](#-star-history)

---

## 🤔 O que é Nano Banana Pro?

**Nano Banana Pro** é o mais recente modelo de IA multimodal do Google com os seguintes recursos:

- 🎯 **Compreensão multimodal** - Processa texto, imagens e vídeo
- 🎨 **Geração de alta qualidade** - De estilos fotorrealistas a artísticos
- ⚡ **Iteração rápida** - Edições e variações rápidas
- 🌈 **Estilos diversos** - De arte pixel a pinturas a óleo
- 🔧 **Controle preciso** - Composição e iluminação detalhadas
- 📐 **Cenas complexas** - Renderização multiobjeto, multipersonagem

📚 **Saiba mais**: [Nano Banana Pro: 10 casos reais](https://youmind.com/blog/nano-banana-pro-10-real-cases)

### 🚀 Integração com Raycast

Alguns prompts suportam **argumentos dinâmicos** usando a sintaxe [Raycast Snippets](https://raycast.com/help/snippets). Procure o emblema 🚀 Raycast Friendly!

**Exemplo:**
```
A quote card with "{argument name="quote" default="Stay hungry, stay foolish"}"
by {argument name="author" default="Steve Jobs"}
```

Quando usado no Raycast, você pode substituir dinamicamente os argumentos para iterações rápidas!

---

## 📊 Estatísticas

<div align="center">

| Métrica | Contagem |
|--------|-------|
| 📝 Total de prompts | **9434** |
| ⭐ Destaque | **9** |
| 🔄 Última atualização | **quarta-feira, 18 de fevereiro de 2026 às 05:19:07 UTC** |

</div>

---

## 🔥 Prompts em destaque

> ⭐ Selecionados à mão pela nossa equipe por qualidade e criatividade excepcionais

### No. 1: Cartão de citação amplo com retrato e personalização em chinês/inglês

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt para gerar um cartão de citação amplo com o retrato de uma pessoa famosa, com um fundo marrom, texto de citação em serifa dourado claro e layout onde o texto ocupa dois terços e a pessoa um terço. O texto da citação e o autor são parametrizados para reutilização.

#### 📝 Prompt

```
Um cartão de citação amplo com uma pessoa famosa, com um fundo marrom e uma fonte serifada dourada clara para a citação: “{argument name="famous_quote" default="Stay Hungry, Stay Foolish"}” e texto menor: “—{argument name="author" default="Steve Jobs"}.” Há uma grande e sutil aspa antes do texto. O retrato da pessoa está à esquerda, o texto à direita. O texto ocupa dois terços da imagem e o retrato um terço, com um leve efeito de transição gradiente no retrato.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763886933714_5zqn1e_G6QBjQHbgAE3Yt_.jpg" width="700" alt="Cartão de citação amplo com retrato e personalização em chinês/inglês - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763886938314_wbcfc7_G6QBiiracAInQ8z.jpg" width="700" alt="Cartão de citação amplo com retrato e personalização em chinês/inglês - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763886941069_1d9ace_G6QBii_acAIRxKd.jpg" width="700" alt="Cartão de citação amplo com retrato e personalização em chinês/inglês - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763886946388_nwahev_G6QBikOaEAAmYkO.jpg" width="700" alt="Cartão de citação amplo com retrato e personalização em chinês/inglês - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Nicolechan](https://x.com/stark_nico99)
- **Fonte:** [Twitter Post](https://x.com/stark_nico99/status/1991718646570426763)
- **Publicado:** 21 de novembro de 2025
- **Idiomas:** zh

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=151)**

---

### No. 2: Infográfico de produto em grade Bento de vidro líquido premium com 8 módulos

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)

#### 📖 Descrição

Crie um infográfico com layout de grade bento de 8 módulos, o usuário pode especificar qualquer nome de produto nas categorias Alimentos, Medicamentos, Tecnologia, etc., escolher o idioma, o estilo de fundo e o estilo da grade principal.

#### 📝 Prompt

```
Variável de Entrada: [inserir nome do produto]
Idioma: Português

Instrução do Sistema:
Crie uma imagem de um infográfico de produto em grade Bento de vidro líquido premium com 8 módulos (os cartões de 2 a 8 mostram apenas os títulos do texto).
1) Análise do Produto:
→ Identificar a cor natural dominante do produto → "cor principal"
→ Identificar a categoria: ALIMENTOS / MEDICAMENTOS / TECNOLOGIA
2) Paleta de Cores (derivada da cor principal):
→ Produto + detalhes: cor principal com saturação total
→ Ícones, bordas: cor principal suave (30-40% de saturação, nunca preto)
3) Estilo Visual:
→ Produto principal: fotografia real (autêntica, premium), versão em vidro 3D [escolha um]
→ Cartões: vidro líquido Apple (85-90% transparente) com bordas ultrafinas e sombra sutil para profundidade flutuante e reflexo da cor de fundo
→ O fundo permanece atrás dos cartões e com alto desfoque onde os cartões estão [escolha um]:
  - Etéreo: essência do produto, cáusticas leves, brilho abstrato
  - Macro: textura do produto em close-up, fortemente desfocada
  - Padrão: produto repetido suavemente com 10-15% de opacidade
  - Contexto: ambiente relevante, desfocado + dessaturado
→ Adicionar efeito de movimento sutil
→ Grade Bento assimétrica, paisagem 16:9
→ Cartão principal: 28-30% | Módulos de informação: 70-72%
4) Conteúdo do Módulo (8 Cartões):
M1 — Principal: Produto exibido como foto real / vidro 3D / interpretação estilizada (escolha um) em bela forma + rótulo com o nome do produto
M2 — Benefícios Principais: 4 benefícios únicos + ícones na cor principal
M3 — Como Usar: 4 métodos de uso + ícones
M4 — Métricas Chave: 5 pontos de dados EXATOS
Formato: [ícone] [Rótulo] [Valor em Negrito] [Unidade]
ALIMENTOS: Calorias: [X] kcal/100g, Carboidratos: [X]g (fibra [X]g, açúcar [X]g), Proteína: [X]g, [Vitamina Chave]: [X]mg ([X]% VD), [Mineral Chave]: [X]mg ([X]% VD)
MEDICAMENTOS: Ativo: [nome], Força: [X] mg, Início: [X] min, Duração: [X] hrs, Meia-vida: [X] hrs
TECNOLOGIA: Chip: [modelo], Bateria: [X] hrs, Peso: [X]g, [Especificação chave]: [valor], Conectividade: [protocolos]
M5 — Para Quem É: 4 grupos recomendados com ícones de visto verde | 3 grupos de cautela com ícones de aviso âmbar
M6 — Notas Importantes: 4 precauções + ícones de aviso
M7 — Referência Rápida:
→ ALIMENTOS: Índice Glicêmico + tags dietéticas com ícones
→ MEDICAMENTOS: Efeitos colaterais + gravidade com ícones
→ TECNOLOGIA: Compatibilidade + certificações com ícones
M8 — Você Sabia: 3 fatos (origem, ciência, estatística global) + ícones
Saída: 1 imagem, paisagem 16:9, infográfico de vidro líquido ultra-premium.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1768962051381_l9uih4_537980579-6f29d32a-c786-40c4-bd5a-79c640737496.png" width="700" alt="Infográfico de produto em grade Bento de vidro líquido premium com 8 módulos - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1768962076321_nu4c5q_537981099-d18d0e38-f7ac-4781-a5da-6d68e2380885.png" width="700" alt="Infográfico de produto em grade Bento de vidro líquido premium com 8 módulos - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Mansi Sanghani](https://x.com/MansiSanghani1)
- **Fonte:** [Twitter Post](https://x.com/MansiSanghani1/status/2013550795224961492)
- **Publicado:** 20 de janeiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=6847)**

---

### No. 3: Prompt de imagem de cabeçalho estilo desenho à mão a partir de foto

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)

#### 📖 Descrição

Prompt para uma imagem de cabeçalho em estilo desenhado à mão de uma pessoa apresentando o Nano Banana Pro

#### 📝 Prompt

```
Recrie completamente a pessoa carregada.
Faça dela uma imagem de cabeçalho para um artigo de nota onde essa pessoa apresenta o "Nano Banana Pro".
Proporção: horizontal 16:9.
Estilo e cores: estilo simples, desenhado à mão, itálico, com um gradiente azul e verde.
Texto do título: "Explicação aprofundada do novo AI 'Nano Banana Pro' do Google".
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763885651870_4szbai_G6VZiROagAAqsIh.jpg" width="700" alt="Prompt de imagem de cabeçalho estilo desenho à mão a partir de foto - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763885654537_qf6h9o_G6VZiRWaIAA_9x5.jpg" width="700" alt="Prompt de imagem de cabeçalho estilo desenho à mão a partir de foto - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [セミナー講師専門AIコンシェルジュ｜工藤 晶](https://x.com/akirakudo_ai)
- **Fonte:** [Twitter Post](https://x.com/akirakudo_ai/status/1992096860765561190)
- **Publicado:** 22 de novembro de 2025
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=498)**

---

### No. 4: Mapa em aquarela da Alemanha com estados rotulados

![Language-DE](https://img.shields.io/badge/Language-DE-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)

#### 📖 Descrição

Um prompt em alemão para gerar um mapa da Alemanha em estilo aquarela, onde todos os estados federais são rotulados com caneta esferográfica, útil para mapas educacionais ou em estilo infográfico.

#### 📝 Prompt

```
Gerar um mapa da Alemanha em estilo aquarela, no qual todos os estados federais são rotulados com caneta esferográfica.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763886061720_fzgqaq_G6RIeSZXgAA7cOf.jpg" width="700" alt="Mapa em aquarela da Alemanha com estados rotulados - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Florian Gallwitz](https://x.com/FlorianGallwitz)
- **Fonte:** [Twitter Post](https://x.com/FlorianGallwitz/status/1991796624646091091)
- **Publicado:** 21 de novembro de 2025
- **Idiomas:** de

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=380)**

---

### No. 5: Especial de Ano Novo: Quebra-Cabeça de Quatro Painéis para a Bênção de 2026

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)

#### 📖 Descrição

Um prompt detalhado de múltiplos painéis para Nano Banana Pro, criando uma colagem de fotos em grade 2x2 onde uma única personagem feminina, em quatro roupas e cenários diferentes, monta um quebra-cabeça que soletra '2026 New Year's Day Happy' no centro. O prompt especifica retenção precisa de características faciais, detalhes de vestuário, elementos de fundo e parâmetros fotográficos para um estilo de revista de moda.

#### 📝 Prompt

```
[Chave: Manter características faciais precisas, reter a estrutura facial original, a personagem na imagem deve ser completamente consistente com a imagem de referência carregada] Estúdio fotográfico de alta qualidade, foto em grade 2x2. Painel superior esquerdo (fundo azul-marinho): A personagem veste um vestido estilo uniforme azul-marinho, decorado com botões dourados, cachos vintage com uma boina azul e brincos de pérola. Ela segura uma enorme peça de quebra-cabeça (peça superior esquerda, com o número "20" nela) com as duas mãos, movendo-a em direção ao centro do quadro. Seus olhos estão focados na área central do quebra-cabeça, sua expressão é séria, com um leve sorriso. O fundo apresenta listras navais, uma âncora e o texto "Set Sail for the New Year". Painel superior direito (fundo rosa-cerejeira): A mesma mulher veste um vestido de renda rosa, um colar de pérolas, um penteado de princesa com um grampo de cabelo de rosa rosa e brincos de cristal. Ela segura a peça superior direita do quebra-cabeça (com o número "26" nela) com as duas mãos, movendo-a em direção ao centro para conectar com a peça superior esquerda. Seus olhos olham para a emenda do quebra-cabeça, sua expressão é focada e expectante, e seu corpo se inclina para frente. O fundo apresenta flores de cerejeira rosa, o texto "Beautiful Encounter", borboletas e pétalas. Painel inferior esquerdo (fundo verde-menta): A mesma mulher veste um vestido de algodão e linho verde-menta, em estilo artístico, com cabelos longos naturais, uma tiara verde e brincos de madeira. Ela segura a peça inferior esquerda do quebra-cabeça (com o texto "New Year's Day" nela) com as duas mãos, movendo-a para cima para conectar com a peça superior esquerda. Seus olhos olham para o quebra-cabeça, sua expressão é séria e sua boca está levemente franzida. O fundo apresenta plantas verdes, o texto "Hope Grows", novos brotos e folhas. Painel inferior direito (fundo amarelo-limão): A mesma mulher veste um vestido amarelo com estampa de girassol, tranças com laços amarelos. Ela empurra a última peça inferior direita do quebra-cabeça (com o texto "Happy" nela) para completar o quebra-cabeça. As quatro peças formam perfeitamente o padrão completo "2026 New Year's Day Happy" no centro do quadro. Ela inclina a cabeça para trás, olhando para o quebra-cabeça completo, seu rosto radiante com um sorriso vitorioso e alegre. O centro do quadro explode com luz dourada e confetes. O fundo apresenta um sol amarelo, o texto "Complete Success", rostos sorridentes e girassóis. As peças do quebra-cabeça convergem dos quatro cantos para o centro para formar uma imagem completa. Maquiagem clara, luz de anel brilhante, lente de 85mm, abertura f/1.8, composição de quatro painéis com interação de quebra-cabeça, estilo de revista de moda.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1767455034932_ivuvu0_G9V-MszakAEAIBw.jpg" width="700" alt="Especial de Ano Novo: Quebra-Cabeça de Quatro Painéis para a Bênção de 2026 - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [松果先森](https://x.com/songguoxiansen)
- **Fonte:** [Twitter Post](https://x.com/songguoxiansen/status/2005822648027091031)
- **Publicado:** 30 de dezembro de 2025
- **Idiomas:** zh

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=4031)**

---

### No. 6: Documento de Patente Vintage de uma Invenção

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt projetado para gerar uma imagem de um documento de patente vintage dos Estados Unidos do final do século XIX. Ele especifica detalhes como desenhos técnicos precisos, anotações manuscritas, textura de papel envelhecido, manchas de foxing, um selo em relevo e um selo de cera, tornando-o ideal para estéticas históricas ou de arquivo.

#### 📝 Prompt

```
Um documento de patente vintage para {argument name="invention" default="INVENTION"}, no estilo dos registros do Escritório de Patentes dos Estados Unidos do final do século XIX. A página apresenta desenhos técnicos precisos com legendas numeradas (Fig. 1, Fig. 2, Fig. 3) mostrando vistas frontal, lateral e explodida. Anotações manuscritas em tinta de caneta-tinteiro descrevem os mecanismos. O papel é de cor marfim envelhecido com manchas de foxing e suaves vincos de dobra. Um selo oficial em relevo e um carimbo de cera vermelha aparecem no canto. Um nome de inventor assinado à mão e a data aparecem na parte inferior. A imagem inteira parece um documento de arquivo recuperado — autoritário, histórico e ligeiramente misterioso.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1766940094520_1mg5pd_G8_m2ZVWEAAMG7y.jpg" width="700" alt="Documento de Patente Vintage de uma Invenção - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1766940095035_8t8iil_G8_mW4FWwAEwERE.jpg" width="700" alt="Documento de Patente Vintage de uma Invenção - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1766940095188_kt8ksq_G8_m_7hWoAAw19u.jpg" width="700" alt="Documento de Patente Vintage de uma Invenção - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1766940096864_fhv4oo_G8_nePrXUAAHvgn.jpg" width="700" alt="Documento de Patente Vintage de uma Invenção - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Alexandra Aisling](https://x.com/AllaAisling)
- **Fonte:** [Twitter Post](https://x.com/AllaAisling/status/2004212035333365763)
- **Publicado:** 25 de dezembro de 2025
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=3438)**

---

### No. 7: Resumo de notícias de IA em estilo de lousa

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)

#### 📖 Descrição

Um prompt em japonês para transformar conteúdo de notícias de IA em um diagrama de quadro-negro desenhado à mão, no estilo de professor, com explicações.

#### 📝 Prompt

```
Usando o conteúdo a seguir, resuma as notícias em um estilo de quadro-negro, com aparência de escrita à mão, e detalhe-as com diagramas e expressões fáceis de entender, como se um professor as tivesse escrito.
—-
Resultados da pesquisa do Grok
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763885620059_vzaj75_G6WfVvIbAAEgvYg.jpg" width="700" alt="Resumo de notícias de IA em estilo de lousa - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763885622901_pk1vka_G6P2CkracAINIfP.jpg" width="700" alt="Resumo de notícias de IA em estilo de lousa - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [ひでもん | AI開発@ニュース発信](https://x.com/okknews)
- **Fonte:** [Twitter Post](https://x.com/okknews/status/1992173611520868372)
- **Publicado:** 22 de novembro de 2025
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=509)**

---

### No. 8: Cena detalhada de quarto otaku com selfie no espelho

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)

#### 📖 Descrição

Um prompt Nano Banana bem detalhado descrevendo uma selfie feminina no espelho em um canto de computador otaku em tons de azul, com especificações completas para personagem, ambiente, iluminação, câmera e prompts negativos.

#### 📝 Prompt

```
### Cena
Selfie no espelho em um canto de computador estilo otaku, em tons de azul.

### Assunto
* Expressão de gênero: feminina
* Idade: cerca de 25 anos
* Etnia: asiática oriental
* Tipo de corpo: magra, com cintura definida; proporções corporais naturais
* Tom de pele: tom neutro claro
* Penteado:
    * Comprimento: cabelo até a cintura
    * Estilo: liso com pontas levemente cacheadas
    * Cor: castanho médio
* Pose:
    * Postura: em pé, em uma leve pose de contrapposto
    * Mão direita: segurando um smartphone na frente do rosto (identidade oculta)
    * Braço esquerdo: naturalmente pendurado ao lado do tronco
    * Tronco: corpo levemente inclinado para trás; cintura e abdômen expostos
* Roupa:
    * Parte de cima: cardigã cropped de malha azul claro, com os dois botões superiores fechados; um sutiã azul estilo francês levemente visível
    * Parte de baixo: shorts jeans ultracurtos, com um laço de fita de cetim azul em cada lado dos quadris
    * Meias: meias azuis e brancas listradas horizontais acima do joelho
    * Acessório: uma capinha de celular azul com um mascote fofo

### Ambiente
* Descrição: canto de computador do quarto visto através de um espelho de parede
* Mobiliário:
    * Mesa branca
    * Um monitor mostrando um papel de parede azul suave (sem texto legível)
    * Teclado mecânico com teclas brancas sobre um tapete de mesa azul
    * Mouse sobre um pequeno mouse pad azul
    * Gabinete do PC no lado direito com iluminação azul
    * Três figuras de anime sobre ou perto do gabinete do PC
    * Um pôster de um pagode na parede
    * Luminária de mesa em forma de gato com detalhes azuis
    * Um copo de água transparente
    * Uma planta alta e frondosa perto da janela (no lado esquerdo do quadro)
* Substituição de cor: substituir todos os elementos originalmente rosa (roupas e decoração do quarto) por tons de azul (azul bebê a azul celeste/azul pervinca).

### Iluminação
* Fonte de luz: luz do dia vinda de uma grande janela no lado esquerdo da câmera, através de cortinas transparentes
* Qualidade da luz: luz suave e difusa
* Balanço de branco (K): 5200

### Câmera
* Modo: câmera traseira do smartphone fotografando através do espelho (sem modo retrato/bokeh)
* Distância focal equivalente (mm): 26
* Distâncias (m):
    * Sujeito ao espelho: 0.6
    * Câmera ao espelho: 0.5
* Exposição:
    * Abertura (f): 1.8
    * ISO: 100
    * Velocidade do obturador (s): 0.01
    * Compensação de exposição (EV): -0.3
* Foco: foco no tronco e shorts na imagem do espelho
* Profundidade de campo: profundidade de campo natural de smartphone; fundo claramente visível sem desfoque artificial
* Composição:
    * Proporção da imagem: 1:1
    * Corte: do topo da cabeça até o meio da coxa; incluir a mesa, monitor, gabinete do PC e planta no quadro
    * Ângulo: ângulo ligeiramente alto do ponto de vista do espelho
    * Nota de composição: manter o assunto centralizado; para evitar distorção de borda de grande angular, fazer com que ela fique um pouco mais afastada e cortar para um quadrado depois.

### Prompts negativos
* Qualquer aparição de rosa/magenta em qualquer lugar
* Filtros de beleza/pele excessivamente suavizada; aparência de pele sem poros
* Anatomia exagerada ou distorcida
* NSFW, tecidos transparentes, problemas de vestuário
* Logotipos, nomes de marcas ou texto de interface de usuário legível
* Desfoque falso de modo retrato, sensação de CGI/ilustração
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763889946850_689z0h_G23i3sJW0AASGUw.jpg" width="700" alt="Cena detalhada de quarto otaku com selfie no espelho - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [宝玉](https://x.com/dotey)
- **Fonte:** [Twitter Post](https://x.com/dotey/status/1976485558319722711)
- **Publicado:** 10 de outubro de 2025
- **Idiomas:** zh

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=553)**

---

### No. 9: Reinterpretação em Ukiyo-e do período Edo de uma cena moderna

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt de imagem altamente estruturado para retratar uma cena moderna reimaginada como uma xilogravura Ukiyo-e japonesa do período Edo, com orientações detalhadas sobre tecnologia anacrônica, composição, textura e cor.

#### 📝 Prompt

```
Uma xilogravura Ukiyo-e japonesa do período Edo. A sensação geral é de uma colaboração surreal entre mestres como Hokusai e Hiroshige, reimaginando a tecnologia moderna através de uma lente antiga.

**A cena:** {argument name="modern scene" default="um movimentado cruzamento de Shibuya"}

**Lógica de transformação Edo:**
Os personagens vestem quimonos da era Edo, mas realizam ações modernas. Toda a tecnologia é transformada em equivalentes Edo surreais:
* Smartphones são pergaminhos de papel ilustrados e brilhantes, sendo lidos atentamente.
* Estações de metrô e trens são gigantescas carruagens de centopeia de madeira articuladas, movendo-se entre as multidões.
* Arranha-céus são reimaginados como pagodes de madeira infinitos e imponentes, alcançando nuvens dramáticas.
* Robôs e mechas aparecem como golens de xilogravura gigantes e blindados.

A composição utiliza uma perspectiva achatada com contornos de tinta grandes, ousados e esculpidos à mão. O fundo apresenta padrões de ondas Ukiyo-e altamente estilizados e nuvens dramáticas e rodopiantes, com um distante Monte Fuji visível no horizonte.

A imagem deve parecer uma impressão física, não uma pintura digital.
* Textura: forte textura de grão de madeira visível e fibras de papel ásperas em toda a peça.
* Imperfeições de impressão: sangramento de pigmento é evidente. Simule placas prensadas à mão com leve desalinhamento de cores para autenticidade.
* Paleta de cores: estritamente limitada a pigmentos minerais tradicionais, com uso dominante de azul da Prússia, vermelho vermelhão e ocre amarelo suave.
* Iluminação: iluminação suave, plana, sem sombras e sem gradientes digitais.

A proporção da imagem é de pôster vertical 3:4. Inclua caligrafia japonesa vertical descrevendo a cena e um selo de artista vermelho tradicional em um canto.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1764915832381_renotr_G7FuPlzbYAAsuo2.jpg" width="700" alt="Reinterpretação em Ukiyo-e do período Edo de uma cena moderna - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [VoxcatAI](https://x.com/VoxcatAI)
- **Fonte:** [Twitter Post](https://x.com/VoxcatAI/status/1995497350543110411)
- **Publicado:** 1 de dezembro de 2025
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=811)**

---

## 📋 Todos os prompts

> 📝 Ordenado por data de publicação (mais recente primeiro)

### No. 1: Perfil / Avatar - Retrato Fotorrealista em Close-Up (JSON)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Uma estrutura de prompt JSON mínima para gerar um retrato fotorrealista em close-up, especificando uma proporção de 9:16 e resolução 4K UHD.

#### 📝 Prompt

```
{
  "image_generation_specification": {
    "meta": {
      "type": "retrato em close-up fotorrealista",
      "aspect_ratio": "9:16",
      "target_resolution": "4K UHD"}}}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310085878_ck93mx_HBTtCrEX0AASLed.jpg" width="600" alt="Perfil / Avatar - Retrato Fotorrealista em Close-Up (JSON) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [degen_dev - d/acc](https://x.com/__degen_dev__)
- **Fonte:** [Twitter Post](https://x.com/__degen_dev__/status/2023502764655960343)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10249)**

---

### No. 2: Perfil / Avatar - Grade de Cabine de Fotos de 6 Painéis com Vestido Rosa e Rosa

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente estruturado para gerar uma grade 2x3 estilo cabine de fotos de uma mulher adulta em um vestido rosa, segurando uma rosa, especificando seis poses distintas, iluminação direta de flash na câmera e uma estética de filme vintage.

#### 📝 Prompt

```
{
  "generation_request": {
    "meta_data": {
      "task_type": "photobooth_film_flash_6panel_grid_no_text",
      "language": "en",
      "priority": "highest",
      "version": "v1.0_PHOTOBOOTH_PINK_DRESS_ROSE_6POSE"
    },
    "input": {
      "mode": "text_to_image",
      "notes": "Crie uma colagem estilo cabine de fotos 2x3 com a mesma mulher adulta e a mesma roupa em todos os seis painéis. Flash direto na câmera, visual de filme quente, expressões casuais e espontâneas. Sem texto, sem logotipos, sem marca d'água."
    },
    "output": {
      "aspect_ratio": "4:5",
      "resolution": "ultra_high",
      "num_images": 1,
      "layout": {
        "type": "grid",
        "rows": 3,
        "cols": 2,
        "gutter": "thin"
      },
      "sharpness": "slightly_soft_film",
      "grain": "true_film_grain"
    },
    "scene": {
      "environment": "fundo de parede interna simples em tom bege/creme quente, minimalista, sensação de cabine de fotos",
      "style": "estética de tira de filme vintage de cabine de fotos, editorial casual do início dos anos 2000"
    },
    "subject": {
      "person": "mulher adulta",
      "hair": "cabelo preto na altura dos ombros com volume suave, movimento lúdico ligeiramente bagunçado",
      "makeup": "maquiagem natural mínima, pele fresca, batom suave",
      "wardrobe": {
        "dress": "{argument name=\"dress color and style\" default=\"vestido de verão justo rosa com pequeno padrão espalhado vermelho/rosa, alças finas, decote quadrado\"}"
      },
      "prop": "{argument name=\"prop\" default=\"uma rosa rosa pálida de haste longa com folhas verdes\"}"
    },
    "poses": {
      "panel_1": "em pé, sorriso brincalhão, segurando a rosa horizontalmente perto do rosto, olhos fechados, cabeça ligeiramente inclinada",
      "panel_2": "em pé, rosa perto do nariz como se estivesse cheirando, sorriso suave, olhos semicerrados, ombro relaxado",
      "panel_3": "em pé, estendendo a rosa em direção à câmera (ligeiro encurtamento), sorriso gentil, contato visual direto",
      "panel_4": "rindo espontaneamente, corpo ligeiramente inclinado para frente, segurando a rosa perto do peito, desfoque de movimento no cabelo",
      "panel_5": "pose de risada tímida, uma mão cobrindo a boca levemente, rosa segurada na outra mão, cabeça um pouco abaixada",
      "panel_6": "pose calma, rosa atrás da orelha como um acessório de cabelo, sorriso sutil, olhando para a câmera"
    },
    "lighting": {
      "style": "flash direto na câmera",
      "effect": "ligeira halação, realces brilhantes no rosto, sombra suave atrás do sujeito na parede",
      "white_balance": "quente"
    },
    "camera": {
      "look": "instantâneo de filme 35mm",
      "lens": "50mm",
      "depth_of_field": "moderada, rosto nítido em cada painel",
      "imperfections": "pequena suavidade de filme, textura natural da pele, sem retoques pesados"
    },
    "negative_prompt": "texto, tipografia, logotipo, marca d'água, pessoas extras, membros extras, dedos extras, mãos deformadas, rosto distorcido, filtro de beleza, pele plástica excessivamente lisa, HDR, aparência digital ultra nítida, desenho animado"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310080437_v1cpap_HBTfsxiaEAAZXC2.jpg" width="600" alt="Perfil / Avatar - Grade de Cabine de Fotos de 6 Painéis com Vestido Rosa e Rosa - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Özge Döner](https://x.com/astronomerozge1)
- **Fonte:** [Twitter Post](https://x.com/astronomerozge1/status/2023488620053569800)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10237)**

---

### No. 3: Perfil / Avatar - Grade de Troca de Identidade Preto e Branco (4x4)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente técnico e estruturado para uma tarefa de troca de identidade de imagem para imagem, gerando uma grade 4x4 em preto e branco. O prompt instrui o modelo a substituir a identidade na imagem da grade de referência por uma nova identidade alvo, preservando estritamente as poses, expressões, layout e vestuário (terno e gravata) originais.

#### 📝 Prompt

```
{
  "generation_request": {
    "meta_data": {
      "task_type": "bw_male_expression_grid_identity_swap",
      "language": "pt",
      "priority": "highest",
      "version": "v1.0_BW_MALE_GRID_KEEP_POSES_SWAP_IDENTITY"
    },
    "input": {
      "mode": "image_to_image",
      "reference_image_usage": "very_high",
      "preserve_identity": true,
      "preserve_facial_features": true,
      "preserve_hairstyle": true,
      "notes": "ÂNCORA DE ESTRUTURA PRIMÁRIA: use a imagem de grade 4x4 masculina carregada (fotocabine de terno). Mantenha o layout 4x4 exato, corte, espaçamento, poses, gestos, posicionamento das mãos e enquadramento em cada painel. ÂNCORA DE IDENTIDADE PRIMÁRIA: use a foto de referência carregada do homem adulto alvo. Substitua o homem em TODOS os painéis pela identidade de referência, preservando a pose original e a intensidade da expressão. Mantenha o estilo de terno e gravata e o fundo de estúdio limpo. Mantenha a identidade consistente em todos os 16 painéis."
    },
    "output": {
      "aspect_ratio": "1:1",
      "resolution": "ultra_high",
      "num_images": 1,
      "layout": {
        "type": "grid",
        "rows": 4,
        "cols": 4,
        "gutter": "thin",
        "panel_consistency": "very_high"
      },
      "sharpness": "crisp_studio",
      "grain": "subtle_analog_bw"
    },
    "scene": {
      "environment": "fundo de estúdio branco limpo",
      "lighting": {
        "style": "estúdio high-key",
        "key_light": "softbox frontal",
        "fill": "preenchimento balanceado",
        "avoid": "sombras cinematográficas dramáticas"
      },
      "camera": {
        "lens": "50mm",
        "framing": "do meio do peito à cabeça (varia por painel, mas mantenha o mesmo da imagem de estrutura)",
        "focus": "olhos nítidos"
      }
    },
    "subject": {
      "type": "homem adulto",
      "wardrobe": "terno preto, camisa branca, gravata preta (igual à imagem de estrutura), sem logotipos",
      "grooming": "combine o penteado de referência o mais próximo possível, mantendo o visual geral consistente",
      "anatomy_rules": "mãos realistas, dedos corretos, sem distorções"
    },
    "style": {
      "color": "preto e branco puro",
      "contrast": "médio-alto",
      "background": "manter idêntico à imagem de estrutura",
      "finish": "aparência de impressão de estúdio limpa"
    },
    "quality_control": {
      "identity_lock": "strict",
      "hands_priority": "very_high",
      "avoid": [
        "dedos extras",
        "dedos faltando",
        "mãos deformadas",
        "rosto deformado",
        "olhos irregulares",
        "boca derretida",
        "desvio de identidade entre os painéis",
        "texto",
        "marca d'água",
        "logotipo"
      ]
    },
    "negative_prompt": [
      "cor",
      "sépia",
      "iluminação cinematográfica",
      "desfoque",
      "baixa resolução",
      "anatomia distorcida",
      "pele plástica",
      "incompatibilidade facial"
    ]
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310075280_d3e99f_HBTFjkHXgAAV-SW.jpg" width="600" alt="Perfil / Avatar - Grade de Troca de Identidade Preto e Branco (4x4) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Özge Döner](https://x.com/astronomerozge1)
- **Fonte:** [Twitter Post](https://x.com/astronomerozge1/status/2023459364082733500)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10230)**

---

### No. 4: Perfil / Avatar - Retrato Estético para Foto de Passaporte

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt simples, mas eficaz, para gerar um retrato de frente para cartão de identificação com uma estética de foto de passaporte. Ele especifica um close-up da cabeça, expressão neutra, granulação sutil de filme, iluminação plana superior e textura de pele realista contra um fundo liso.

#### 📝 Prompt

```
Retrato de documento de identificação frontal, estética de foto de passaporte, close-up de rosto, expressão neutra, granulação sutil de filme, iluminação plana superior, textura de digitalização de documento, pele realista, fundo liso.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310085417_gaes5q_HBTD6BUXAAA6CR2.jpg" width="600" alt="Perfil / Avatar - Retrato Estético para Foto de Passaporte - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [degen_dev - d/acc](https://x.com/__degen_dev__)
- **Fonte:** [Twitter Post](https://x.com/__degen_dev__/status/2023457536981037418)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10248)**

---

### No. 5: Perfil / Avatar - Simulação de Selfie no Espelho de Ana de Armas

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt extremamente detalhado e estruturado, projetado para simular uma selfie de espelho de alta fidelidade de Ana de Armas em um quarto ensolarado, especificando detalhes biométricos, guarda-roupa, pose, física da cena (integridade do reflexo) e especificações técnicas da câmera para uma geração ultrarrealista.

#### 📝 Prompt

```
{
  "subject": {
    "identity": {
      "biometric_reference": "{argument name=\"identity\" default=\"Ana de Armas\"}",
      "facial_geometry": "Estrutura craniana de alta fidelidade; maçãs do rosto proeminentes, contorno suave da mandíbula, profundidade específica do filtro e borda do vermelhão do lábio superior característicos da referência. Textura da pele em nível forense com efélides sutis.",
      "dentition": "Alinhamento dental natural; leves bordas incisais visíveis dos incisivos centrais superiores através de uma postura labial suavemente entreaberta.",
      "ocular_details": "Padrões de íris verde-avelã altamente detalhados com intrincados sulcos radiais e uma borda pupilar escura; vascularização escleral realista e reflexos especulares de olhos úmidos."
    },
    "wardrobe": {
      "top": "Top cropped branco ultrafino semitransparente; trama de algodão-jersey leve com textura de microfibra visível; barra de corte cru. Cor: #FFFFFF.",
      "bottom": "Shorts lounge de cintura alta e caimento relaxado em algodão off-white; cós elástico com leve franzido do tecido. Cor: #F9F9F9."
    },
    "pose_action": {
      "body_position": "Sentada no chão com as pernas cruzadas; braço esquerdo apoiado sobre os joelhos; braço direito levantado em um ângulo de 45 graus segurando um smartphone para uma selfie no espelho.",
      "hand_anatomy": "Aderência perfeita de cinco dedos no dispositivo; articulação realista dos nós dos dedos e lúnula das unhas; sem dedos fundidos.",
      "hair_styling": "Coque alto bagunçado preso com dois palitos de cabelo de madeira (kanzashi); mechas loiro-morenas soltas emoldurando o rosto com efeitos de dispersão subsuperficial em fios individuais."
    },
    "scene": {
      "environment": "Interior de quarto ensolarado visto através de um espelho vertical; textura de carpete felpudo de pelo alto bege; o fundo inclui uma estrutura de cama de madeira minimalista com lençóis brancos amassados e uma cadeira de penteadeira branca.",
      "reflection_integrity_rules": "Lógica de reflexão com traçado de raios; a superfície do espelho inclui partículas de poeira realistas e rastros de luz verticais; o olhar do sujeito é direcionado para a tela do telefone ou para o plano focal do espelho.",
      "atmosphere": "Iluminação volumétrica com partículas de poeira suspensas visíveis; ambiente matinal nebuloso e quente."
    },
    "lighting": {
      "source": "Luz solar dura e direcional da hora dourada entrando por uma janela lateral direita em um ângulo baixo; temperatura de cor #FFD27F.",
      "surface_physics": "Forte iluminação de contorno na silhueta do sujeito; claro-escuro de alto contraste no chão; dispersão subsuperficial nas orelhas e na pele; reflexos especulares no vidro do telefone.",
      "camera": {
        "technical_specs": "Simulação de sensor móvel; perspectiva grande angular de 24mm; abertura f/1.8 para profundidade de campo rasa no fundo; leve aberração cromática perto das bordas do espelho; proporção de aspecto vertical 9:16.",
        "negative_constraints": [
          "sem logotipos",
          "sem texto",
          "sem marcas d'água",
          "sem membros extras",
          "sem dedos distorcidos",
          "sem suavização de beleza",
          "sem pelos deformados"
        ]
      }
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310071309_fksqp7_HBSZpSQWgAAuXky.jpg" width="600" alt="Perfil / Avatar - Simulação de Selfie no Espelho de Ana de Armas - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310071316_y6s056_HBSZwnQaAAAhXSD.jpg" width="600" alt="Perfil / Avatar - Simulação de Selfie no Espelho de Ana de Armas - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [RubenSalvo](https://x.com/RubenSalvo_)
- **Fonte:** [Twitter Post](https://x.com/RubenSalvo_/status/2023411222423433546)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10222)**

---

### No. 6: Perfil / Avatar - Troca de Identidade na Grade de Expressão (4x4)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON complexo para geração de imagem para imagem, especificamente projetado para realizar uma troca de identidade. Ele usa uma identidade de referência para substituir a pessoa em uma imagem de grade de expressão 4x4 existente, preservando estritamente o layout original da grade, poses, expressões e plano de fundo, ao mesmo tempo em que garante anatomia realista e renderização de alta qualidade.

#### 📝 Prompt

```
{
  "generation_request": {
    "meta_data": {
      "task_type": "identity_swap_into_existing_expression_grid",
      "language": "pt",
      "priority": "highest",
      "version": "v1.0_KEEP_GRID_SWAP_IDENTITY_4X4"
    },
    "input": {
      "mode": "image_to_image",
      "reference_image_usage": "very_high",
      "preserve_identity": true,
      "preserve_facial_features": true,
      "preserve_hairstyle": true,
      "notes": "ÂNCORA DE ESTRUTURA PRIMÁRIA: use a imagem da grade de expressões 4x4 carregada. Mantenha o layout exato da grade, corte, enquadramento do painel, variedade de poses, posições das mãos e plano de fundo. ÂNCORA DE IDENTIDADE PRIMÁRIA: use o retrato de referência carregado da pessoa alvo. Substitua a pessoa em cada painel pela identidade de referência, mantendo a expressão e o gesto de cada painel. Mantenha a textura natural da pele, anatomia realista e mãos corretas."
    },
    "output": {
      "aspect_ratio": "2:3",
      "resolution": "ultra_high",
      "num_images": 1,
      "sharpness": "crisp",
      "grain": "subtle_analog"
    },
    "style": {
      "keep_original": true,
      "background": "keep exactly the same as the grid image",
      "lighting": "match the grid image lighting",
      "color": "keep original (or convert to pure black and white if requested)",
      "finish": "clean, realistic, no plastic skin"
    },
    "quality_control": {
      "identity_lock": "strict",
      "hands_priority": "very_high",
      "avoid": [
        "dedos extras",
        "dedos faltando",
        "mãos deformadas",
        "rosto deformado",
        "olhos desiguais",
        "boca derretida",
        "texto",
        "marca d'água",
        "logotipo"
      ]
    },
    "negative_prompt": [
      "baixa resolução",
      "borrão",
      "anatomia distorcida",
      "incompatibilidade facial",
      "pele plástica",
      "suavização excessiva"
    ]
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310082994_y72r2n_HBR7Qx2aMAAvk8-.jpg" width="600" alt="Perfil / Avatar - Troca de Identidade na Grade de Expressão (4x4) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Özge Döner](https://x.com/astronomerozge1)
- **Fonte:** [Twitter Post](https://x.com/astronomerozge1/status/2023377736958447809)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10243)**

---

### No. 7: Perfil / Avatar - Selfie Crua com Flash no Espelho em Elevador Espelhado

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente estruturado simulando uma selfie espelhada ultra-wide 0.5x, crua e de alto contraste, tirada com flash forte em um elevador espelhado, apresentando uma trendsetter em um body de vinil preto e jaqueta de couro, enfatizando a distorção e um clima ousado e sedutor.

#### 📝 Prompt

```
{
  "image_prompt": {
    "meta": {
      "aspect_ratio": "9:16",
      "style": "Selfie de espelho ultra-wide 0.5x, flash cru"
    },
    "subject": {
      "description": "Jovem de 22 anos, lançadora de tendências, com uma aura confiante e ousada",
      "face": "Olhando para a tela do próprio celular no espelho, mordendo levemente o lábio, delineador gatinho marcante, com um olhar sedutor",
      "skin": "Destaques nítidos do flash do celular, textura de pele brilhante, clavículas reluzentes",
      "hair": "Rabo de cavalo elegante com 'efeito molhado', baby hairs perfeitamente penteados na testa",
      "pose": "Sentada no chão de um elevador espelhado, pernas estendidas em direção ao espelho (distorção extrema de 0.5x), segurando o celular no alto",
      "outfit": "Body de vinil/látex preto, jaqueta de couro oversized caindo de um ombro, correntes prateadas grossas"
    },
    "environment": {
      "location": "Um elevador moderno com paredes espelhadas e metal arranhado",
      "background_elements": [
        "Reflexos infinitos da pessoa se desvanecendo na distância",
        "Número do andar 'B2' em LED vermelho brilhando no canto",
        "Manchas sutis de mãos e impressões digitais no vidro do espelho"
      ]
    },
    "lighting": {
      "type": "Flash direto e forte de smartphone + LED frio no teto",
      "characteristics": [
        "Sombras pretas duras na parede de trás",
        "Destaques especulares no tecido de vinil (aparência líquida)",
        "Bordas com vinheta devido à lente grande angular"
      ]
    },
    "photography_style": {
      "style": "Dump de 'noite na balada' estilo paparazzi",
      "camera_look": "Câmera de smartphone com distorção de 0.5x, alto contraste",
      "imperfections": "Pequenas partículas de poeira no espelho, reflexo da lente do flash, granulação digital nas áreas escuras",
      "mood": "Rebelde, poderosa, sedutora, elétrica"
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310081386_2j2eby_HBQJSPFWkAA1fdd.jpg" width="600" alt="Perfil / Avatar - Selfie Crua com Flash no Espelho em Elevador Espelhado - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Human AI Gallery | Prompt Architect](https://x.com/HumanAIGallery)
- **Fonte:** [Twitter Post](https://x.com/HumanAIGallery/status/2023252347997024645)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10239)**

---

### No. 8: Perfil / Avatar - Prompt de Renderização 3D da Versão Cartoon da Billie Eilish

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente estruturado para o Gemini Nano Banana Pro gerar uma renderização 3D semirrealista da Billie Eilish em uma versão cartoon. Ele especifica características faciais detalhadas, cabelo verde-escuro em maria-chiquinhas, joias específicas, roupas verdes oversized e detalhes técnicos como resolução 8K e iluminação cinematográfica.

#### 📝 Prompt

```
{
"image_type": "Retrato digital renderizado em 3D",
"resolution_target": "8K",
"aspect_ratio": "3:4",
"camera_framing": {
"shot_type": "plano médio fechado",
"orientation": "vertical",
"subject_position": "o sujeito ocupa o centro-esquerda do quadro",
"crop": "cabeça até o torso superior visível"
},
"camera_angle": {
"head_pose": "perfil três-quartos",
"face_direction": "virado para a direita do observador",
"eye_direction": "olhando ligeiramente para a câmera"
},
"subject": {
"gender_presentation": "feminino",
"age_appearance": "jovem adulta",
"skin_tone": "tom de pele claro",
"facial_features": {
"face_shape": "ligeiramente alongado com contornos suaves",
"forehead": "lisa, larga",
"eyes": {
"color": "verde",
"shape": "grandes, arredondados",
"eyelashes": "visíveis, espessura natural"
},
"eyebrows": "escuras, grossas, arqueadas naturalmente",
"nose": {
"shape": "pequeno a médio",
"piercing": "piercing de argola prateada na narina esquerda"
},
"mouth": {
"expression": "sorriso sutil",
"lips": "preenchimento médio, tom rosa natural"
},
"freckles": "sardas visíveis no nariz e nas bochechas",
"marks": "pequena marca semelhante a um arranhão na bochecha direita"
}
},
"hair": {
"color": "{argument name=\"hair color\" default=\"dark green\"}",
"style": "duas marias-chiquinhas altas",
"parting": "partido ao meio",
"texture": "liso com fios soltos esvoaçantes",
"hair_ties": "elásticos verdes",
"loose_strands": "vários fios finos emoldurando o rosto"
},
"ears_and_jewelry": {
"ears_visible": true,
"ear_piercings": "pequeno brinco de argola dourada visível na orelha direita",
"neckwear": [
{
"type": "gargantilha",
"material": "couro preto",
"details": "tachas prateadas"
}
],
"necklaces": [
{
"material": "ouro",
"style": "corrente fina",
"pendant": "pequeno anel circular"
},
{
"material": "ouro",
"style": "corrente mais grossa",
"pendant": "pingente em forma de cadeado"
}
]
},
"clothing": {
"top": {
"type": "camiseta oversized",
"color": "verde",
"fabric_appearance": "algodão macio",
"graphics": "símbolo abstrato preto no peito",
"fit": "solto"
}
},
"pose_and_body": {
"shoulders": "ligeiramente angulados",
"neck": "alongado, relaxado",
"posture": "ereta com inclinação casual"
},
"lighting": {
"type": "iluminação de estúdio suave",
"direction": "frente-esquerda",
"shadows": "sombras suaves definindo os contornos faciais",
"contrast": "moderado"
},
"background": {
"color": "cinza claro neutro",
"texture": "gradiente suave",
"depth": "profundidade de campo rasa",
"distractions": "nenhuma"
},
"render_style": {
"style": "renderização de personagem 3D semi-realista",
"skin_detail": "textura de pele altamente detalhada",
"material_quality": "shaders realistas de tecido e metal",
"edges": "limpas, polidas",
"overall_finish": "gerado por IA, visual ultralimpo"
},
"color_palette": {
"dominant_colors": ["verde", "cinza"],
"accent_colors": ["dourado", "preto", "prata"]
},
"quality_tags": [
"ultradetalhado",
"8K",
"alta nitidez",
"iluminação cinematográfica",
"renderização 3D profissional"
]
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223975087_2e3t4b_HBN0QFFakAEkIfT.jpg" width="600" alt="Perfil / Avatar - Prompt de Renderização 3D da Versão Cartoon da Billie Eilish - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [esratrkr](https://x.com/trkresram)
- **Fonte:** [Twitter Post](https://x.com/trkresram/status/2023089400012284088)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10193)**

---

### No. 9: Perfil / Avatar - Retrato de Loira Voluptuosa em Carro

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente detalhado para o Nano Banana Pro gerar um retrato fotorrealista e em close-up de alto ângulo de uma jovem loira voluptuosa sentada em um veículo, usando um biquíni floral de amarrar, capturada sob luz natural com uma expressão brincalhona e sedutora.

#### 📝 Prompt

```
{
"subject": {
"description": "Jovem mulher com cabelo loiro ondulado na altura dos ombros, sentada em um veículo. Ela tem pele clara com textura natural, incluindo uma pequena pinta no peito. Suas características faciais incluem sobrancelhas arqueadas, olhos castanhos e covinhas profundas ao sorrir.",
"body_characteristics": {
"build": "Curvilínea e voluptuosa",
"bust": "Busto visivelmente grande, cheio e pesado, com decote proeminente e projeção profunda. Comportamento natural do tecido mole com a gravidade afetando a forma. A profundidade do busto é significativamente maior que a profundidade da caixa torácica.",
"torso": "Cintura estreita em relação ao tamanho do busto, textura de pele macia."
},
"clothing": {
"item": "Top de biquíni de amarrar",
"color": "Base branca ou azul muito pálido",
"pattern": "Estampa floral pequena roxa com folhas verdes",
"fit": "Ajuste apertado, enfatizando o volume do busto"
},
"accessories": {
"nails": "Unhas longas, quadradas com esmalte branco"
}
},
"pose": {
"type": "Retrato sentado, close-up",
"head": "Inclinada ligeiramente para a direita, olhando diretamente para a câmera",
"expression": "Sorriso brincalhão e sedutor, mostrando os dentes, com covinhas distintas. Ela está mordendo o polegar esquerdo ou apoiando-o no lábio inferior.",
"arms": "Braço esquerdo levantado com a mão curvada perto da boca, polegar tocando o lábio. Braço direito para baixo ao lado.",
"body_orientation": "Tronco superior ligeiramente angulado em direção à câmera, sentada encostada no banco do carro."
},
"environment": {
"location": "Interior de um veículo, provavelmente um Jeep Wrangler",
"elements": "Bancos de carro de couro preto com encostos de cabeça, barras de proteção visíveis ou estrutura do veículo ao fundo. Através da janela traseira, uma cena externa borrada com um prédio e sinalização (texto parcialmente visível inclui 'BANK' e 'REAL ESTATE') e uma lixeira verde.",
"atmosphere": "Dia casual e ensolarado, cabine de veículo semiaberta"
},
"camera": {
"shot_type": "Retrato em close-up, ângulo alto",
"perspective": "Perspectiva à distância de um braço (simulando um ângulo de selfie sem o telefone visível)",
"focal_length": "Equivalente a 35mm a 50mm",
"depth_of_field": "Moderada, mantendo o sujeito em foco nítido enquanto o fundo do interior do carro é ligeiramente suavizado, mas reconhecível.",
"framing": "Enquadrado do meio do tronco para cima, centralizando no rosto e no peito."
},
"lighting": {
"type": "Luz natural do dia",
"source": "Luz solar ambiente entrando no veículo pela frente e pela esquerda",
"quality": "Brilhante e difusa, criando sombras suaves sob o queixo e definindo os contornos das clavículas e do decote.",
"highlights": "Destaques naturais na testa, nariz e parte superior do peito."
},
"mood_and_expression": {
"mood": "Brincalhona, confiante, sedutora, feliz",
"expression": "Sorriso genuíno com covinhas, contato visual envolvente, gesto sugestivo com o polegar perto da boca."
},
"style_and_realism": {
"style": "Fotografia fotorrealista, estilo de vida espontâneo",
"fidelity": "Renderização de textura de alta fidelidade, capturando poros da pele, fios de cabelo e detalhes do tecido sem estilização."
},
"colors_and_tone": {
"palette": "Tons de pele naturais, cabelo loiro brilhante"
}
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223986445_8nb2x0_HBNq36La0AAQLYq.jpg" width="600" alt="Perfil / Avatar - Retrato de Loira Voluptuosa em Carro - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [brindley](https://x.com/brindleyai)
- **Fonte:** [Twitter Post](https://x.com/brindleyai/status/2023078177577271404)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10218)**

---

### No. 10: Perfil / Avatar - Prompt de Substituição de Retrato em Close-up Cinematográfico

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt de retrato cinematográfico ultra-realista em close-up para o Nano Banana Pro que exige a substituição do assunto por uma imagem de referência. Ele especifica iluminação direcional dramática e quente, textura de pele visível, uma expressão suave e pensativa e uma profundidade de campo rasa (aparência de lente de 85 mm) para uma sensação editorial.

#### 📝 Prompt

```
Retrato cinematográfico em close-up ultrarrealista, substituir o sujeito pela minha imagem de referência.

Uma jovem mulher mostrada dos ombros para cima, cabeça ligeiramente virada, olhos olhando para fora do quadro com uma expressão suave e pensativa. Proporções faciais naturais, textura de pele visível, sardas sutis e detalhes finos preservados.

Fios de cabelo soltos e ligeiramente bagunçados caindo sobre o rosto, criando um clima natural e íntimo, vestindo um top preto de alças finas, estilo minimalista, sem acessórios pesados. A iluminação é dramática e cinematográfica: luz direcional quente atingindo o rosto de um lado, sombras profundas no lado oposto, criando forte contraste e profundidade emocional. O fundo é escuro e discreto, suavemente desfocado, mantendo o foco total no rosto.

Fotografado com profundidade de campo rasa, aparência de lente de retrato de 85mm, bokeh cremoso, alto alcance dinâmico, gradação de cores natural com realces quentes e sombras suaves, tons de pele realistas, sem brilho artificial.

Fotorrealista, ultra-alta definição, fotografia de retrato editorial, realismo cinematográfico, iluminação com qualidade de filme, zero artefatos de IA.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223973694_rxa2yh_HBNPK14aUAAkNFJ.jpg" width="600" alt="Perfil / Avatar - Prompt de Substituição de Retrato em Close-up Cinematográfico - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Alice Glassier](https://x.com/aliceglassierai)
- **Fonte:** [Twitter Post](https://x.com/aliceglassierai/status/2023053010365010279)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10190)**

---

### No. 11: Perfil / Avatar - Restauração e Upscaling de Fotos Antigas: Prompt

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para o Gemini Nano Banana Pro instruindo-o a restaurar uma foto vintage antiga e desbotada, transformando-a em um retrato profissional de alta definição com cores e detalhes com qualidade de DSLR, usando upscaling avançado e preservando as características faciais e a clareza.

#### 📝 Prompt

```
"Restaure esta foto antiga para um retrato profissional com cores e detalhes com qualidade de DSLR, usando um algoritmo de upscaling avançado comparável aos resultados da Canon EOS R6 II. Garanta que a imagem restaurada pareça natural, mantenha as características faciais exatas e tenha ótima clareza."
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223971662_oh5wsm_HBND2K5bsAEurH1.jpg" width="600" alt="Perfil / Avatar - Restauração e Upscaling de Fotos Antigas: Prompt - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223971543_td1y9g_HBND2LSbsAAVrx6.jpg" width="600" alt="Perfil / Avatar - Restauração e Upscaling de Fotos Antigas: Prompt - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Edraak Tech | إدراك تِك](https://x.com/EdraakTechAi)
- **Fonte:** [Twitter Post](https://x.com/EdraakTechAi/status/2023035277225132309)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10185)**

---

### No. 12: Perfil / Avatar - Prompt de Cartão de Perfil do X (Twitter) no Estilo Pixar/Disney

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt detalhado para gerar uma imagem animada 3D fofa e altamente detalhada no estilo Pixar/Disney. A imagem apresenta uma garota sentada naturalmente na borda inferior de um cartão de perfil do X (Twitter), com os elementos da interface do usuário claramente visíveis, enfatizando iluminação quente, profundidade e alta resolução. Ele usa uma imagem de entrada como referência para as características da pessoa.

#### 📝 Prompt

```
Estilo de animação 3D fofo e ultradetalhado, no estilo Pixar/Disney,
sentado naturalmente na borda inferior do cartão de perfil do X (Twitter), flutuando para cima a partir da moldura do perfil.
As características da pessoa são baseadas em: "{argument name="person features" default="Input Image"}".
A garota está sentada na moldura do perfil.
A garota está tirando uma foto com uma câmera.
Os seguintes itens são exibidos claramente na interface do usuário do perfil do X: Nome: {argument name="name" default="Lovart Official"} (selo azul verificado)
Nome de usuário: {argument name="username" default="@lovart_jp"}
Uma interface do X (Twitter) limpa e moderna, um cartão de perfil branco arredondado, ícones discretos "Input Image", e a foto de perfil está visível.
A mão de uma pessoa segurando a borda inferior do cartão de mídia social. Fundo bege pastel suave, iluminação de estúdio quente, profundidade e sombras realistas, composição cinematográfica, resolução ultra-alta, 4K, ilustração 3D profissional e estética de tendência de mídia social.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223985023_myw799_HBCOe9ba8AADfeU.jpg" width="600" alt="Perfil / Avatar - Prompt de Cartão de Perfil do X (Twitter) no Estilo Pixar/Disney - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223985082_3m1x32_HBCOe1nagAAWf1b.jpg" width="600" alt="Perfil / Avatar - Prompt de Cartão de Perfil do X (Twitter) no Estilo Pixar/Disney - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Lovart 公式 (ラブアート)](https://x.com/lovart_jp)
- **Fonte:** [Twitter Post](https://x.com/lovart_jp/status/2022959075873673277)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10213)**

---

### No. 13: Perfil / Avatar - Prompt de Geração de Vídeo de Moda Estilo Vlog

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um prompt detalhado usado com o Nano Banana Pro para gerar uma imagem, que foi então convertida em vídeo usando o Google Veo 3.1. O prompt foca na criação de uma tomada realista, íntima e calorosa, no estilo vlog, de uma mulher discutindo sua moda, incluindo detalhes específicos sobre ângulo da câmera, iluminação, expressão e diálogo.

#### 📝 Prompt

```
Crie uma tomada em estilo de vídeo, com a câmera voltada para a frente. A câmera está fixa na altura do rosto e posicionada diretamente na frente do objeto. O objeto está sentado, conforme indicado por sua postura e composição.

A composição é simples e estável, sem ângulos dramáticos ou movimentos perceptíveis da câmera. A iluminação é realista, considerando [Adicionar iluminação realista considerando tomadas estilo UGC]. O rosto está claramente visível.

A expressão do objeto é calma e relaxada, com um sorriso natural e sutil. Parece que ela está prestes a começar a falar para a câmera para um vlog. A qualidade da imagem reflete uma tomada de vídeo de alta qualidade feita em ambiente interno à noite, sem filtros, efeitos de embelezamento ou nitidez artificial aplicados.

O espaço parece pessoal. O bokeh é devido às limitações da câmera, não a efeitos artificiais de profundidade de campo. A atmosfera geral é quente, brilhante e íntima, lembrando um momento real de vlog pouco antes de o objeto começar a falar.

O diálogo da mulher é: "O destaque da moda de hoje é [Adicionar características de moda]!" Ela fala em tom suave enquanto toca suas roupas. Ela sorri no final.

BGM: Uma música confortável, adequada para uma atmosfera de moda estilo vlog, está tocando.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223983678_w2ehj0_HBK4SxWasAAZM1E.jpg" width="600" alt="Perfil / Avatar - Prompt de Geração de Vídeo de Moda Estilo Vlog - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223983642_7xxayc_HBK4UKMakAMIGj1.jpg" width="600" alt="Perfil / Avatar - Prompt de Geração de Vídeo de Moda Estilo Vlog - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223983731_czbuz8_HBK4SSWasAAXNaf.jpg" width="600" alt="Perfil / Avatar - Prompt de Geração de Vídeo de Moda Estilo Vlog - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [空想写真家](https://x.com/KusoPhoto)
- **Fonte:** [Twitter Post](https://x.com/KusoPhoto/status/2022913770595778937)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10212)**

---

### No. 14: Perfil / Avatar - Retrato Cinematográfico Ultra-Realista em Close-up

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt detalhado para gerar um retrato em close-up cinematográfico ultrarrealista de uma jovem, enfatizando características faciais naturais, iluminação dramática e uma profundidade de campo rasa para um visual editorial com qualidade de filme. Requer uma imagem de referência do sujeito.

#### 📝 Prompt

```
Retrato cinematográfico em close-up ultrarrealista, substituir o sujeito pela minha imagem de referência.

Uma jovem mulher mostrada dos ombros para cima, com a cabeça ligeiramente virada, os olhos olhando para fora do quadro com uma expressão suave e pensativa. Proporções faciais naturais, textura de pele visível, sardas sutis e detalhes finos preservados.

Fios de cabelo soltos e ligeiramente bagunçados caindo sobre o rosto, criando um clima natural e íntimo, vestindo um top preto de alças finas, estilo minimalista, sem acessórios pesados. A iluminação é dramática e cinematográfica: luz direcional quente atingindo o rosto de um lado, sombras profundas no lado oposto, criando forte contraste e profundidade emocional. O fundo é escuro e discreto, suavemente desfocado, mantendo o foco total no rosto.

Fotografado com profundidade de campo rasa, aparência de lente de retrato de 85mm, bokeh cremoso, alto alcance dinâmico, gradação de cores natural com realces quentes e sombras suaves, tons de pele realistas, sem brilho artificial.

Fotorrealista, ultra-alta definição, fotografia de retrato editorial, realismo cinematográfico, iluminação com qualidade de filme, zero artefatos de IA.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223975362_bikr3t_HBKvhaqakAIo7uk.jpg" width="600" alt="Perfil / Avatar - Retrato Cinematográfico Ultra-Realista em Close-up - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Harboriis](https://x.com/harboriis)
- **Fonte:** [Twitter Post](https://x.com/harboriis/status/2022872175397736736)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10194)**

---

### No. 15: Perfil / Avatar - Selfie no Espelho com Colant do Homem-Aranha em Quarto de Luxo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente detalhado e estruturado para gerar um retrato de selfie no espelho ultrarrealista de uma mulher em um body inspirado no Homem-Aranha, em um quarto de luxo, especificando configurações de câmera, iluminação (golden hour), pose e descrições detalhadas de guarda-roupa/adereços.

#### 📝 Prompt

```
{
  "meta": {
    "style": "retrato selfie espelho ultrarrealista",
    "quality": "alta resolução 8k",
    "camera": "DSLR full-frame",
    "lens": "lente retrato 85mm f/1.8",
    "aperture": "f/2.2",
    "lighting": "luz natural suave de janela, tons ambientes dourados quentes",
    "color_grading": "tons cinematográficos quentes de bege e dourado suave",
    "aspect_ratio": "4:5 vertical"
  },
  "scene": {
    "location": "interior de quarto de luxo",
    "environment": "espelho de corpo inteiro ornamentado com moldura decorativa",
    "background_elements": [
      "cama estofada cor creme",
      "colcha bege texturizada",
      "travesseiros brancos macios",
      "cortinas transparentes filtrando a luz do dia",
      "paredes em tons quentes",
      "sombras interiores sutis e ambientes"
    ],
    "time_of_day": "manhã, hora dourada",
    "atmosphere": "calma, aconchegante, suavemente iluminada"
  },
  "subject": {
    "gender": "feminino",
    "age_range": "meados dos 20 anos",
    "skin_tone": "tez clara e quente",
    "physique": "em forma, atlética",
    "pose": "em pé, ereta, em frente ao espelho, segurando smartphone para selfie",
    "expression": "sorriso suave e confiante, olhar relaxado direcionado para a tela do telefone",
    "hair": {
      "style": "na altura dos ombros, ondas naturais soltas",
      "parting": "partido ao meio"
    },
    "makeup": "maquiagem natural suave, blush sutil, lábios neutros, leve definição nos olhos"
  },
  "wardrobe": {
    "outfit_type": "body de super-heroína",
    "design": "padrão inspirado no Homem-Aranha",
    "primary_colors": ["vermelho escuro", "azul marinho"],
    "details": [
      "padrão de teia vermelho metálico no torso e braços",
      "emblema de aranha preta centralizado no peito",
      "mangas longas e ajustadas",
      "design de perna de corte alto",
      "material atlético justo",
      "textura de tecido sutil com leve brilho"
    ],
    "material": "tecido de desempenho elástico tipo spandex",
    "fit": "justo, contornando a forma do corpo"
  },
  "props": {
    "smartphone": {
      "brand_style": "smartphone moderno de ponta",
      "color": "grafite escuro",
      "camera_module": "sistema de câmera tripla",
      "usage": "segurado verticalmente para selfie no espelho"
    }
  },
  "composition": {
    "framing": "composição centralizada",
    "crop": "enquadramento da metade da coxa até a cabeça",
    "camera_angle": "perspectiva direta do espelho",
    "depth_of_field": "profundidade de campo rasa, fundo suavemente desfocado",
    "symmetry": "alinhamento vertical equilibrado usando a moldura do espelho"
  },
  "lighting_details": {
    "key_light": "luz natural da janela lateral",
    "fill_light": "luz ambiente interior suave e refletida",
    "highlight_behavior": "reflexos suaves nas seções vermelhas metálicas",
    "shadow_quality": "sombras suaves e difusas"
  },
  "rendering_style": {
    "realism_level": "fotorrealista",
    "skin_texture": "textura de pele natural com suavidade sutil",
    "fabric_detail": "detalhes finos do padrão de teia visíveis",
    "dynamic_range": "alto alcance dinâmico com realces preservados",
    "post_processing": [
      "suave"
    ]
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137197233_rl5oz0_HBJVjQLXMAMpcx0.jpg" width="600" alt="Perfil / Avatar - Selfie no Espelho com Colant do Homem-Aranha em Quarto de Luxo - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Alice Glassier](https://x.com/aliceglassierai)
- **Fonte:** [Twitter Post](https://x.com/aliceglassierai/status/2022774326479519918)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10095)**

---

### No. 16: Perfil / Avatar - Gerador de Imagens para Passaporte

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt projetado para gerar uma foto tamanho passaporte ultrarrealista, enfatizando a semelhança facial exata, estilo de estúdio profissional e requisitos específicos para fotos de documentos oficiais, incluindo expressão neutra e orelhas visíveis.

#### 📝 Prompt

```
"Foto de passaporte ultrarrealista minha (semelhança facial exata, 100% igual, sem alterações faciais).",."style": "Retrato de estúdio profissional adequado para uso em documentos de identificação oficiais ou passaporte.",
"outfit": "{argument name=\"outfit description\" default=\"camisa social branca e gravata combinando com marca moderna\"}", "expression": "Sorriso neutro com lábios fechados, olhar direto, ambas as orelhas visíveis, ombros incluídos."
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137215285_52g5w5_HBIZIR7bgAE7C-y.jpg" width="600" alt="Perfil / Avatar - Gerador de Imagens para Passaporte - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137215234_rct9a0_HBIZIRPakAAKO-r.jpg" width="600" alt="Perfil / Avatar - Gerador de Imagens para Passaporte - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Shreya♡](https://x.com/Shreyayadav)
- **Fonte:** [Twitter Post](https://x.com/Shreyayadav/status/2022706817013551558)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10130)**

---

### No. 17: Perfil / Avatar - Grade de Expressões de Cabine de Fotos em Preto e Branco (4x4)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt estruturado altamente detalhado para gerar uma grade 4x4 de imagens estilo fotocabine em preto e branco, com foco em preservar a identidade de uma imagem de referência carregada enquanto retrata 16 expressões faciais distintas com requisitos específicos de iluminação e textura.

#### 📝 Prompt

```
{
  "generation_request": {
    "meta_data": {
      "task_type": "black_and_white_photobooth_expression_grid_4x4",
      "language": "en",
      "priority": "highest",
      "version": "v1.0_BW_PHOTOBOOTH_EXPRESSIONS_4X4"
    },
    "input": {
      "mode": "image_to_image",
      "reference_image_usage": "very_high",
      "preserve_identity": true,
      "preserve_facial_features": true,
      "preserve_hairstyle": true,
      "notes": "Use a referência como âncora principal. Crie uma grade de expressões estilo cabine de fotos em preto e branco. Mantenha a mesma identidade e cabelo da mulher adulta. Cada painel deve mostrar uma expressão facial diferente. Fundo mínimo, aparência de flash direto de cabine de fotos, textura de pele natural."
    },
    "output": {
      "aspect_ratio": "1:1",
      "resolution": "ultra_high",
      "num_images": 1,
      "layout": {
        "type": "grid",
        "rows": 4,
        "cols": 4,
        "gutter": "thin",
        "panel_consistency": "high"
      },
      "sharpness": "crisp_photobooth",
      "grain": "subtle_analog_bw"
    },
    "scene": {
      "concept": "folha de contato clássica de cabine de fotos com rostos expressivos",
      "environment": "fundo neutro simples, sem adereços",
      "lighting": {
        "style": "flash direto de cabine de fotos",
        "key_light": "flash frontal, ligeiramente forte, mas lisonjeiro",
        "shadows": "sombras curtas e suaves atrás do sujeito",
        "avoid": "luz lateral cinematográfica, fundos dramáticos"
      },
      "camera": {
        "lens": "50mm",
        "distance": "enquadramento apertado de cabeça e ombros",
        "focus": "olhos nítidos em cada painel"
      }
    },
    "subject": {
      "type": "adult woman",
      "wardrobe": "visual simples de cabine de fotos sem alças ou ombros à mostra (sem logotipos)",
      "hair": "manter o mesmo penteado em todos os painéis",
      "makeup": "mínima, natural",
      "anatomy_rules": "proporções faciais corretas, sem olhos/boca distorcidos"
    },
    "expression_set": {
      "panel_01": "sorriso enrugado, olhos ligeiramente apertados",
      "panel_02": "olhar intenso com os dedos emoldurando os olhos",
      "panel_03": "grande risada, boca aberta, alegre",
      "panel_04": "rosto entediado / desinteressado, queixo nas mãos",
      "panel_05": "bico triste, olhar com olhos marejados",
      "panel_06": "rosto bobo com as duas mãos fazendo pequenos chifres acima da cabeça",
      "panel_07": "língua para fora brincalhona, sorriso maroto",
      "panel_08": "olhar zangado, sobrancelhas abaixadas",
      "panel_09": "olhar sedutor, mão tocando a bochecha",
      "panel_10": "olhos arregalados de surpresa, boca ligeiramente aberta",
      "panel_11": "grito falso / grito animado, mãos perto do rosto",
      "panel_12": "sorriso malicioso com pose de mão em forma de garra",
      "panel_13": "cenho franzido confuso, lábios apertados",
      "panel_14": "rosto chorando, mãos na cabeça, dramático",
      "panel_15": "língua para fora com os olhos fechados, brincalhão",
      "panel_16": "duck face com pequeno gesto de chifres de diabo"
    },
    "style": {
      "color": "preto e branco puro",
      "contrast": "m"
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137193041_jhor76_HBIKSy1W4AALopr.jpg" width="600" alt="Perfil / Avatar - Grade de Expressões de Cabine de Fotos em Preto e Branco (4x4) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Özge Döner](https://x.com/astronomerozge1)
- **Fonte:** [Twitter Post](https://x.com/astronomerozge1/status/2022690793702486382)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10089)**

---

### No. 18: Perfil / Avatar - Retrato Corporativo Ultrarrealista de Empresário

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um retrato de estúdio ultrarrealista de um jovem empresário confiante, detalhando sua vestimenta (terno preto sob medida), ação (ajustando o punho da camisa) e especificações técnicas de fotografia (lente de 85mm, f/2, iluminação suave e difusa) para um retrato corporativo premium.

#### 📝 Prompt

```
Retrato de estúdio ultrarrealista de um jovem empresário confiante usando um terno preto sob medida e gravata preta, camisa social branca, leve sorriso natural, barba bem-cuidada, ajustando o punho do terno enquanto exibe um relógio de pulso de luxo. Fundo de estúdio cinza limpo, fundo com gradiente suave, estilo de foto profissional corporativa. Luz principal suave e difusa, iluminação de contorno sutil, detalhes faciais nítidos, textura de pele natural, profundidade de campo rasa, lente de 85mm, f/2, alto alcance dinâmico, foco nítido, gradação de cores cinematográfica, resolução 8K, fotografia editorial premium.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137198989_jssa6q_HBHOG6obgAA4MYR.jpg" width="600" alt="Perfil / Avatar - Retrato Corporativo Ultrarrealista de Empresário - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Taaruk](https://x.com/Taaruk_)
- **Fonte:** [Twitter Post](https://x.com/Taaruk_/status/2022624342811816235)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10097)**

---

### No. 19: Perfil / Avatar - Retrato Fitness de Selfie no Espelho Ultra-Realista

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente detalhado e estruturado para gerar uma selfie de espelho vertical ultrarrealista de uma mulher após um treino, simulando uma captura de smartphone (iPhone 17 Pro Max) com textura de pele natural, brilho de suor e detalhes autênticos pós-treino.

#### 📝 Prompt

```
{
  "meta": {
    "style": "fotografia ultra-realista de estilo de vida fitness com smartphone",
    "quality": "4K Ultra HD, alto detalhe, textura de pele natural",
    "camera": "iPhone 17 Pro Max",
    "lens": "lente nativa 1x",
    "aperture_simulation": "f/1.8 computacional",
    "iso": 160,
    "white_balance": "equilíbrio de luz do dia neutro",
    "color_grading": "tons naturais com realces ligeiramente quentes",
    "aspect_ratio": "9:16 vertical",
    "focus": "reflexo nítido no espelho, profundidade realista do smartphone"
  },
  "scene": {
    "location": "canto de academia moderna em casa ou espaço de treino no quarto",
    "time_of_day": "final da tarde",
    "lighting": {
      "primary": "luz natural da janela",
      "secondary": "iluminação ambiente interna suave",
      "mood": "energético, fresco, autêntico",
      "shadows": "queda de sombra natural suave"
    },
    "background_elements": [
      "espelho de corpo inteiro",
      "tapete de yoga enrolado",
      "pequena toalha no chão",
      "decoração mínima",
      "garrafa de água por perto"
    ],
    "atmosphere": "momento espontâneo pós-treino, vibe de estilo de vida saudável"
  },
  "subject": {
    "gender": "feminino",
    "age": "jovem adulta",
    "body_type": "físico esbelto e tonificado com curvas femininas naturais",
    "skin_tone": "clara com vermelhidão natural do treino",
    "skin_details": "brilho leve de suor na testa e clavícula, marcas sutis de acne, poros visíveis, textura realista",
    "hair": {
      "color": "loiro claro",
      "style": "rabo de cavalo ligeiramente bagunçado com mechas soltas e úmidas emoldurando o rosto"
    },
    "expression": "sorriso suave e satisfeito, bochechas ligeiramente coradas",
    "pose": {
      "position": "em pé na frente do espelho",
      "action": "segurando o telefone em uma mão para selfie no espelho",
      "posture": "ligeira inclinação do quadril, postura relaxada, mas energizada"
    },
    "wardrobe": {
      "outfit_type": "conjunto de yoga atlético",
      "top": "top esportivo justo ligeiramente escurecido pelo suor",
      "bottom": "leggings de compressão de cintura alta",
      "style_description": "roupa esportiva moderna, marca mínima"
    },
    "emotion": "realizada, confiante, beleza natural após o treino"
  },
  "composition": {
    "camera_angle": "perspectiva de selfie no espelho",
    "framing": "composição vertical centralizada",
    "depth_of_field": "profundidade moderada, sujeito nítido, fundo suavemente desfocado",
    "realism_effects": "processamento HDR autêntico do iPhone, ligeira distorção da lente, granulação sutil do smartphone"
  },
  "rendering_details": {
    "skin_detail": "textura de pele natural com poros visíveis e realces de suor realistas",
    "fabric_detail": "textura de tecido elástico com áreas sutilmente úmidas",
    "hair_detail": "fios individuais ligeiramente úmidos visíveis",
    "lighting_effects": "reflexos de brilho natural na pele",
    "realism_level": "fotorrealista, captura autêntica de smartphone"
  },
  "mood_keywords": [
    "pós-treino",
    "estilo de vida fitness",
    "selfie no espelho",
    "beleza natural",
    "autêntico"
  ]
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137210114_mpqut4_HBHDh-yXcAIwur1.jpg" width="600" alt="Perfil / Avatar - Retrato Fitness de Selfie no Espelho Ultra-Realista - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [TumuAI](https://x.com/tumuaipromptx)
- **Fonte:** [Twitter Post](https://x.com/tumuaipromptx/status/2022612768529031385)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10120)**

---

### No. 20: Publicação em Mídias Sociais - Imagem de anúncio de livro estilo "Train-ad"

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt japonês detalhado para gerar um anúncio estilo livro de negócios 16:9, apresentando uma imagem de livro específica com pontos de cópia em japonês.

#### 📝 Prompt

```
Por favor, gere uma imagem de anúncio.

==== Especificações do anúncio ===
- Proporção: 16:9 (horizontal)
- Produto a ser anunciado: o livro na primeira imagem anexada
- Elemento principal: coloque o livro da primeira imagem anexada de forma tridimensional
- Idioma: japonês
- Estilo: anúncio para um livro de negócios

# Texto a incluir:
- Texto pré-título: 【Nova tiragem decidida cerca de uma semana após o lançamento】

Livro “{argument name="book_title_en" default="Designing from Zero with AI"}” já à venda e com bom desempenho.

Ranking de Mais Vendidos da Amazon
Classificado em 1º lugar em vendas de design comercial (em 15/10)
https://t.co/QxbYpfFVj6
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1763885539326_yao7in_G6WBYReawAAcp2x.jpg" width="600" alt="Publicação em Mídias Sociais - Imagem de anúncio de livro estilo "Train-ad" - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [KAWAI](https://x.com/kawai_design)
- **Fonte:** [Twitter Post](https://x.com/kawai_design/status/1992142466255114727)
- **Publicado:** 22 de novembro de 2025
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=532)**

---

### No. 21: Publicação em Mídias Sociais - Grade de Transformação Sazonal

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um modelo de prompt para gerar uma grade 2x2 mostrando o mesmo objeto ou cena transformada ao longo das quatro estações (Primavera, Verão, Outono, Inverno), mantendo uma estética contínua e um ângulo de câmera consistente.

#### 📝 Prompt

```
Grade 2x2 mostrando o mesmo [{argument name="object or scene" default="OBJETO/CENA"}] nas quatro estações. Primavera no canto superior esquerdo (flores de cerejeira, tons pastel suaves), verão no canto superior direito (luz dourada, verdes vibrantes), outono no canto inferior esquerdo (folhas alaranjadas, tons quentes), inverno no canto inferior direito (neve, crepúsculo azul). Estética perfeita, mesmo ângulo de câmera, iluminação cinematográfica em cada painel.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310079634_278gq0_HBT0rq3bcAMeCHF.jpg" width="600" alt="Publicação em Mídias Sociais - Grade de Transformação Sazonal - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310079735_nlkcd5_HBT0xm1bEAAepVS.jpg" width="600" alt="Publicação em Mídias Sociais - Grade de Transformação Sazonal - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310079770_63tpm7_HBT016CacAA6g3s.jpg" width="600" alt="Publicação em Mídias Sociais - Grade de Transformação Sazonal - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310080753_7f6e9o_HBT06t7XwAAVXyL.jpg" width="600" alt="Publicação em Mídias Sociais - Grade de Transformação Sazonal - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Alexandra Aisling](https://x.com/AllaAisling)
- **Fonte:** [Twitter Post](https://x.com/AllaAisling/status/2023511466884895022)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10238)**

---

### No. 22: Publicação em Mídias Sociais - Arte Abstrata Fluida Vibrante

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma imagem vibrante e abstrata em close-up de uma arte fluida. Ele enfatiza um padrão hipnotizante de células e formas orgânicas usando uma mistura vívida de azuis profundos, verdes-azulados, laranjas, amarelos e roxos, criando uma composição dinâmica e energética que lembra organismos microscópicos.

#### 📝 Prompt

```
Uma vibrante e abstrata imagem em close-up de uma técnica de fluid art, exibindo um padrão hipnotizante de células e formas orgânicas. As cores são uma mistura vívida de azuis profundos, verdes-azulados, laranjas, amarelos e roxos, com algumas áreas em rosa e branco. As células variam em tamanho e forma, algumas perfeitamente redondas, outras irregulares e ameboides, muitas contendo círculos concêntricos menores ou pontos dentro delas. O fundo é um roxo escuro e rico que transita para áreas de laranja brilhante e rosa, criando uma composição dinâmica e energética. O efeito geral lembra organismos microscópicos ou uma superfície colorida e marmorizada.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310084474_dw9kld_HBTvo5FaUAAaZkR.jpg" width="600" alt="Publicação em Mídias Sociais - Arte Abstrata Fluida Vibrante - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Heather Green](https://x.com/heathergreen)
- **Fonte:** [Twitter Post](https://x.com/heathergreen/status/2023505623120224377)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10246)**

---

### No. 23: Publicação em Mídias Sociais - Retrato Cinematográfico Noturno de Sadie Sink com Carro de Luxo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente estruturado para gerar um retrato noturno cinematográfico e fotorrealista de Sadie Sink em um agasalho de veludo escuro, virando-se para olhar para a câmera, ambientado ao ar livre ao lado de um carro conversível de luxo com impressionante iluminação ambiente de néon roxo.

#### 📝 Prompt

```
{
  "image_generation_prompt": {
    "subject_details": {
      "identity": "{argument name=\"identity\" default=\"Sadie Sink\"}",
      "physical_attributes": "Rosto, formato do corpo e altura exatos de Sadie Sink. Vibe sexy, sedutora e confiante.",
      "hair": "Cabelo ruivo característico penteado em um rabo de cavalo casual, ligeiramente bagunçado, com mechas soltas emoldurando elegantemente o rosto.",
      "pose_and_expression": "De pé, virada para o lado, mas torcendo o corpo para olhar por cima do ombro esquerdo diretamente para a câmera. A mão esquerda está levantada com um dedo suavemente apoiado perto do lábio inferior. O braço direito está para baixo segurando uma bolsa. Expressão sedutora e cativante."
    },
    "wardrobe_and_accessories": {
      "clothing": "Agasalho de veludo cotelê/veludo marrom escuro composto por um moletom cropped de manga comprida (revelando um pouco da barriga) e calças de moletom largas combinando.",
      "jewelry": "Vários anéis de prata nos dedos e pulseiras de prata em camadas no pulso esquerdo.",
      "bag": "Segurando uma bolsa de couro acolchoada verde escura com alça de corrente dourada (estilo Chanel) na mão direita, pendurada ao lado da perna."
    },
    "setting_and_props": {
      "environment": "Ao ar livre durante a noite/crepúsculo. De pé em uma entrada pavimentada ou estrada tranquila com árvores e cercas vivas altas e verde-escuras ao fundo.",
      "vehicle": "Um carro conversível de luxo branco moderno (estilo Mercedes) estacionado bem ao lado dela. A porta do lado do motorista está bem aberta.",
      "vehicle_details": "O carro possui interior preto com volante visível. Uma impressionante iluminação ambiente neon roxa ilumina o interior da porta do carro aberta e o painel. Uma bolsa prateada brilhante está dentro do carro no lado do passageiro."
    },
    "style_and_quality": {
      "image_type": "Foto 4k HD, fotorrealista.",
      "lighting_and_atmosphere": "Iluminação cinematográfica noturna, luz natural do crepúsculo misturada com o brilho das luzes ambientes roxas do carro. Altamente detalhado, foco nítido, capturando uma estética de estilo de vida de celebridade de alto nível."
    },
    "technical_parameters": {
      "aspect_ratio": "9:16"
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310079131_bo1yj2_HBTrSIzbUAEr43a.jpg" width="600" alt="Publicação em Mídias Sociais - Retrato Cinematográfico Noturno de Sadie Sink com Carro de Luxo - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Serrah ❀](https://x.com/Serreh131306)
- **Fonte:** [Twitter Post](https://x.com/Serreh131306/status/2023500834794074238)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10235)**

---

### No. 24: Publicação em Mídias Sociais - Foto Documental em Preto e Branco de Criança em Barco

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para criar uma fotografia documental em preto e branco de uma criança descansando dentro de um pequeno barco de pesca de madeira, focando na autêntica vida rural, iluminação natural e realismo fotojornalístico.

#### 📝 Prompt

```
Fotografia documental em preto e branco de uma criança deitada dentro de um pequeno barco de pesca de madeira, com os braços atrás da cabeça, cordas espalhadas ao redor, horizonte de água calma ao fundo, vila costeira visível à distância, céu nublado, luz natural suave e difusa, lente documental de 35mm, vida rural autêntica, tons de pele realistas, granulação sutil, retrato ambiental, realismo fotojornalístico
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310069713_uu952u_HBTm-Yea8AEWd6W.jpg" width="600" alt="Publicação em Mídias Sociais - Foto Documental em Preto e Branco de Criança em Barco - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Baby Meme X](https://x.com/babymemexx)
- **Fonte:** [Twitter Post](https://x.com/babymemexx/status/2023496650753487009)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10219)**

---

### No. 25: Publicação em Mídias Sociais - Reel de Banho de Espuma Aconchegante à Luz de Velas

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON detalhado para gerar uma imagem ultra-fotorrealista simulando um vídeo HDR de iPhone em baixa luminosidade. A cena apresenta uma mulher loira curvilínea relaxando em uma banheira moderna com muita espuma, iluminada por uma luz quente e bruxuleante de velas, usando uma tiara de sapo verde brilhante, enfatizando proporções corporais naturais e sombras cinematográficas.

#### 📝 Prompt

```
{
  "meta": {
    "quality": "ultrarrealista",
    "resolution": "4k",
    "aspect_ratio": "9:16",
    "camera": "iPhone 15 Pro",
    "lens": "câmera frontal grande angular de 24mm",
    "style": "HDR de iPhone com pouca luz, brilho quente de velas, sombras cinematográficas, granulação suave, tons de pele realistas"
  },

  "character_lock": {
    "age": "meados dos 20 anos (adulto)",
    "ethnicity": "europeia loira",
    "hair": {
      "color": "loiro",
      "style": "cabelo úmido preso para trás sob uma tiara"
    },
    "eyes": "azuis",
    "body": {
      "type": "feminino curvilíneo",
      "proportions": "ampulheta natural"
    }
  },

  "scene": {
    "location": "banheira branca moderna em um banheiro aconchegante e com pouca luz",
    "time": "noite",
    "atmosphere": "várias velas quentes ao redor da banheira, luz suave e bruxuleante, vapor leve no ar"
  },

  "lighting_details": {
    "primary_light": "luz quente de velas vinda das laterais",
    "secondary_light": "brilho ambiente muito suave vindo de cima",
    "effect": "reflexos dourados na pele, suavidade nas sombras"
  },

  "camera_perspective": {
    "pov": "quadro de vídeo vertical da câmera frontal",
    "angle": "ângulo ligeiramente elevado para baixo",
    "framing": "pés suavemente visíveis no primeiro plano inferior, bolhas cobrindo o corpo apropriadamente, rosto no terço superior do quadro"
  },

  "subject": {
    "action": "relaxando em um banho de espuma quente, movendo suavemente os pés na água enquanto filma um vídeo aconchegante",
    "pose": {
      "legs": "estendidas naturalmente em direção à câmera",
      "expression": "sorriso calmo e relaxado, olhos serenos"
    },

    "details": {
      "bath": "bolhas brancas espessas cobrindo o peito e o corpo apropriadamente",
      "steam": "névoa sutil capturando a luz das velas",
      "water_effect": "ondulações suaves refletindo a luz quente"
    },

    "outfit": {
      "head_accessory": {
        "type": "tiara de sapo macia",
        "color": "verde brilhante",
        "details": "olhos de sapo fofos no topo, ligeiramente iluminados pela luz das velas"
      }
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310090459_ds7kvx_HBTEcfUaIAAWvZv.jpg" width="600" alt="Publicação em Mídias Sociais - Reel de Banho de Espuma Aconchegante à Luz de Velas - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [TumuAI](https://x.com/tumuaipromptx)
- **Fonte:** [Twitter Post](https://x.com/tumuaipromptx/status/2023458159692489047)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10258)**

---

### No. 26: Publicação em Mídias Sociais - Grade de Expressão de Personagens no Estilo Pixar

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para converter uma imagem em um personagem animado no estilo Pixar, gerando uma grade de 6 painéis mostrando o mesmo personagem com emoções diferentes (feliz, chocado, bravo, carinhoso, confiante, polegar para cima) contra fundos sólidos e coloridos, enfatizando a qualidade de renderização 3D suave.

#### 📝 Prompt

```
Menina animada em 3D no estilo Pixar, mostrada em uma grade de 6 painéis, a mesma personagem com cabelo castanho curto e olhos azuis grandes, diferentes emoções (feliz, chocada, brava, carinhosa, confiante, polegar para cima), fundos coloridos sólidos (amarelo, azul, vermelho, rosa, roxo, verde), iluminação de estúdio suave, renderização 3D suave, cores vibrantes, ultra detalhada, 4K, qualidade de filme de animação.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310086398_7f1k62_HBTBVIiawAA3BKI.jpg" width="600" alt="Publicação em Mídias Sociais - Grade de Expressão de Personagens no Estilo Pixar - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Edraak Tech | إدراك تِك](https://x.com/EdraakTechAi)
- **Fonte:** [Twitter Post](https://x.com/EdraakTechAi/status/2023454723849003368)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10250)**

---

### No. 27: Publicação em Mídias Sociais - Retrato de Konbini Japonês com Katana

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente técnico para gerar uma fotografia bruta e de alta fidelidade simulando uma captura de iPhone 17 Pro. Ele foca no bloqueio de identidade rigoroso (topografia facial, física do cabelo) baseado em uma imagem de referência (Imagem A). A cena é uma loja de conveniência japonesa (konbini) onde o sujeito, vestindo um uniforme escolar, está sentado e segurando uma katana, enfatizando o volume anatômico realista e a física das sombras.

#### 📝 Prompt

```
(vertical 9:16). Fotografia crua de alta fidelidade, simulação de iPhone 17 Pro, distância focal de 35mm, abertura f/2.8 para profundidade estrutural realista, granulação digital autêntica.

[Bloqueio de Assunto e Identidade]

Bloqueio de Identidade: Herança absoluta da topografia facial, coordenadas dos olhos amendoados e linha da mandíbula em formato de coração da Imagem A.

Física do Cabelo: herdada da Imagem A.

Biofidelidade: Física epidérmica, incluindo microporos visíveis nas bochechas, textura natural da pele e hidratação com acabamento acetinado.

Sincronização de Expressão: Bloqueio de Expressão - replicar o olhar pensativo para baixo e a tensão labial neutra da cena de referência.

[Roupa e Físico]

Descrição Técnica: Blusa profissional de algodão popeline branca com botões e pences estruturais padrão; gravata borboleta de seda listrada azul-marinho e branca; microssaia plissada xadrez azul-marinho de cintura alta.

Arquitetura Têxtil: Caimento natural do tecido e costura realista; dobras de material padrão na cintura e nos cotovelos.

Volume Anatômico: Proporções anatômicas naturais seguindo a geometria humana padrão e renderização física realista.

[Pose e Interação]

Geometria: Perfil sentado em um banco de madeira redondo; tronco inclinado em direção a um balcão de madeira.

Articulação: Ambas as mãos segurando uma katana no colo; articulação realista das juntas dos dedos e contato da pele com o objeto.

[Ambiente e Iluminação]

Atmosfera: Iluminação interna de fonte dupla; luzes fluorescentes frias no teto e luminárias pendentes quentes.

Integridade do Plano de Fundo: Ambiente de loja de conveniência japonesa (konbini) de alta fidelidade; prateleiras com embalagens coloridas de lanches e sinalização japonesa detalhada.

Física da Sombra: Sombras naturais traçadas por raios projetadas pelo sujeito no banco e no balcão; oclusão ambiente realista nas dobras do tecido.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310091532_wb813g_HBS7YH_bcAAW9WO.jpg" width="600" alt="Publicação em Mídias Sociais - Retrato de Konbini Japonês com Katana - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Danna R.](https://x.com/daaaaanc)
- **Fonte:** [Twitter Post](https://x.com/daaaaanc/status/2023448170085109983)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10260)**

---

### No. 28: Publicação em Mídias Sociais - Retrato de Praia Ultrarrealista com Anatomia Específica

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente explícito e técnico para gerar um retrato de praia ultrarrealista, cru e espontâneo. Ele exige a preservação rigorosa da textura natural da pele, da realidade anatômica e de proporções corporais específicas (especialmente volume e profundidade do busto) com base em uma imagem de referência. A modelo está agachada em pedras costeiras usando um biquíni de crochê verde sálvia sob a forte luz do sol diurna.

#### 📝 Prompt

```
{
"subject": "Uma jovem adulta com pele bronzeada, exibindo textura natural, poros e imperfeições sutis. Ela tem cabelos longos, lisos e castanhos escuros, soprando levemente para a direita. Ela está usando um biquíni de crochê verde sálvia claro, composto por um top triângulo e uma calcinha de amarrar nas laterais. Os acessórios incluem óculos de sol geométricos com aro dourado, esmalte branco e um piercing de umbigo de prata. Sua anatomia apresenta uma cintura fina, abdômen tonificado e um busto proeminente e cheio com volume natural significativo, projeção clara para frente e para fora, pesado e naturalmente afetado pela gravidade, com decote visível e uma profundidade de busto visivelmente maior do que a profundidade da caixa torácica. As proporções corporais são mantidas exatamente como na referência, sem normalização ou compressão.",
"pose": "Agachada assimetricamente em grandes rochas. A perna direita está dobrada com a coxa inclinada para frente. A perna esquerda está dobrada para fora. O tronco inclina-se ligeiramente para frente. O braço direito está direcionado para baixo, principalmente fora do quadro. O braço esquerdo está levantado, cotovelo para fora, a mão posicionada em seu rosto: o dedo médio está totalmente estendido apontando para cima, enquanto o dedo indicador repousa horizontalmente logo abaixo de seu nariz/área do lábio superior. Sua cabeça está ligeiramente inclinada para frente, mas olhando diretamente para a câmera. A curvatura exata da coluna, a inclinação dos ombros e o posicionamento dos membros são fixados na referência.",
"environment": "Um cenário de praia tropical brilhante. O primeiro plano consiste em grandes rochas costeiras cinza-marrons, ásperas e altamente texturizadas. O plano médio apresenta um oceano turquesa vibrante e claro que se estende até um horizonte reto e nítido. O fundo é um céu azul claro brilhante com nuvens finas e nebulosas espalhadas.",
"camera": "Orientação retrato, plano médio-completo. A perspectiva está no nível dos olhos ou ligeiramente elevada, capturando o sujeito e o ambiente com forte profundidade tridimensional. A distância e o ângulo da câmera preservam estritamente o volume físico e a profundidade do sujeito, sem qualquer distorção de grande angular, compressão ou enquadramento estilo selfie/espelho.",
"lighting": "Luz solar diurna brilhante, direta e forte vinda de cima e ligeiramente para a direita. A iluminação cria sombras fortes e nítidas no corpo (sob o queixo, braços e sombras profundas entre os seios) e nas rochas. Dispersão subsuperficial realista na pele, sem suavização artificial ou filtros de beleza.",
"mood_and_expression": "Brincalhona, atrevida, energética e irreverente. Ela tem um sorriso/risada de boca aberta, mostrando os dentes, com o olhar direcionado diretamente para a câmera através das lentes coloridas de seus óculos de sol.",
"style_and_realism": "Fotografia digital ultrarrealista, crua e espontânea. Precisão física absoluta em relação à imagem de referência. Zero estilização, retoque ou média de proporções. Preserva a realidade anatômica exata, o comportamento natural da pele e os microdetalhes.",
"colors_and_tone": "Cores quentes, altamente saturadas e vibrantes. Tons de pele bronzeados em marrom-dourado profundo, biquíni verde sálvia claro, ciano/turquesa marcante"
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310091989_kax1qh_HBSqUcxWUAAph0s.jpg" width="600" alt="Publicação em Mídias Sociais - Retrato de Praia Ultrarrealista com Anatomia Específica - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [brindley](https://x.com/brindleyai)
- **Fonte:** [Twitter Post](https://x.com/brindleyai/status/2023429421005156755)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10261)**

---

### No. 29: Publicação em Mídias Sociais - Retrato de estúdio de Sydney Sweeney em jeans azul

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente estruturado para gerar um retrato de estúdio hiper-realista de Sydney Sweeney usando um top azul claro e jeans, com foco em preservar sua identidade, características faciais detalhadas, iluminação de estúdio profissional e qualidade de editorial de revista.

#### 📝 Prompt

```
{
  "image_prompt": {
    "subject": {
      "identity": "{argument name=\"identity\" default=\"Sydney Sweeney\"}",
      "face": "Rosto altamente detalhado de Sydney Sweeney, olhando diretamente para a câmera com um sorriso suave, natural e de boca fechada. Maquiagem sutil e iluminada, lábios rosa-nude, cílios definidos e sombra suave.",
      "hair": "Cabelo loiro longo, volumoso e ondulado, com risca central e caindo sobre ambos os ombros."
    },
    "wardrobe": {
      "top": "Blusa justa, azul-clara, canelada, sem mangas e com gola alta (estilo frente única/regata).",
      "bottoms": "Calça jeans clássica de lavagem média, cintura alta, com botão prateado visível e estilo padrão de cinco bolsos."
    },
    "accessories": {
      "earrings": "Brincos dourados grandes e pendurados.",
      "necklace": "Colar de corrente dourada fina e delicada.",
      "bracelet": "Pulseira de elos grossos dourados no pulso esquerdo."
    },
    "pose_and_composition": {
      "pose": "Retrato em pé. A modelo está levemente inclinada com o antebraço direito apoiado em um bloco de acrílico transparente e claro. O braço esquerdo está relaxado ao lado do corpo.",
      "camera_angle": "Retrato de médio comprimento, na altura dos olhos, da cintura para cima."
    },
    "environment": {
      "background": "Cenário de estúdio limpo e sem emendas, apresentando um gradiente sutil de cinza escuro a marrom-quente, ligeiramente mais claro diretamente atrás da modelo.",
      "lighting": "Iluminação de estúdio profissional. Iluminação suave, difusa e uniforme que realça lindamente as características faciais, enquanto projeta sombras suaves e naturais no fundo e nas roupas."
    },
    "technical_specifications": {
      "resolution": "Resolução 4k, foto HD",
      "aspect_ratio": "9:16",
      "style": "Fotografia de retrato hiper-realista, fotorrealista, iluminação cinematográfica, ultra-detalhada, foco nítido, qualidade editorial de revista."
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310073834_jugn7b_HBSi7PubIAA7AiX.jpg" width="600" alt="Publicação em Mídias Sociais - Retrato de estúdio de Sydney Sweeney em jeans azul - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Serrah ❀](https://x.com/Serreh131306)
- **Fonte:** [Twitter Post](https://x.com/Serreh131306/status/2023421275658764481)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10227)**

---

### No. 30: Publicação em Mídias Sociais - Elon Musk em um Ônibus Urbano Turco (Realismo Documental)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente específico, projetado para gerar uma imagem ultrarrealista, em estilo documentário, simulando uma captura de iPhone 15 Pro. A cena retrata um homem de meia-idade (parecido com Elon Musk) em um ônibus urbano público lotado na Turquia durante o trajeto matinal, enfatizando a textura natural da pele, a fadiga sutil e a iluminação realista para criar uma atmosfera de classe trabalhadora.

#### 📝 Prompt

```
{
  "meta": {
    "style": "ultrarrealista, realismo documental",
    "resolution": "8k",
    "aspect_ratio": "9:16",
    "camera": "iPhone 15 Pro",
    "lens": "26mm",
    "lighting": "luz natural da manhã através das janelas do ônibus",
    "quality": "alto detalhe, realismo cinematográfico"
  },
  "subject": {
    "description": "Um homem de meia-idade com pele clara, cabelo castanho escuro curto e ligeiramente despenteado, olhos claros, linhas de expressão sutis e maçãs do rosto definidas.",
    "expression": "expressão matinal cansada, mas calma e ligeiramente pensativa",
    "clothing": "jaqueta escura acessível, camisa de botão simples ligeiramente amassada, roupa modesta do dia a dia",
    "details": "cansaço muito sutil sob os olhos, textura natural da pele, poros realistas, sem estilo glamoroso"
  },
  "scene": {
    "location": "ônibus público na Turquia durante o trajeto matinal",
    "environment": "interior de ônibus lotado, corrimãos amarelos, assentos de tecido, pessoas em pé, janelas ligeiramente embaçadas",
    "time": "início da manhã",
    "weather": "luz suave do dia, ligeiramente nublado",
    "mood": "atmosfera realista de trajeto matinal da classe trabalhadora"
  },
  "composition": {
    "angle": "foto espontânea ao nível dos olhos de alguém sentado em frente",
    "framing": "formato vertical para redes sociais, parte superior do corpo visível",
    "focus": "foco nítido no sujeito, passageiros no fundo ligeiramente borrados",
    "depth_of_field": "baixa profundidade de campo"
  },
  "realism_boost": {
    "skin_texture": "textura da pele natural altamente detalhada",
    "imperfections": "pequena assimetria facial, rugas naturais, fadiga matinal sutil",
    "motion": "leve desfoque de movimento fora da janela do ônibus",
    "color_grading": "tons neutros suaves, luz matinal turca realista"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310088678_5uofj7_HBSZuP5bcAA57Ap.jpg" width="600" alt="Publicação em Mídias Sociais - Elon Musk em um Ônibus Urbano Turco (Realismo Documental) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [TumuAI](https://x.com/tumuaipromptx)
- **Fonte:** [Twitter Post](https://x.com/tumuaipromptx/status/2023411353336086571)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10254)**

---

### No. 31: Publicação em Mídias Sociais - Selfie Glamorosa no Espelho em Interior de Luxo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt estruturado para gerar uma selfie no espelho ultrarrealista de uma mulher loira glamorosa em um interior clássico luxuoso, vestindo renda dourada intrincada e uma saia metálica, enfatizando a luz solar natural suave e uma estética de editorial de moda de alta qualidade.

#### 📝 Prompt

```
{
  "model": "gpt-image-1",
  "prompt": "Selfie ultra-realista no espelho de uma mulher loira glamorosa em um interior clássico luxuoso com paredes brancas com painéis, uma lareira de mármore, uma pintura antiga emoldurada e uma mesa de centro de vidro. Ela está usando um espartilho de renda dourada intrincado com bordados florais e uma minissaia drapeada dourada metálica. Luz solar natural suave vindo da lateral, brilho quente na pele, estética elegante de alta qualidade, texturas detalhadas, foco nítido, estilo editorial de moda de luxo, 4k, fotorrealista, sombras suaves, profundidade de campo rasa.",
  "size": "1024x1024"
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310072781_1jf6hl_HBSSRqzbsAAL1Ss.jpg" width="600" alt="Publicação em Mídias Sociais - Selfie Glamorosa no Espelho em Interior de Luxo - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310073245_gtvcrs_HBSSRq6bsAE5k1J.jpg" width="600" alt="Publicação em Mídias Sociais - Selfie Glamorosa no Espelho em Interior de Luxo - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Dockie](https://x.com/Document195)
- **Fonte:** [Twitter Post](https://x.com/Document195/status/2023402977848177021)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10226)**

---

### No. 32: Publicação em Mídias Sociais - Grade de Expressões de Fotos de Estúdio com Tiara da Minnie

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt detalhado para gerar uma colagem vertical fotorrealista 2x2 de uma jovem em um estúdio. Ele especifica textura de pele natural, maquiagem leve, um bralette de veludo azul royal e uma tiara estilo Minnie, mostrando quatro expressões distintas (piscada, surpresa, bico, confiante) na grade.

#### 📝 Prompt

```
Foto de estúdio fotorrealista de uma jovem esguia na casa dos 20 anos, com pele bege quente clara a média e textura natural suave. Ela tem um rosto oval suave, maçãs do rosto definidas, mandíbula suave, nariz reto médio-pequeno, lábios rosados naturais médios-cheios e olhos castanhos amendoados com sobrancelhas escuras suavemente arqueadas. A maquiagem é leve e natural, com rímel sutil, blush suave e lábios neutros. Seu cabelo é castanho médio na altura dos ombros com mechas douradas quentes, repartido ao meio, levemente ondulado e natural.
Ela veste um sutiã bralette triangular de veludo azul royal com alças finas bege, brincos prateados pendurados e uma tiara estilo Minnie com orelhas redondas pretas e um laço vermelho com bolinhas brancas. O fundo é um cenário de estúdio cinza claro limpo com iluminação suave e difusa e sombras mínimas para um visual de moda brilhante.
A imagem é uma colagem vertical 2x2 (proporção 4:5), enquadramento médio-próximo, câmera no nível dos olhos, sujeito centralizado.
Expressões em cada painel:
piscada brincalhona com um sorriso largo mostrando os dentes, uma mão perto da boca
rosto surpreso com olhos arregalados, boca aberta, ambas as mãos nas bochechas
rosto emburrado/irritado com as sobrancelhas levemente franzidas, bochechas apoiadas nas palmas das mãos
olhar sério e confiante com lábios neutros, ambos os braços levantados e mãos atrás da cabeça ajustando o cabelo.
Alta resolução, foco nítido, textura detalhada da pele e do tecido, cores naturais.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310090555_k1jlb4_HBSR7XMa8AIOn0_.jpg" width="600" alt="Publicação em Mídias Sociais - Grade de Expressões de Fotos de Estúdio com Tiara da Minnie - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [sammy](https://x.com/sumiturkude007)
- **Fonte:** [Twitter Post](https://x.com/sumiturkude007/status/2023402596011298986)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10257)**

---

### No. 33: Publicação em Mídias Sociais - Retrato Surreal de Zendaya: Elegância Entomológica

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON extremamente detalhado para gerar um retrato surreal hiper-realista e macro-cinemático (estilo Zendaya). O rosto do sujeito está parcialmente obscurecido por um enxame de insetos de obsidiana em tons de joia em uma caótica Oficina Vitoriana de Entomologia. Ele especifica iluminação dramática de Chiaroscuro, fidelidade microscópica (Phase One XF IQ4) e o grão orgânico e granulado do filme Kodak Tri-X 400.

#### 📝 Prompt

```
{
  "vibe_title_en": "Elegância Entomológica",
  "master_prompt": "Um retrato hiper-realista e macro-cinemático de O(A) Protagonista, situado(a) em uma caótica oficina vitoriana de entomologia, repleta de poeira. O rosto do(a) sujeito(a) está artisticamente parcialmente obscurecido por um enxame de aracnídeos e besouros de obsidiana, em tons de joia e hiperdetalhados, rastejando delicadamente sobre a textura da pele, imitando um véu vivo. O ambiente é incrivelmente movimentado e claustrofóbico, repleto de prateleiras com potes de boticário antigos, espécimes de borboletas alfinetadas, ferramentas de latão espalhadas, manuscritos botânicos em decomposição e gavetas de madeira transbordando. A iluminação é um dramático Chiaroscuro, utilizando uma única luz principal fria para capturar o brilho nas carapaças dos insetos e os óleos naturais da pele do(a) sujeito(a), enquanto a desordem do fundo se desvanece em sombras profundas e texturizadas. Filmado com uma Phase One XF IQ4 150MP e uma lente Macro de 120mm para fidelidade microscópica, renderizado com o grão áspero e orgânico de um filme Kodak Tri-X 400 forçado. Sem neon, apenas poeira, sombra e textura orgânica.",
  "meta": {
    "intent": "Moda Editorial / Retrato Surrealista",
    "priorities": "Fidelidade de Textura, Realismo Surreal, Densidade Atmosférica",
    "device_profile": "Phase One XF IQ4 150MP"
  },
  "frame": {
    "aspect": "4:5",
    "composition": "Close-up Extremo (Foco Macro)",
    "layout": "Sujeito Centralizado com Desordem Periférica Densa",
    "camera_angle": "Nível dos Olhos",
    "tilt_roll_degrees": "0°"
  },
  "subject": {
    "gender": "Feminino",
    "identity": "O(A) Protagonista",
    "demographics": "Jovem Adulto(a), etnicamente ambíguo(a)",
    "face": "Textura de pele impecável visível sob a sobreposição surreal de insetos, maçãs do rosto marcadas",
    "hair": "Penteado para trás ou preso para focar no rosto e nos insetos",
    "body": "Ombros visíveis, tensão nos músculos do pescoço",
    "expression": "Estóico(a), intenso(a), olhar fixo e sem piscar diretamente para a lente",
    "pose": "Estático(a), congelado(a) em um momento de simbiose com as criaturas"
  },
  "wardrobe_accessories": {
    "garments": [
      {
        "item": "Blusa de gola alta",
        "material": "Renda Antiga / Seda",
        "color": "Carvão ou Preto Profundo",
        "fit": "Ajustado, silhueta vitoriana"
      }
    ],
    "accessories": []
  },
  "environment": {
    "setting": "Oficina Vitoriana de Entomologia / Laboratório de Taxidermia",
    "surfaces": "Madeira envelhecida, potes de vidro, metal de latão, partículas de poeira",
    "depth": "Profundidade de campo rasa, o fundo é um borrão de desordem",
    "atmosphere": "Ar estagnado, cheiro de papel velho e fluidos preservativos, empoeirado",
    "lens_interaction": "Foco nítido nos olhos e insetos, bokeh pesado nas prateleiras do fundo"
  },
  "lighting": {
    "key": "Luz direcional dura e fria (Luz da Lua ou Lâmpada de Laboratório)",
    "fill": "Preenchimento negativo (sombras profundas)",
    "rim": "Luz de borda sutil nos insetos",
    "shadows": "Pretos esmagados, alto contraste",
    "color_temperature": "Frio / Dessaturado (5500K)",
    "sensor_fla": ""
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310088045_sxu26a_HBR-2K_WEAAMjF4.jpg" width="600" alt="Publicação em Mídias Sociais - Retrato Surreal de Zendaya: Elegância Entomológica - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310088138_012za0_HBR-2MYWgAAO9FX.jpg" width="600" alt="Publicação em Mídias Sociais - Retrato Surreal de Zendaya: Elegância Entomológica - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [timedoctor.eth](https://x.com/timedoctor_nft)
- **Fonte:** [Twitter Post](https://x.com/timedoctor_nft/status/2023381605968916619)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10253)**

---

### No. 34: Infográfico / Edu Visual - Cena da Trilha Ho Chi Minh na Guerra do Vietnã - Prompt

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt de geração de imagem 3D hiper-realista para Nano Banana Pro descrevendo uma seção da Trilha Ho Chi Minh ao anoitecer. Ele foca no ambiente de selva densa, luz filtrada, uma bicicleta escondida, uma entrada de túnel camuflada e uma atmosfera úmida e envolvente.

#### 📝 Prompt

```
Uma vista 3D hiper-realista de uma seção da Trilha Ho Chi Minh, nas profundezas das montanhas Truong Son, ao anoitecer. A densa selva de dossel triplo filtra a luz que se esvai em uma penumbra de verdes profundos e índigos. Uma trilha estreita e batida serpenteia por entre folhas gigantes de samambaias e antigas árvores de teca. Em primeiro plano, uma bicicleta reforçada e pesadamente carregada está encostada em uma rocha musgosa, meio escondida pela folhagem. Uma entrada de túnel oculta é mal visível sob um emaranhado de raízes. A atmosfera é pesada com umidade, a névoa subindo do chão da floresta, capturando a resistência silenciosa e oculta da rede logística.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223974185_mdkzha_HBLDqEVbsAAak3c.jpg" width="600" alt="Infográfico / Edu Visual - Cena da Trilha Ho Chi Minh na Guerra do Vietnã - Prompt - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Jimi Plouffe](https://x.com/jimiplouffe)
- **Fonte:** [Twitter Post](https://x.com/jimiplouffe/status/2022894315496681659)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10191)**

---

### No. 35: Infográfico / Edu Visual - Prompt da Seção Arquitetônica de Evolução de Mangá

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt estruturado projetado para gerar uma imagem que retrata a "Evolução do Mangá" como uma seção arquitetônica detalhada, mostrando quatro estratos empilhados representando diferentes fases, completos com artefatos representativos e transições educacionais, renderizados com realismo arquitetônico.

#### 📝 Prompt

```
Evolução do Mangá --> <LAYOUT> Um único bloco robusto (como um corte de museu) fatiado para revelar 4 andares/estratos empilhados. Cada nível representa uma era/estágio/versão inferida do INPUT. Lado direito: uma barra de legenda vertical com datas/rótulos de período inferidos pelo modelo. </LAYOUT>
<INFER_AND_RENDER> Inferir 4 fases principais e representar cada uma com artefatos, ferramentas e ambientes representativos. Manter as transições educativas: mostrar o que mudou entre os níveis (materiais, escala, método). </INFER_AND_RENDER>
<STYLE_NOTES> Realismo de seção arquitetônica: espessura visível, vergalhões/fixadores se aplicável, detritos realistas na borda do corte. </STYLE_NOTES>
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050435772_gwth03_HA2ZyjGaAAI9SI-.jpg" width="600" alt="Infográfico / Edu Visual - Prompt da Seção Arquitetônica de Evolução de Mangá - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050436487_o2ug9k_HA2Zv_zWgAA9rEr.jpg" width="600" alt="Infográfico / Edu Visual - Prompt da Seção Arquitetônica de Evolução de Mangá - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Gadgetify](https://x.com/Gdgtify)
- **Fonte:** [Twitter Post](https://x.com/Gdgtify/status/2022422529038811247)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9974)**

---

### No. 36: Infográfico / Edu Visual - Esboço de headset VR inspirado em Dieter Rams

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um esboço detalhado, desenhado à mão a lápis, de um headset de VR futurista e minimalista, inspirado nos designs da Braun de Dieter Rams, focando em linhas limpas, detalhes funcionais como perfurações e sombreamento leve em um estilo de desenho técnico.

#### 📝 Prompt

```
Esboço detalhado a lápis, feito à mão, de um headset de VR futurista e minimalista, inspirado nos designs Braun de Dieter Rams, com linhas limpas e funcionais, sem detalhes desnecessários. Headset fosco branco de perfil baixo com visor retangular suavemente curvado, a parte frontal apresenta uma grade precisa de pequenas perfurações circulares (pontos) para ventilação e estética do alto-falante. Uma alça superior diagonal fina cruza de um lado para o outro em um ângulo para um ajuste ergonômico, integrada perfeitamente. Seção traseira com almofadas macias visíveis na parte de trás da área da cabeça para conforto. Vistas de perfil simples e três quartos mostradas, sombreamento leve para profundidade, hachuras sutis para materiais, estilo de desenho técnico em papel branco, preciso, mas discreto, esboço de conceito de design industrial.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050457581_1e3cjp_HBDZ5bubcAATLBr.jpg" width="600" alt="Infográfico / Edu Visual - Esboço de headset VR inspirado em Dieter Rams - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050457912_0u2tqa_HBDZ5rSakAMKS6a.jpg" width="600" alt="Infográfico / Edu Visual - Esboço de headset VR inspirado em Dieter Rams - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Carolina Delgado](https://x.com/carolletta)
- **Fonte:** [Twitter Post](https://x.com/carolletta/status/2022355821057958168)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10012)**

---

### No. 37: Infográfico / Edu Visual - Planta Baixa Arquitetônica como Mundo em Miniatura

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt complexo para gerar uma imagem que visualize uma planta arquitetônica espalhada sobre uma prancheta, onde os espaços se elevam em cômodos em miniatura habitáveis, mostrando momentos humanos e detalhes técnicos como HVAC e padrões de circulação, mesclando a planta e o modelo 3D simultaneamente.

#### 📝 Prompt

```
Uma planta arquitetônica de {BUILDING_TYPE} espalhada sobre uma prancheta, com os espaços se elevando em uma miniatura habitável. {ROOM_1} emerge com {FURNITURE_1} e {ACTIVITY_1} em andamento, {ROOM_2} se eleva com {DESIGN_ELEMENT} e {HUMAN_MOMENT}, {ROOM_3} surge com {DETAIL_1} e {LIGHTING_1}. As paredes existem como linhas e divisórias reais simultaneamente. As linhas de visão marcadas na planta se tornam vistas reais entre os espaços. Os sistemas mecânicos na planta — HVAC, encanamento, elétrica — pulsam com função invisível. Padrões de circulação humana aparecem como rastros de movimento fantasmagóricos. Figuras em escala arquitetônica se tornam pequenos habitantes reais vivendo suas pequenas vidas. Cortes de seção revelam relações verticais. As ferramentas do arquiteto cercam: escalas, lápis, papel vegetal. Luz dourada de estúdio de design, a planta como promessa e prova, 8K, arquitetura como recipiente de vida.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050449884_hcov06_HBDTYb-XMAARwNo.jpg" width="600" alt="Infográfico / Edu Visual - Planta Baixa Arquitetônica como Mundo em Miniatura - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050450035_0tk9cf_HBDTKRpWgAckB5A.jpg" width="600" alt="Infográfico / Edu Visual - Planta Baixa Arquitetônica como Mundo em Miniatura - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050449999_p2fyx6_HBDTP0lWgAUbyLE.jpg" width="600" alt="Infográfico / Edu Visual - Planta Baixa Arquitetônica como Mundo em Miniatura - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050450755_121dzn_HBDTgAfW0AAIK12.jpg" width="600" alt="Infográfico / Edu Visual - Planta Baixa Arquitetônica como Mundo em Miniatura - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Alexandra Aisling](https://x.com/AllaAisling)
- **Fonte:** [Twitter Post](https://x.com/AllaAisling/status/2022353962385744076)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10000)**

---

### No. 38: Infográfico / Edu Visual - Comparação Arquitetônica Lado a Lado da Hagia Sophia

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON projetado para gerar uma imagem lado a lado comparando a Hagia Sophia, apresentando um esboço arquitetônico técnico à esquerda e uma fotografia de alta resolução do mundo real à direita, adequado para uso educacional ou em exposições de arquitetura.

#### 📝 Prompt

```
{
  "objective": "Criar uma comparação visual lado a lado da Hagia Sophia, apresentando um esboço arquitetônico técnico e uma fotografia da vida real",
  "image_specifications": {
    "style": "Mídia mista (Desenho arquitetônico + Fotografia real)",
    "layout": "Divisão horizontal em 2 partes",
    "aspect_ratio": "3:2"
  },
  "left_side": {
    "content_type": "Esboço técnico ou planta baixa da Maravilha do Mundo selecionada",
    "features": [
      "Proporções estruturais precisas",
      "Profundidade das dimensões rotuladas",
      "Vistas de elevação arquitetônica ou cortes",
      "Anotações de texto no idioma nativo ou inglês"
    ],
    "text_annotations": {
      "units": "Métrico ou imperial, com base na região",
      "details": [
        "Fases de construção",
        "Notas de material",
        "Rótulos arquitetônicos"
      ],
      "font_style": "Texto estilo engenharia ou planta baixa"
    },
    "visual_style": "Monocromático, arte linear ou planta baixa sépia",
    "positioning": "Metade esquerda da imagem"
  },
  "right_side": {
    "content_type": "Imagem de alta resolução do mundo real da Maravilha do Mundo selecionada",
    "features": [
      "Vista grande angular ou perspectiva frontal",
      "Iluminação natural ou ambiente",
      "Foto colorida com contexto ambiental circundante"
    ],
    "positioning": "Metade direita da imagem"
  },
  "visual_elements": {
    "border_division": "Divisão vertical limpa ou transição mesclada",
    "comparison_focus": "Contraste entre o conceito de design e o resultado no mundo real"
  },
  "output_format": {
    "type": "Imagem",
    "high_resolution": true,
    "use_case": [
      "Pôster educacional",
      "Vitrine arquitetônica",
      "Guia turístico",
      "Série de infográficos"
    ]
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964557847_jd2hsg_HA-Ca1MXoAA7ztD.jpg" width="600" alt="Infográfico / Edu Visual - Comparação Arquitetônica Lado a Lado da Hagia Sophia - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Keskin](https://x.com/craftian_keskin)
- **Fonte:** [Twitter Post](https://x.com/craftian_keskin/status/2021979052333015291)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9905)**

---

### No. 39: Infográfico / Edu Visual - Geração Aleatória de Grade de Produtos Estranhos

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um modelo de prompt simples para gerar uma grade 2x2 de produtos aleatórios e estranhos de um ano e estilo especificados, com rótulos de texto abaixo descrevendo o que são os produtos.

#### 📝 Prompt

```
2 x 2 de produtos aleatórios e estranhos {argument name="Year" default="[Year]"} {argument name="style" default="[style]"} com o que eles são por baixo em texto
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964563693_155ark_HA5FB5xbsAQJO03.jpg" width="600" alt="Infográfico / Edu Visual - Geração Aleatória de Grade de Produtos Estranhos - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Captain HaHaa](https://x.com/CaptainHaHaa)
- **Fonte:** [Twitter Post](https://x.com/CaptainHaHaa/status/2021635010600792502)
- **Publicado:** 11 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9823)**

---

### No. 40: Infográfico / Edu Visual - Infográfico de Engenharia Cinematográfica do USS Abraham Lincoln

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt JSON altamente detalhado e estruturado para gerar um infográfico cinematográfico no estilo de engenharia industrial do porta-aviões USS Abraham Lincoln. Ele especifica elementos técnicos como linhas de dimensão, seções transversais e vistas explodidas, misturando realismo cinematográfico com documentação técnica militar profissional.

#### 📝 Prompt

```
{
  "prompt": {
    "subject": "{argument name=\"ship name\" default=\"USS Abraham Lincoln (CVN-72)\"}",
    "description": "Infográfico cinematográfico em estilo de engenharia industrial do USS Abraham Lincoln (CVN-72) no mar, correspondendo à foto de referência. Renderização técnica ultraprecisa do porta-aviões visto de uma perspectiva angular dinâmica com proporções exatas, marcações de convés, texturas de superfície e realismo estrutural idênticos à referência.",
    "technical_elements": {
      "dimension_lines": ["comprimento total", "largura do convés de voo", "profundidade do casco", "calado", "altura da torre da ilha"],
      "cross_section": ["estrutura do convés de voo", "baía do hangar", "elevadores de aeronaves", "reatores nucleares", "salas de máquinas", "compartimentos da tripulação", "radar e centro de comando"],
      "exploded_view": ["elevadores de aeronaves", "conjuntos de radar", "sistemas de catapulta", "equipamento de parada", "eixos de propulsão", "estrutura interna"],
      "dynamic_diagrams": ["vetores de lançamento de aeronaves", "setas de movimento do navio", "fluxo hidrodinâmico ao redor do casco", "dissipação de calor dos reatores"],
      "materials": ["aço naval de alta resistência", "materiais compósitos para convés", "ligas reforçadas", "revestimentos protetores"],
      "manufacturing_processes": ["montagem modular de navios", "soldagem de precisão", "forjamento de aço", "aplicação de revestimento"],
      "part_numbering": "Estilo de anotação naval industrial (Peça N01, N02, etc)",
      "tech_data_panels": ["deslocamento", "velocidade máxima", "capacidade da tripulação", "capacidade de aeronaves", "tipo de reator", "alcance operacional"],
      "industrial_design_elements": ["bloco de dados navais estilo QR", "faixa de código de barras", "esquemáticos microtécnicos"]
    },
    "design_style": {
      "layout": "infográfico cinematográfico em camadas com o porta-aviões como herói central e chamadas técnicas ao redor",
      "color_palette": ["cinza naval", "azul oceano profundo", "branco", "detalhes em laranja de sinalização"],
      "background": "oceano aberto desvanecendo-se no horizonte com uma sutil sobreposição de grade de projeto",
      "typeface": "sans-serif industrial nítida com estilo de anotação de engenharia naval",
      "lighting": "iluminação direcional dramática com realces nítidos no convés de voo",
      "shadows": "controladas e nítidas para clareza técnica"
    },
    "overall_vibe": "pôster épico de engenharia naval misturando realismo cinematográfico com documentação técnica militar profissional",
    "aspect_ratio": "9:16"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792192416_h535l7_HAzUkSmW0AEDzVa.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico de Engenharia Cinematográfica do USS Abraham Lincoln - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792192441_gvm90o_HAzUkUwXYAEVpyL.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico de Engenharia Cinematográfica do USS Abraham Lincoln - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Gilbert Odera | Your AI Plug™🇰🇪](https://x.com/yourPlugAI)
- **Fonte:** [Twitter Post](https://x.com/yourPlugAI/status/2021224075683664254)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9694)**

---

### No. 41: Infográfico / Edu Visual - Infográfico de Comida Cinematográfica com Ingredientes Flutuantes

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar fotografia de alimentos cinematográfica ultrarrealista de um prato tradicional (sopa de charutos de folha de uva com almôndegas). Apresenta ingredientes flutuando acima do prato em um layout organizado, combinado com linhas e rótulos infográficos sutis, estilizado para uma estética de livro de receitas premium ou educação alimentar.

#### 📝 Prompt

```
Fotografia cinematográfica ultrarrealista de um prato tradicional, apresentado em uma mesa de madeira rústica. Prato finalizado em primeiro plano, charutos de folha de uva e sopa com almôndegas, com vapor subindo naturalmente. Ingredientes flutuando acima do prato em um layout limpo e organizado: ervas frescas, arroz, carne moída, cebola, especiarias, azeite, batata, grão de bico, açafrão, cada ingrediente isolado e claramente visível. Linhas infográficas curvas sutis e rótulos mínimos apontando para cada ingrediente. Iluminação de estúdio quente com sombras suaves, profundidade de campo rasa, paleta de cores terrosas, estilo de livro de receitas premium e educação alimentar. Texturas hiperdetalhadas, superfícies de alimentos realistas, infográfico culinário editorial, fotorrealista, ultradetalhado, qualidade 8K.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792190873_lyxmit_HAx7ilWaAAYrKbW.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico de Comida Cinematográfica com Ingredientes Flutuantes - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792190870_fs93pc_HAx7ip5aAAE2MIb.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico de Comida Cinematográfica com Ingredientes Flutuantes - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Taaruk](https://x.com/Taaruk_)
- **Fonte:** [Twitter Post](https://x.com/Taaruk_/status/2021126176786600044)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9690)**

---

### No. 42: Infográfico / Edu Visual - Prompt de Objeto Bruto para Projeto de Fábrica

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt desenvolvido para o Gemini Nano Banana Pro visualizar precisão, transformando um conceito de objeto bruto em uma visualização de projeto de nível de fábrica.

#### 📝 Prompt

```
Do objeto bruto ao projeto de nível industrial
Precisão visualizada com Gemini Nano Banana Pro em @lovart_ai
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792193680_lno75s_HAxTzJ3agAAFm4H.jpg" width="600" alt="Infográfico / Edu Visual - Prompt de Objeto Bruto para Projeto de Fábrica - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [𝐌](https://x.com/Strength04_X)
- **Fonte:** [Twitter Post](https://x.com/Strength04_X/status/2021082486294675765)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9696)**

---

### No. 43: Infográfico / Edu Visual - Prompt para Gerador de Infográficos Árabes Hiper-Realistas

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt JSON altamente estruturado e detalhado, projetado para o modelo Gemini Nano Banana Pro, para gerar um infográfico hiper-realista de um prato com tema árabe. Ele especifica o ambiente, a iluminação, a composição visual, elementos dinâmicos como ingredientes levitando e anotações de design gráfico em indonésio, visando um visual de fotografia macro cinematográfica de alta fidelidade.

#### 📝 Prompt

```
{
  "request_type": "HyperRealistic_Infographic_Generator",
  "environment_config": {
    "cuisine_theme": "{argument name=\"cuisine theme\" default=\"Arabic\"}",
    "background_surface": "Rustic_Aged_Wood",
    "lighting_model": "Cinematic_Studio_Warm",
    "atmosphere_effects": ["High_Density_Steam", "Motion_Freeze_Action"]
  },
  "visual_composition": {
    "anchor_element": {
      "object": "Traditional_Middle_Eastern_Ceramic_Bowl",
      "state": "Steaming_Hot_Platter",
      "position": "Bottom_Center"
    },
    "dynamic_elements": {
      "arrangement": "Vertical_Levitation_Gravity_Defying",
      "ingredients": [
        "{argument name=\"main ingredient\" default=\"Slow_Cooked_Shredded_Lamb\"}",
        "Crispy_Tofu_Cubes",
        "Viscous_Glossy_Tomato_Sauce_Splashes",
        "Fresh_Cilantro_and_Mint_Sprigs",
        "Whole_Red_and_Green_Chilies",
        "Symmetrical_Lime_Slices",
        "Whole_Garlic_Bulbs_and_Cloves",
        "Golden_Fried_Shallots"
      ]
    }
  },
  "graphic_design_layer": {
    "annotation_style": "Editorial_Magazine_Infographic",
    "language": "Indonesian",
    "typography": {
      "font_weight": "Bold_Clean_Sans",
      "connector_lines": "Thin_White_Minimalist"
    },
    "labels": [
      "Tender Meat",
      "Crispy Fried Tofu",
      "Sauce Splashes",
      "Fresh Herbs",
      "Chili",
      "Lime",
      "Garlic",
      "Fried Shallots"
    ]
  },
  "technical_output_specs": {
    "camera_settings": "Shallow_Depth_of_Field_Macro",
    "texture_detail": "8K_Ultra_Detailed_PBR",
    "rendering_engine": "DSLR_Look_High_Fidelity"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792215702_3p6s0k_HAxC6upaAAAAWq-.jpg" width="600" alt="Infográfico / Edu Visual - Prompt para Gerador de Infográficos Árabes Hiper-Realistas - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Meem](https://x.com/mehvishs25)
- **Fonte:** [Twitter Post](https://x.com/mehvishs25/status/2021063922938462584)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9743)**

---

### No. 44: Infográfico / Edu Visual - Infográfico sobre a Produção de Cerveja da Abadia Trapista

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um infográfico de alta qualidade que explique o processo de fabricação de cerveja em uma Abadia Trapista, exigindo ilustrações ricas para acompanhar o texto.

#### 📝 Prompt

```
Gerar um infográfico de alta qualidade explicando a produção de cerveja em uma Abadia Trapista com ilustrações ricas.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706149209_yqfh2m_HAuo5WZWMAAUfAn.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico sobre a Produção de Cerveja da Abadia Trapista - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706149032_hwmcx2_HAuoDPoWsAE8VJQ.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico sobre a Produção de Cerveja da Abadia Trapista - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706148945_b9ds6n_HAuo3vvbUAAOHq-.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico sobre a Produção de Cerveja da Abadia Trapista - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706150838_lm3k51_HAuo6RBaoAETy-f.jpg" width="600" alt="Infográfico / Edu Visual - Infográfico sobre a Produção de Cerveja da Abadia Trapista - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Creative Diffusion FR](https://x.com/StableTom)
- **Fonte:** [Twitter Post](https://x.com/StableTom/status/2020894599175164284)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9535)**

---

### No. 45: Infográfico / Edu Visual - Prompt de Criação de Ativos e Correspondência de Estilo do Canva

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt usado para gerar ativos numerados ausentes (11 e 12) para um design do Canva, garantindo que a IA corresponda ao estilo, textura e cor dos ativos existentes (1-10) fornecidos como imagem de referência.

#### 📝 Prompt

```
Preciso dos números de 1 a 12 para um design de {argument name="theme" default="12 Signos do Zodíaco"}, mas só tenho recursos de 0 a 10. Com base nesta imagem, crie 11 e 12.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706248514_jfrust_HAt_g9XakAA4dkw.jpg" width="600" alt="Infográfico / Edu Visual - Prompt de Criação de Ativos e Correspondência de Estilo do Canva - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [かい@デザイナー,Shopifyパートナー](https://x.com/kai_toyohashi)
- **Fonte:** [Twitter Post](https://x.com/kai_toyohashi/status/2020849080457658696)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9659)**

---

### No. 46: Infográfico / Edu Visual - Vista Microscópica Abstrata da Crema de Café Viva

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma fotografia macro abstrata e surreal da crema do café, retratando-a como uma substância viva com delicadas gavinhas brilhantes e redes fractais. Ele especifica efeitos bioluminescentes em tons de esmeralda e magenta, iluminação volumétrica dramática e uma atmosfera artística e maravilhosa.

#### 📝 Prompt

```
"Visão microscópica abstrata de creme de café vivo, delicados filamentos brilhantes e redes fractais se espalhando naturalmente pela base escura do espresso, sutis efeitos bioluminescentes em tons de esmeralda e magenta, formas orgânicas fluidas com detalhes intrincados, fantasia biológica surreal, estilo de macrofotografia ultra nítida, iluminação volumétrica dramática, sem elementos de terror, atmosfera artística e maravilhosa, qualidade 8k"
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706184793_1u1urc_HAtQOlKasAAmb58.jpg" width="600" alt="Infográfico / Edu Visual - Vista Microscópica Abstrata da Crema de Café Viva - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706184993_msjj2e_HAtQOnSaIAERTnn.jpg" width="600" alt="Infográfico / Edu Visual - Vista Microscópica Abstrata da Crema de Café Viva - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [🇹🇷 İREM AKSOY 🇹🇷 Ⓥ #pallascataesthetics](https://x.com/bewisetojudge_)
- **Fonte:** [Twitter Post](https://x.com/bewisetojudge_/status/2020797150481752324)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9581)**

---

### No. 47: Infográfico / Edu Visual - Gerando uma Imagem de Borboleta com Iridescência Seletiva

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Este prompt foi desenvolvido para resolver um problema comum na geração de imagens por IA, onde especificar "iridescente" faz com que o objeto inteiro brilhe. O objetivo é gerar uma imagem de uma borboleta (especificamente uma *Atrophaneura alcinous* macho na forma de primavera) que represente com precisão a cor estrutural seletiva (iridescência) na asa esquerda e uma cor marrom fosca na asa direita, exigindo controle preciso sobre a luz e a textura.

#### 📝 Prompt

```
Comparação da frente e do verso de um espécime montado de um macho de {argument name="butterfly species" default="Atrophaneura alcinous"} na forma de primavera. As informações nesta ilustração mostram que a cor estrutural à esquerda e o {argument name="color" default="marrom fosco"} à direita são da mesma borboleta. Quando você escreve "iridescente" para a IA, tudo brilha. O trabalho do prompt é especificar "esta parte brilha, esta parte não brilha".
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706231672_wgg1zr_HAtBmhvaQAAM6TT.jpg" width="600" alt="Infográfico / Edu Visual - Gerando uma Imagem de Borboleta com Iridescência Seletiva - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [SHINTARO](https://x.com/UNIBRACITY)
- **Fonte:** [Twitter Post](https://x.com/UNIBRACITY/status/2020780992701882429)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9637)**

---

### No. 48: Infográfico / Edu Visual - Ilustração de História Natural Precisa. Prompt: Borboleta-pavão-chinesa.

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente detalhado com o objetivo de gerar uma ilustração precisa de história natural de uma borboleta-pavão-chinesa (Karasuageha) macho (forma de primavera) e uma flor de rododendro (Yama-tsutsuji) usando Nano Banana. O prompt inclui detalhes específicos necessários para a identificação da espécie, como o gradiente de cor estrutural nas asas, a faixa lateral amarela no abdômen e o padrão de pontos de néctar nas pétalas, buscando a precisão científica.

#### 📝 Prompt

```
{argument name="subject" default="Borboleta-pavão-chinesa-macho (forma de primavera)"} × {argument name="flower" default="Rododendro"} — gradiente de cor estrutural das asas, faixa lateral amarela do abdômen, padrão de manchas de néctar das pétalas
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706242979_n4cxzr_HArwi-kaEAA2cwv.jpg" width="600" alt="Infográfico / Edu Visual - Ilustração de História Natural Precisa. Prompt: Borboleta-pavão-chinesa. - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [SHINTARO](https://x.com/UNIBRACITY)
- **Fonte:** [Twitter Post](https://x.com/UNIBRACITY/status/2020695596659868030)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9652)**

---

### No. 49: Miniatura do YouTube - Visualização do Comercial de Tacos Explodidos

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt de duas partes para gerar uma sequência de movimento e duas imagens comerciais de alta qualidade de tacos. O prompt de movimento especifica uma separação precisa e suave dos ingredientes, enquanto os prompts de imagem detalham iluminação cinematográfica, profundidade de campo rasa e um estilo de visualização de explosão elegante.

#### 📝 Prompt

```
Motion Prompt: A comida começa a girar em círculos enquanto os ingredientes se separam suavemente e com precisão, mantendo o alinhamento e a escala. O movimento é suave, sem efeitos extras.

Imagem 1: Quadro cinematográfico de um comercial de comida de alta qualidade mostrando os mesmos tacos, preservados exatamente. Iluminação quente e dramática, profundidade de campo rasa, vapor suave com efeito de movimento, fundo luxuoso e desfocado, qualidade de anúncio ultra-premium.

Imagem 2: Visualização cinematográfica explodida com efeito de holofote, rótulos modernos e ousados, fundo com gradiente rico, estilo de apresentação comercial elegante.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137194492_45d740_HBHLpN3akAEHg7b.jpg" width="600" alt="Miniatura do YouTube - Visualização do Comercial de Tacos Explodidos - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [𝐌](https://x.com/Strength04_X)
- **Fonte:** [Twitter Post](https://x.com/Strength04_X/status/2022621706016453020)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10091)**

---

### No. 50: Miniatura do YouTube - Cena de Comercial de Panquecas Ultra-Luxuosas

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente estruturado projetado para gerar uma imagem estática ultra-realista e cinematográfica de um comercial de alimentos, apresentando uma pilha de panquecas americanas com calda de bordo escorrendo e várias coberturas, enfatizando iluminação específica, ângulos de câmera e texturas hiperdetalhadas.

#### 📝 Prompt

```
{
  "scene": "Comercial de Comida Ultra-Luxuoso",
  "subject": {
    "item": "Panquecas Americanas",
    "attributes": ["grossas", "fofas", "bordas douradas"],
    "stack_count": 4,
    "toppings": {
      "syrup": "Xarope de bordo puro, cascata em câmera lenta, gotas brilhantes",
      "fruit": ["mirtilos", "framboesas", "amoras"],
      "nuts": ["avelãs torradas", "amêndoas"],
      "texture_add": "flocos de aveia crocantes"
    }
  },
  "action": {
    "interaction": "Colher dourada ornamentada dando uma mordida delicada",
    "physics": "tensão superficial e alongamento realistas do xarope"
  },
  "environment": {
    "plating": "minimalista, sofisticado",
    "background": "bokeh suave em tom bege",
    "lighting": "luz matinal quente e rica, volumétrica"
  },
  "cinematography": {
    "camera_angle": ["close-up cinematográfico", "circulando", "levemente de cima para baixo"],
    "depth_of_field": "f/1.8 (raso)",
    "motion": "rastreamento suave",
    "rendering": ["texturas hiperdetalhadas", "ultrarrealista", "resolução 8k"]
  },
  "aesthetic_tags": [
    "fotografia de comida em alta",
    "de dar água na boca",
    "indulgente",
    "nível comercial"
  ]
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137194992_xybrb3_HBG0B3qakAIZuU2.jpg" width="600" alt="Miniatura do YouTube - Cena de Comercial de Panquecas Ultra-Luxuosas - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137195005_fhlack_HBG0BilbQAAZ3Fc.jpg" width="600" alt="Miniatura do YouTube - Cena de Comercial de Panquecas Ultra-Luxuosas - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137195476_vik5im_HBG0Bn0akAAVtmP.jpg" width="600" alt="Miniatura do YouTube - Cena de Comercial de Panquecas Ultra-Luxuosas - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137195982_fyt6pw_HBG0B78akAArlmm.jpg" width="600" alt="Miniatura do YouTube - Cena de Comercial de Panquecas Ultra-Luxuosas - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Meem](https://x.com/mehvishs25)
- **Fonte:** [Twitter Post](https://x.com/mehvishs25/status/2022595667995300126)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10093)**

---

### No. 51: Miniatura do YouTube - Prompt de Vídeo Cinematográfico Contínuo de Comida Japonesa

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um prompt cinematográfico e abrangente usado para gerar um vídeo de 4 cortes focado na culinária japonesa, enfatizando elementos ASMR, transições suaves (cortes correspondentes/panorâmicas), iluminação quente e uma trilha sonora minimalista de piano com toques de instrumentos japoneses. O prompt foi usado tanto para a geração de imagens (Nano Banana Pro) quanto para a geração de vídeo (Kling 3.0 Omni).

#### 📝 Prompt

```
Gere um vídeo cinematográfico focado na culinária japonesa, composto por quatro cortes perfeitamente conectados.

O primeiro corte deve ser um close-up, capturando cuidadosamente os sons da cozinha, o ritmo da faca e o movimento das mãos tocando os ingredientes, começando com um design de som tipo ASMR que enfatiza o vapor e as texturas dos ingredientes. A câmera deve usar profundidade de campo rasa e câmera lenta para guiar naturalmente o espectador das mãos aos gestos da mulher, mostrando sua fofura através de pequenos movimentos como uma surpresa sutil ou um sorriso gentil. Faça a transição suavemente a partir daqui usando cortes de correspondência ou panorâmicas.

O segundo corte é um plano médio do empratamento, capturando lindamente o movimento dos hashis e o momento em que os ingredientes são colocados no prato, enfatizando os sons delicados do prato e dos ingredientes ressoando, destacando o charme através do cuidado e do afeto.

O corte subsequente usa uma composição aérea para mostrar a visão geral do prato finalizado, com a câmera se aproximando lentamente, capturando o momento em que a mulher dá uma mordida em um close-up, capturando delicadamente sua respiração e reações sutis para convidar à empatia do espectador.

A parte final se conecta a uma interação calorosa à mesa, usando uma panorâmica suave e um crossfade para deixar uma impressão duradoura, misturando sutilmente risadas e fragmentos de conversa para expressar intimidade. O tom de cor deve ser cinematográfico e tendendo ao quente, com iluminação natural que mantém os destaques suavemente suprimidos. A música deve ser de piano minimalista com toques de instrumentos japoneses, e os efeitos sonoros devem misturar cuidadosamente sons de cozinha e de alimentação para aumentar o realismo. O ritmo geral deve ser relaxado, priorizando a conexão natural do final de cada corte com o início do próximo através do som e do movimento.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050479260_e17orq_HBCB8_-bYAAludD.jpg" width="600" alt="Miniatura do YouTube - Prompt de Vídeo Cinematográfico Contínuo de Comida Japonesa - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [空想写真家](https://x.com/KusoPhoto)
- **Fonte:** [Twitter Post](https://x.com/KusoPhoto/status/2022261278119735649)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10056)**

---

### No. 52: Miniatura do YouTube - Fotografia de Concerto Ultrarrealista de Billie Eilish

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente detalhado e estruturado, projetado para gerar uma fotografia de concerto ultrarrealista de uma artista feminina no palco, especificamente Billie Eilish, usando iluminação de palco verde dramática e uma perspectiva de ângulo extremamente baixo para enfatizar dominância e energia.

#### 📝 Prompt

```
{
  "model_style": {
    "type": "fotografia de show ultrarrealista",
    "quality": "8k, altamente detalhado, foco nítido",
    "aesthetic": "performance ao vivo, energética, dramática, ousada",
    "color_grading": "iluminação de palco dominante verde, alto contraste, sombras cinematográficas"
  },

  "character": {
    "identity": "{argument name=\"character identity\" default=\"YOUR_CHARACTER_HERE\"}",
    "gender_presentation": "artista feminina de palco",
    "body_type": "corpo curvilíneo, pernas fortes, presença atlética",
    "facial_expression": "expressão de performance focada e intensa",
    "gaze_direction": "olhando ligeiramente para cima",
    "hair": "escuro, na altura dos ombros, ligeiramente bagunçado sob o boné",
    "makeup": "maquiagem de palco, sutil, mas pronta para a performance"
  },

  "pose_and_posture": {
    "stance": "postura de poder, pernas afastadas na largura dos ombros",
    "camera_relative_position": "em pé diretamente acima do ponto de vista da câmera",
    "upper_body": "tronco ligeiramente inclinado para trás",
    "left_hand": "segurando o microfone perto da boca",
    "right_hand": "levantada perto da testa como se estivesse ajustando o boné ou protegendo os olhos das luzes",
    "legs": "firmemente plantadas, presença de palco dominante"
  },

  "clothing": {
    "top": "camisa de futebol americano vermelha oversized",
    "jersey_details": "grande número branco '26' na frente",
    "bottom": "shorts justos de renda vermelha, textura semitransparente",
    "legwear": "joelheiras Nike pretas",
    "socks": "meias pretas de cano médio",
    "shoes": "tênis cano alto pretos, sola grossa",
    "headwear": "boné de beisebol preto"
  },

  "accessories": {
    "microphone": "microfone de mão sem fio preto",
    "knee_pads": "logotipo Nike visível",
    "no_extra_jewelry": true
  },

  "environment": {
    "location": "arena de show interna",
    "stage": "grande plataforma de palco",
    "audience": "multidão visível ao fundo, borrada, mas perceptível",
    "barriers": "barreiras de controle de multidão de metal visíveis",
    "atmosphere": "neblina de show, público energético"
  },

  "lighting": {
    "main_light": "forte iluminação de palco verde vinda de baixo",
    "backlight": "luzes de palco brancas brilhantes atrás do sujeito",
    "rim_light": "iluminação sutil de contorno ao redor do corpo",
    "shadow_style": "sombras dramáticas para cima devido ao baixo ângulo da câmera"
  },

  "camera": {
    "angle": "ângulo de câmera extremamente baixo (visão de olho de minhoca)",
    "lens": "lente grande angular (equivalente a 24mm)",
    "perspective": "perspectiva distorcida enfatizando pernas e dominância",
    "focus": "foco nítido no sujeito, leve desfoque na plateia",
    "framing": "composição vertical de corpo inteiro"
  },

  "mood": {
    "energy": "empoderada, imponente, intensa",
    "vibe": "performance ao vivo em estádio",
    "emotion": "confiança e dominância de palco"
  },

  "technical_details": {
    "resolution": "8k",
    "texture_detail": "textura de tecido visível, detalhes de renda, textura de pele",
    "dynamic_range": "alto alcance dinâmico",
    "depth_of_field": "moderada, sujeito nítido, fundo ligeiramente borrado"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050444261_bkttzl_HBB7SgZaAAEAj6U.jpg" width="600" alt="Miniatura do YouTube - Fotografia de Concerto Ultrarrealista de Billie Eilish - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050444260_baktbs_HBB7SutagAAjw6-.jpg" width="600" alt="Miniatura do YouTube - Fotografia de Concerto Ultrarrealista de Billie Eilish - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050444271_s5sc36_HBB7SsAaIAA576Y.jpg" width="600" alt="Miniatura do YouTube - Fotografia de Concerto Ultrarrealista de Billie Eilish - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [Khanzy](https://x.com/Khhanzy)
- **Fonte:** [Twitter Post](https://x.com/Khhanzy/status/2022251797889650756)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9989)**

---

### No. 53: Miniatura do YouTube - Retrato de Posto de Gasolina Rosa Neon (Lente Olho de Peixe)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt estruturado para gerar uma imagem vibrante e de alto contraste de Madison Beer em um posto de gasolina com asfalto molhado à noite, iluminada por luzes neon rosa brilhantes. O prompt especifica uma perspectiva de lente olho de peixe grande angular, formato corporal detalhado e guarda-roupa/adereços específicos, incluindo um gesto de dedo do meio.

#### 📝 Prompt

```
{
  "subject": {
    "identity": "A cantora pop {argument name=\"subject name\" default=\"Madison Beer\"}, sorrindo com confiança.",
    "body": "Corpo em forma de ampulheta com definição atlética. Ombros largos que se afunilam para uma cintura estreita e marcada, contrastando com quadris proeminentes e curvilíneos e glúteos bem desenvolvidos (alta proporção cintura-quadril). Pernas e panturrilhas musculosas visíveis nas meias.",
    "wardrobe": {
      "top": "Top cropped rosa liso",
      "bottom": "Minissaia plissada branca.",
      "footwear": "Meias brancas até o joelho com listras rosas, tênis rosa e branco.",
      "accessories": "Brincos de argola grandes, unhas longas e rosadas. SEM colar.",
      "props": "Segurando um copo de isopor branco com um canudo na mão direita, fazendo um gesto de dedo médio com a mão esquerda."
    }
  },
  "scene": {
    "location": "Posto de gasolina com asfalto molhado à noite, sob uma grande cobertura triangular iluminada por luzes de néon rosa brilhantes e luminárias suspensas.",
    "elements": "Um carro esportivo rosa estacionado atrás dela, bombas de gasolina, prédio de loja de conveniência ao fundo com uma placa 'ABERTO 24 HRS'.",
    "atmosphere": "Vibrante, iluminado por néon, chuvoso, reflexos no pavimento molhado."
  },
  "camera": {
    "lens": "Lente olho de peixe grande angular, criando uma distorção circular e perspectiva distintas.",
    "lighting": "Luz artificial mista: néon rosa brilhante da cobertura, luzes brancas suspensas, criando fortes realces e reflexos coloridos no chão molhado e no carro.",
    "angle": "Ângulo ligeiramente baixo, olhando para o sujeito.",
    "focus": "Foco nítido no sujeito e no primeiro plano imediato, com o fundo ligeiramente distorcido pela lente."
  },
  "aspect_ratio": "9:16"
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964575617_i8nihv_HA8xTNgbgAAUL2-.jpg" width="600" alt="Miniatura do YouTube - Retrato de Posto de Gasolina Rosa Neon (Lente Olho de Peixe) - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964575701_bwl7ih_HA8xSjMXwAAVzPx.jpg" width="600" alt="Miniatura do YouTube - Retrato de Posto de Gasolina Rosa Neon (Lente Olho de Peixe) - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964575717_7uc4d7_HA8xK7BWwAAGfoe.jpg" width="600" alt="Miniatura do YouTube - Retrato de Posto de Gasolina Rosa Neon (Lente Olho de Peixe) - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [Bethany](https://x.com/JustBethanyai)
- **Fonte:** [Twitter Post](https://x.com/JustBethanyai/status/2021888973774147898)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9952)**

---

### No. 54: Miniatura do YouTube - Geração de Vídeos Estilo Vlog a Partir de Imagens Nano Banana Pro Usando Google Veo 3.1

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um prompt detalhado usado para transformar uma imagem gerada pelo Nano Banana Pro em um vídeo usando o Google Veo 3.1, com foco em um estilo de vlog realista e íntimo. O prompt especifica ângulos de câmera, iluminação, expressão do sujeito, diálogo e música de fundo para obter uma aparência de alta qualidade e sem edição.

#### 📝 Prompt

```
Crie uma tomada em estilo de vídeo, com a câmera voltada para frente. A câmera está fixa na altura do rosto e posicionada diretamente na frente do objeto. A postura e a composição do objeto indicam que ele está sentado.

A composição é simples e estável, sem ângulos dramáticos ou movimentos de câmera perceptíveis. A iluminação é de [Adicionar iluminação realista considerando tomadas estilo UGC]. O rosto está claramente visível.

A expressão do objeto é calma e relaxada, com um sorriso natural e discreto. Parece que ela está prestes a começar a falar para a câmera para um vlog. A qualidade da imagem reflete uma gravação de vídeo feita em ambiente interno à noite (alta qualidade), sem filtros, efeitos de embelezamento ou nitidez artificial aplicados.

O espaço parece pessoal. O bokeh é devido às limitações da câmera, não a efeitos artificiais de profundidade de campo. A atmosfera geral é quente, brilhante e íntima, lembrando um momento real de vlog pouco antes de o objeto começar a falar.

O diálogo da mulher é: "O destaque da moda de hoje é [Adicionar características de moda]!", dito em tom suave enquanto ela toca suas roupas. Ela sorri no final.

Música de fundo: Uma música confortável, adequada para uma atmosfera de moda estilo vlog, está tocando.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964576146_4dlzju_HA7BRKBagAAapve.jpg" width="600" alt="Miniatura do YouTube - Geração de Vídeos Estilo Vlog a Partir de Imagens Nano Banana Pro Usando Google Veo 3.1 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964576719_413o3j_HA7BRmUaMAASstR.jpg" width="600" alt="Miniatura do YouTube - Geração de Vídeos Estilo Vlog a Partir de Imagens Nano Banana Pro Usando Google Veo 3.1 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964576721_75939s_HA7BQzZa4AAXLYg.jpg" width="600" alt="Miniatura do YouTube - Geração de Vídeos Estilo Vlog a Partir de Imagens Nano Banana Pro Usando Google Veo 3.1 - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [空想写真家](https://x.com/KusoPhoto)
- **Fonte:** [Twitter Post](https://x.com/KusoPhoto/status/2021841706656604668)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9954)**

---

### No. 55: Miniatura do YouTube - Prompt de vídeo de YouTuber de tecnologia demonstrando caixa de som Bluetooth

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um vídeo com um jovem YouTuber de tecnologia demonstrando um alto-falante Bluetooth retrô-futurista em um estúdio com pouca luz, iluminado por uma ring light.

#### 📝 Prompt

```
Um jovem YouTuber de tecnologia demonstra um alto-falante Bluetooth. Ele está sentado em frente à câmera em uma mesa, vestindo um moletom e um boné. A mesa está de frente para a câmera. O fundo é um estúdio de YouTuber com iluminação baixa. O YouTuber é iluminado por uma ring light. O alto-falante Bluetooth parece minimalista e retrô-futurista.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770878326360_kxfj3j_HA3WQRsbwAAywhW.jpg" width="600" alt="Miniatura do YouTube - Prompt de vídeo de YouTuber de tecnologia demonstrando caixa de som Bluetooth - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Harboriis](https://x.com/harboriis)
- **Fonte:** [Twitter Post](https://x.com/harboriis/status/2021507491843228158)
- **Publicado:** 11 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9784)**

---

### No. 56: Miniatura do YouTube - Gerar Personagem Realista a partir de Prompt de Referência de Imagem de Fantasia

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)

#### 📖 Descrição

Este é um prompt de processo de duas etapas. Primeiro, uma imagem de fantasia inicial é gerada (presumivelmente via Midjourney), e então o Nano Banana Pro é instruído a gerar um personagem humano realista com base nessa imagem de fantasia como referência. A imagem realista resultante é então usada como referência para um modelo de geração de vídeo (Seedance 2.0).

#### 📝 Prompt

```
Use o Nano Banana Pro para gerar um efeito de personagem realista e, em seguida, use essa imagem como um elemento de referência para o Seedance 2.0 criar um vídeo.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792217949_zs9td1_HA0MoEsaAAIVs9N.jpg" width="600" alt="Miniatura do YouTube - Gerar Personagem Realista a partir de Prompt de Referência de Imagem de Fantasia - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792218224_hiasel_HA0MlWoaAAUcMhq.jpg" width="600" alt="Miniatura do YouTube - Gerar Personagem Realista a partir de Prompt de Referência de Imagem de Fantasia - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [John](https://x.com/john87445528)
- **Fonte:** [Twitter Post](https://x.com/john87445528/status/2021285699786338704)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** zh

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9748)**

---

### No. 57: Miniatura do YouTube - Prompt de Foto de Ação de Montanha-Russa Emocionante

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON abrangente para o Nano Banana Pro, projetado para gerar uma fotografia de ação espontânea de uma jovem em uma montanha-russa. O prompt detalha a aparência da modelo (cabelo loiro platinado, estampa de leopardo), expressão (gritando de emoção), pose (segurando a barra de segurança) e aspectos técnicos como o ângulo da câmera a bordo, luz solar forte e proporção de aspecto 3:4, capturando um momento de pura adrenalina.

#### 📝 Prompt

```
{
  "prompt": "Foto de ação emocionante em montanha-russa, jovem mulher com cabelo loiro platinado esvoaçando selvagemente ao vento, gritando de emoção com a boca bem aberta, sentada em um carrinho de montanha-russa descendo uma queda íngreme, vestindo um vestido regata com estampa de leopardo, colar gargantilha de corrente dourada, pequenos brincos de argola dourados, mãos segurando firmemente a barra de segurança, outros passageiros visíveis nos assentos atrás, estrutura da pista da montanha-russa vermelha e laranja visível, cenário de parque de diversões com brinquedos e atrações ao fundo, dia ensolarado e brilhante, momento de ação espontâneo capturando pura alegria e emoção, cabelo voando dramaticamente, expressão de adrenalina, conteúdo de estilo de vida de parque temático, 3:4",
  "negative_prompt": "ambiente interno, estúdio, pose calma, expressão séria, noturno, cabelo estático, roupa formal",
  "style": "fotografia de ação espontânea, estilo de vida de parque de diversões, captura de momento emocionante, conteúdo divertido de verão",
  "aspect_ratio": "3:4",
  "camera": {
    "type": "câmera on-ride ou câmera de ação",
    "angle": "frontal do carrinho da montanha-russa, capturando a reação do passageiro",
    "framing": "plano médio, parte superior do corpo e rosto, ambiente da montanha-russa visível"
  },
  "lighting": {
    "type": "luz solar natural brilhante ao ar livre",
    "quality": "luz do dia forte, iluminação externa dinâmica",
    "atmosphere": "dia ensolarado de verão em parque de diversões"
  },
  "mood": "emocionante, excitante, alegre, adrenalina, divertido, espontâneo, estimulante",
  "color_palette": "loiro platinado, estampa de leopardo bege e preto, joias douradas, pista de montanha-russa vermelha e laranja, fundo colorido de parque de diversões",
  "subject_features": {
    "hair": "loiro platinado, voando selvagemente ao vento, desfoque de movimento dramático, despenteado pelo vento",
    "skin": "clara, natural",
    "eyes": "claros, arregalados de excitação",
    "lips": "boca bem aberta gritando de alegria",
    "expression": "emocionada, excitada, gritando, pura alegria e adrenalina",
    "teeth": "visíveis, sorriso/grito genuíno e grande"
  },
  "accessories": {
    "necklace": "colar gargantilha de corrente dourada",
    "earrings": "pequenos brincos de argola dourados"
  },
  "wardrobe": {
    "outfit": "regata ou vestido justo com estampa animal de leopardo, decote quadrado, alças finas"
  },
  "pose": {
    "position": "sentada no assento da montanha-russa",
    "hands": "segurando firmemente a barra de segurança preta",
    "body": "pressionada contra o assento pela força G",
    "expression": "gritando de excitação, boca bem aberta"
  },
  "setting": {
    "location": "montanha-russa em parque de diversões ou feira",
    "ride": "seção de queda íngreme da montanha-russa, estrutura de trilho de metal vermelho visível",
    "background": "parque de diversões com vários brinquedos, atrações de carnaval, outras estruturas",
    "other_riders": "outras pessoas visíveis nos assentos atrás",
    "atmosphere": "dia de verão movimentado em parque temático"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770878365080_n5wfrg_HAy6z3KaAAk3Ynv.jpg" width="600" alt="Miniatura do YouTube - Prompt de Foto de Ação de Montanha-Russa Emocionante - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [gauche](https://x.com/gaucheai)
- **Fonte:** [Twitter Post](https://x.com/gaucheai/status/2021195829621436857)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9854)**

---

### No. 58: Miniatura do YouTube - Retrato de Jennie Kim, estrela de K-pop, em performance no palco

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON estruturado para gerar uma imagem cinematográfica de alto contraste da estrela de K-pop Jennie Kim (BLACKPINK) durante uma performance. O prompt especifica sua pose dinâmica, estética de "pele de vidro" (glass-skin), roupa de palco (top cropped de renda branca, parte de baixo plissada preta) e iluminação dramática (holofotes de palco de alto contraste com luz de contorno azul fria e névoa cinematográfica).

#### 📝 Prompt

```
{
  "subject": {
    "name": "Jennie Kim",
    "alias": "Jennie",
    "group": "BLACKPINK",
    "persona": "Presença de palco elegante e feroz, estilo característico de 'human Chanel'",
    "expression": "Focada, ligeiramente intensa, olhar penetrante fora da câmera",
    "pose": "Perfil dinâmico de três quartos, no meio da coreografia, cabelo em movimento"
  },
  "physical_features": {
    "hair": "Cabelo longo, escuro, com ondas volumosas emoldurando o rosto e caindo pelas costas",
    "skin": "Pele orvalhada, hiper-reflexiva, estilo 'glass-skin', tom de pele quente",
    "makeup": "Sombra esfumada suave, delineador gatinho, lábios vermelhos em degradê"
  },
  "clothing": {
    "top": "Top cropped de renda branca texturizada",
    "bottom": "Parte de baixo plissada preta de cintura alta",
    "style": "Monocromático, traje de palco chique"
  },
  "lighting": {
    "type": "Holofotes de palco",
    "contrast": "Alto",
    "effects": "Luz de contorno azul fria realçando cabelo e pele, névoa/fumaça cinematográfica no ar"
  },
  "atmosphere": "Concerto/performance focada, clima cinematográfico e etéreo, equilíbrio entre vulnerabilidade e poder",
  "image_details": {
    "width": 504,
    "height": 1002
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792211932_250pxi_HAxc8kyaAAIcT94.jpg" width="600" alt="Miniatura do YouTube - Retrato de Jennie Kim, estrela de K-pop, em performance no palco - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792211922_w0y291_HAxc8jgaQAA-v6k.jpg" width="600" alt="Miniatura do YouTube - Retrato de Jennie Kim, estrela de K-pop, em performance no palco - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792211956_3a4858_HAxc8kWagAANAXb.jpg" width="600" alt="Miniatura do YouTube - Retrato de Jennie Kim, estrela de K-pop, em performance no palco - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [Ankit Mishra](https://x.com/AnkitMi16412441)
- **Fonte:** [Twitter Post](https://x.com/AnkitMi16412441/status/2021092537528619088)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9735)**

---

### No. 59: Miniatura do YouTube - Prompt de Geração de Imagem de Miniatura para Vlogger

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um usuário gerou uma ilustração em miniatura para uma sessão de prática de piano noturna usando o Nano Banana Pro, demonstrando a capacidade da ferramenta de criar imagens específicas para conteúdo VTuber.

#### 📝 Prompt

```
Gere uma ilustração para uma miniatura de prática de piano relaxada noturna
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792218751_edhr7o_HAxL-TgbMAAvxuc.jpg" width="600" alt="Miniatura do YouTube - Prompt de Geração de Imagem de Miniatura para Vlogger - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [エルティアナ@Vtuber/ゲーム音楽系キーボーディスト🎹/AI・Web3の錬金術士](https://x.com/atelier_ert)
- **Fonte:** [Twitter Post](https://x.com/atelier_ert/status/2021074050328691190)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9749)**

---

### No. 60: Miniatura do YouTube - Pôster Dinâmico de Batalha de Anime com Texto em Japonês

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt de modelo para gerar um pôster de batalha de anime super dinâmico com um personagem de referência. Ele especifica o uso do estilo de arte e das características exatas da referência, cercando-os com poder e aura, e incluindo texto japonês dramático em uma posição específica para corresponder à energia do ataque.

#### 📝 Prompt

```
Arte de Anime super dinâmica do personagem referenciado 【{argument name="character name" default="REFERENCED CHARACTER OR ANIME CHARACTER NAME"}】 【〈 REMOVER SEÇÃO PARA RESULTADOS MAIS CRIATIVOS〉com suas características exatas e expressões faciais, proporções de lineart】 no mesmo estilo de arte em batalha com sua energia característica combinando com a vibe da imagem referenciada, poder e aura os envolvendo, estilo anime, alta resolução, alta qualidade, alto detalhe, fundo de anime dramático combinando com o fundo da imagem referenciada, visual chave de anime, escreva 【{argument name="text to write" default="TEXT"}】 na 【{argument name="text position" default="POSITION"}】 em japonês no ataque em uma fonte de anime caótica e dramática que se encaixa no poder e energia do ataque, pôster chave de anime.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706188788_u3xzfd_HAwPm0WaAAMwSXU.jpg" width="600" alt="Miniatura do YouTube - Pôster Dinâmico de Batalha de Anime com Texto em Japonês - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706188710_67eo8y_HAwPi9wXkAAwh_x.jpg" width="600" alt="Miniatura do YouTube - Pôster Dinâmico de Batalha de Anime com Texto em Japonês - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706189344_18xf3n_HAwPY0VXEAAOMrZ.jpg" width="600" alt="Miniatura do YouTube - Pôster Dinâmico de Batalha de Anime com Texto em Japonês - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706190456_p3ucio_HAwPtvYa8AAkmve.jpg" width="600" alt="Miniatura do YouTube - Pôster Dinâmico de Batalha de Anime com Texto em Japonês - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [KiriKev](https://x.com/0xKiriKev)
- **Fonte:** [Twitter Post](https://x.com/0xKiriKev/status/2021007862680727940)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9588)**

---

### No. 61: Miniatura do YouTube - Prompt de Imagem de Artigos Esportivos de Neve de Celebridades

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt de array JSON projetado para gerar quatro imagens separadas de celebridades (Addison Rae, Ana de Armas, Sydney Sweeney) em roupas esportivas de inverno, mas colocadas em ambientes de montanha nevada ou academia. Cada entrada especifica a celebridade, a roupa, o local e os principais elementos de fundo (raposa, veado, lobo, Matterhorn) para criar imagens temáticas e verticais.

#### 📝 Prompt

```
[
  {
    "fileName": "1000586027.png",
    "name": "{argument name="first celebrity" default="Addison Rae"}",
    "description": "Uma mulher ajoelhada na neve profunda com uma montanha e uma cabana ao fundo. Ela está usando protetores de ouvido amarelos, um top cropped verde e amarelo, e shorts amarelos. Uma raposa está sentada na neve atrás dela.",
    "location": "Montanhas Nevadas",
    "outfit": "Roupa Esportiva de Inverno",
    "dimensions": "1080x1920"
  },
  {
    "fileName": "1000586028.png",
    "name": "Celebridade",
    "description": "Uma mulher posando na neve com a montanha Matterhorn ao fundo. Ela está usando protetores de ouvido marrons, uma camiseta preta e branca, e shorts pretos com 'MATTERHORN' e uma cruz suíça. Um cervo está descansando ao fundo.",
    "location": "Zermatt, Suíça",
    "outfit": "Roupa Esportiva Temática",
    "dimensions": "1080x1920"
  },
  {
    "fileName": "1000586030.png",
    "name": "{argument name="third celebrity" default="Ana de Armas"}",
    "description": "Uma versão editada da selfie de academia com um efeito de sobreposição de neve pesada. A mulher está na mesma pose e roupa, mas toda a cena está coberta por flocos de neve caindo.",
    "location": "Academia Interna (Efeito Neve)",
    "outfit": "Roupa Esportiva",
    "dimensions": "1080x1920"
  },
  {
    "fileName": "1000586025.jpg",
    "name": "Sydney Sweeney",
    "description": "Uma mulher ajoelhada em uma paisagem nevada com uma cabana de madeira e um lobo ao fundo. Ela está usando protetores de ouvido azuis, uma camisa tie-dye verde e shorts verdes com 'ASPEN' estampado.",
    "location": "Aspen, Colorado",
    "outfit": "Roupa Esportiva de Inverno",
    "dimensions": "1080x1920"
  }
]
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619734428_baf83h_HAoWF4tXAAAwjxL.jpg" width="600" alt="Miniatura do YouTube - Prompt de Imagem de Artigos Esportivos de Neve de Celebridades - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619734464_rdx2qi_HAoWF_fWgAAp_LE.jpg" width="600" alt="Miniatura do YouTube - Prompt de Imagem de Artigos Esportivos de Neve de Celebridades - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619734443_q5dwle_HAoWF4vXYAAuydW.jpg" width="600" alt="Miniatura do YouTube - Prompt de Imagem de Artigos Esportivos de Neve de Celebridades - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619735486_0jkxxe_HAoWF5GbEAA7jRv.jpg" width="600" alt="Miniatura do YouTube - Prompt de Imagem de Artigos Esportivos de Neve de Celebridades - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Bahar azam](https://x.com/BaharAzamm561)
- **Fonte:** [Twitter Post](https://x.com/BaharAzamm561/status/2020451702999015624)
- **Publicado:** 8 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9510)**

---

### No. 62: Miniatura do YouTube - Prompt de Foto de Post de Filme Cinematográfico de Kollywood

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt projetado para gerar uma foto no estilo de um pôster de filme cinematográfico de Kollywood, criado usando o modelo Gemini Nano Banana. O texto do prompt real é referenciado como estando no texto alternativo da imagem.

#### 📝 Prompt

```
Criação de imagem de filme cinematográfico de Kollywood com prompt de foto Gemini Nano Banana.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770532864197_t3k16v_HAhR_WobMAA6Qvb.jpg" width="600" alt="Miniatura do YouTube - Prompt de Foto de Post de Filme Cinematográfico de Kollywood - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [blogbursthub](https://x.com/blogbursthub)
- **Fonte:** [Twitter Post](https://x.com/blogbursthub/status/2019954609352265927)
- **Publicado:** 7 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9409)**

---

### No. 63: Quadrinhos / Storyboard - Prompt para Geração de Storyboard Cinematográfico de 9 Painéis

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt para o Nano Banana Pro que usa uma imagem de entrada como referência para gerar uma folha de storyboard cinematográfica sequencial de 9 painéis (grade 3x3). Ele enfatiza perspectivas dinâmicas, diversos ângulos de câmera, consistência de personagem/iluminação e imagens estáticas de alta resolução sem bordas.

#### 📝 Prompt

```
Uma folha de storyboard cinematográfica de 9 painéis disposta em uma grade 3x3. Uma narrativa visual sequencial que expande o contexto da imagem de entrada. Variedade dinâmica de perspectivas, diversos ângulos de câmera, pontos focais mutáveis e narrativa atmosférica. Consistência de personagem, iluminação e granulação de filme. Imagens estáticas de alta resolução. Sem bordas. plot: {argument name="plot description" default="[opcional]"}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223973076_s6ca28_HBO2nUra8AA-yvw.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt para Geração de Storyboard Cinematográfico de 9 Painéis - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [proper](https://x.com/ProperPrompter)
- **Fonte:** [Twitter Post](https://x.com/ProperPrompter/status/2023161447342333964)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10188)**

---

### No. 64: Quadrinhos / Storyboard - Prompt de Grade de Imagens Cinematográficas para Sequência de Dança em Casa

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON detalhado para o Nano Banana Pro gerar uma grade 2x3 de imagens cinematográficas que capturam uma sequência íntima de dança em casa. O prompt especifica parâmetros complexos, incluindo modo imagem-para-imagem, preservação de identidade e pose, iluminação específica (ambiente quente e suave), configurações da câmera (35mm, f/2.0) e detalhes do guarda-roupa do sujeito (vestido de cetim vermelho escuro) e controle de desfoque de movimento.

#### 📝 Prompt

```
{
  "generation_request": {
    "meta_data": {
      "task_type": "home_dance_film_still_grid_2x3_red_satin",
      "language": "pt",
      "priority": "highest",
      "version": "v1.0_HOME_DANCE_2X3_RED_SATIN_FILM"
    },
    "input": {
      "mode": "image_to_image",
      "reference_image_usage": "very_high",
      "preserve_identity": true,
      "preserve_facial_features": true,
      "preserve_pose_dynamics": true,
      "notes": "Use a colagem de referência como âncora principal. Mantenha o mesmo casal, o mesmo cômodo, o mesmo enquadramento e o mesmo fluxo de dança nos seis painéis. Mude o vestido da mulher para um vestido de cetim vermelho escuro com brilho elegante. Mantenha o desfoque de movimento realista da dança, mantendo os rostos legíveis."
    },
    "output": {
      "aspect_ratio": "1:1",
      "resolution": "ultra_high",
      "num_images": 1,
      "layout": {
        "type": "grid",
        "rows": 2,
        "cols": 3,
        "gutter": "thin",
        "panel_consistency": "high"
      },
      "sharpness": "filmic_soft",
      "grain": "subtle_analog",
      "halation": "soft"
    },
    "scene": {
      "concept": "sequência de dança íntima em casa capturada como fotos de filme cinematográficas",
      "environment": "corredor/sala de estar aconchegante, porta simples e quadro na parede, luz do dia quente ou mistura de tungstênio",
      "lighting": {
        "style": "luz ambiente suave e quente",
        "key_light": "luz lateral suave tipo janela",
        "fill_light": "preenchimento suave para manter os detalhes da pele",
        "shadow_behavior": "suave, ligeiramente nebuloso",
        "avoid": "flash forte, HDR agressivo"
      }
    },
    "camera": {
      "lens": "35mm",
      "aperture": "f/2.0",
      "depth_of_field": "rasa a média",
      "look": "foto de filme vintage, leve suavidade e desfoque"
    },
    "subjects": {
      "count": 2,
      "type": "casal adulto",
      "male": {
        "wardrobe": "camiseta branca justa, calças escuras",
        "notes": "mantenha a roupa simples e consistente em todos os painéis"
      },
      "female": {
        "wardrobe": {
          "dress": "vestido midi de cetim vermelho escuro, caimento elegante, saia fluida, reflexos sutis de brilho, corpete ajustado",
          "details": "os reflexos do tecido de cetim devem parecer realistas e suaves, não metálicos"
        },
        "hair": "corte bob curto (mantenha consistente com a referência, se visível)"
      },
      "anatomy_rules": "mãos e dedos corretos, pegada natural durante a dança, alinhamento realista dos braços"
    },
    "motion_style": {
      "dance_energy": "suave, mas dinâmica",
      "blur": "desfoque de movimento controlado no vestido e nos braços durante os giros, rostos permanecem principalmente legíveis",
      "camera_motion": "câmera estática, movimento vem dos sujeitos"
    },
    "grid_plan": {
      "panel_1": "casal começando a dançar, passos brincalhões próximos à porta",
      "panel_2": "de frente um para o outro, de mãos dadas, sorrindo, preparando-se para girar",
      "panel_3": "homem inclina a mulher ligeiramente, saia de cetim vermelho fluindo",
      "panel_4": "wo"
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223960099_57p2kr_HBNy2wGWwAEVfw7.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt de Grade de Imagens Cinematográficas para Sequência de Dança em Casa - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Özge Döner](https://x.com/astronomerozge1)
- **Fonte:** [Twitter Post](https://x.com/astronomerozge1/status/2023086953428607098)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10163)**

---

### No. 65: Quadrinhos / Storyboard - Prompt de Grade de Personagens Animados 3D no Estilo Pixar

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma grade de 6 painéis de uma personagem feminina jovem animada em 3D no estilo Pixar. Ele especifica closes extremos, poses dinâmicas, expressões únicas, fundos vibrantes e proporções de desenho animado estilizadas para enfatizar uma personalidade brincalhona e aventureira.

#### 📝 Prompt

```
Uma personagem feminina jovem animada em 3D, estilo Pixar, em uma grade de 6 painéis, cada painel mostrando um close-up extremo ou um plano de corpo inteiro que preenche quase todo o quadro. Cada painel apresenta uma expressão única, pose dinâmica e roupa. Fundos ousados e brilhantes (amarelo, azul, vermelho, rosa, roxo, verde). Ela tem cabelo ondulado e brilhante, olhos grandes e cintilantes, pele lisa e proporções de desenho animado estilizadas. Cada painel enfatiza sua personalidade brincalhona, confiante e aventureira através de gestos expressivos, poses animadas e moda distinta — do esportivo ao mágico e ao casual chique. O enquadramento de ponta a ponta destaca detalhes intrincados e cores vibrantes.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223967936_e5m3tc_HBLKB5kakAMng8r.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt de Grade de Personagens Animados 3D no Estilo Pixar - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Cherry 2.O](https://x.com/Mind_Boticni)
- **Fonte:** [Twitter Post](https://x.com/Mind_Boticni/status/2022901334484357165)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10178)**

---

### No. 66: Quadrinhos / Storyboard - Cinemática de Transformação de Estatueta de Cavalo de Vidro (Prompt de Vídeo)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um vídeo cinematográfico 3D de 15 a 20 segundos baseado em um storyboard, mostrando uma estatueta de cavalo de vidro azul translúcido se transformando em ouro radiante enquanto galopa em uma paisagem de pôr do sol dourado, enfatizando materiais brilhantes e iluminação volumétrica.

#### 📝 Prompt

```
Gerar um comercial 3D cinematográfico com este storyboard. Seguindo os quadros exatos, contando a história de uma estatueta de cavalo de vidro azul translúcido adornada com gravuras florais tradicionais que acorda em um mundo azul estilizado, se transforma através da luz em ouro radiante e galopa para uma paisagem de pôr do sol dourado. Duração: ~15–20 segundos. Estilo: cinematográfico 3D, materiais translúcidos brilhantes, iluminação volumétrica.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137202467_1s5cjc_HBGeqADbkAE7bws.jpg" width="600" alt="Quadrinhos / Storyboard - Cinemática de Transformação de Estatueta de Cavalo de Vidro (Prompt de Vídeo) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Vinh Lam](https://x.com/vinhiam)
- **Fonte:** [Twitter Post](https://x.com/vinhiam/status/2022572159483400229)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10105)**

---

### No. 67: Quadrinhos / Storyboard - Variação de Posição do Personagem no Prompt

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um prompt usado com o Nano Banana Pro para gerar quatro visualizações/poses diferentes de um personagem, começando de uma imagem frontal, permitindo uma conexão de vídeo contínua. Este prompt foi projetado para criar variações de um assunto existente.

#### 📝 Prompt

```
1: A visão traseira deste personagem (traseira diagonal)
2: O belo perfil deste personagem (lado direito)
3: A parte superior do corpo, vista traseira diagonal deste personagem (traseira diagonal)
4: Perfil em close-up do rosto deste personagem
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050477832_hbrbg8_HBDBULvaEAAechi.jpg" width="600" alt="Quadrinhos / Storyboard - Variação de Posição do Personagem no Prompt - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050477842_luu35y_HBDBXCZbwAAgO_A.jpg" width="600" alt="Quadrinhos / Storyboard - Variação de Posição do Personagem no Prompt - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050477951_dhjw0h_HBDBWKwacAAMCzV.jpg" width="600" alt="Quadrinhos / Storyboard - Variação de Posição do Personagem no Prompt - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050478876_bedssa_HBDBcD9acAAOGY2.png" width="600" alt="Quadrinhos / Storyboard - Variação de Posição do Personagem no Prompt - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [空想写真家](https://x.com/KusoPhoto)
- **Fonte:** [Twitter Post](https://x.com/KusoPhoto/status/2022329932546777523)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10055)**

---

### No. 68: Quadrinhos / Storyboard - Ilustração Surreal no Estilo de Mangueira de Borracha

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt JSON detalhado para gerar uma ilustração em preto e branco no estilo de animação surrealista dos anos 1930, conhecido como "rubber hose". O prompt enfatiza arte de linha de alto contraste, hachuras/pontilhados pesados e características específicas do personagem, como uma estética de derretimento/gotejamento, sorrisos largos e dentuços e olhos pretos vazios, visando uma vibe de quadrinhos underground vintage.

#### 📝 Prompt

```
{
"style_name": "Tinta Surreal de Mangueira de Borracha",
"Subject": "{argument name=\"Subject\" default=\"[ASSUNTO]\"}",
"prompt_structure": {
"prefix": "Um assunto desenhado em um estilo de animação surreal de mangueira de borracha dos anos 1930.",
"core_aesthetic": "Ilustração em tinta preta e branca desenhada à mão, fundo branco limpo.",
"shading_technique": "Arte de linha de alto contraste, uso intenso de hachuras e pontilhismo para sombreamento.",
"character_features": "Estética de derretimento e gotejamento, sorrisos largos e dentuços, olhos pretos vazios.",
"vibe": "Quadrinhos underground vintage, texturas minimalistas mas detalhadas, contornos limpos.",
"full_composite_prompt": "Desenhado em um estilo de animação surreal de mangueira de borracha dos anos 1930. Ilustração em tinta preta e branca desenhada à mão em um fundo branco limpo. Apresenta arte de linha de alto contraste com uso intenso de hachuras e pontilhismo para sombreamento. O personagem tem uma estética de derretimento e gotejamento, sorrisos largos e dentuços e olhos pretos vazios. Vibe de quadrinhos underground vintage, texturas minimalistas mas detalhadas, contornos limpos."
},
"negative_prompt": "colorido, gradientes, render 3d, foto, realista, tons de cinza, borrado, linhas bagunçadas, cenário de fundo, cortado, fora do quadro, truncado",
"recommended_settings": {
"aspect_ratio": "1:1",
"color_palette": "Monocromático / Preto e Branco"
}
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964580417_ol9ugp_HA9lY4QbsAQPplk.jpg" width="600" alt="Quadrinhos / Storyboard - Ilustração Surreal no Estilo de Mangueira de Borracha - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [ibexdream](https://x.com/ibexdream)
- **Fonte:** [Twitter Post](https://x.com/ibexdream/status/2021946529452261720)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9964)**

---

### No. 69: Quadrinhos / Storyboard - Prompt de Geração de Personagem Inimigo Abstrato Gigante (Passo 2)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

O segundo passo em um processo de várias etapas, este prompt gera uma imagem de alta resolução (4K recomendado) de uma gigantesca entidade inimiga abstrata, descrita como sendo formada inteiramente por uma névoa preta rodopiante com um rosto de máscara Noh tradicional, em um cenário de paisagem montanhosa escura.

#### 📝 Prompt

```
Uma gigantesca entidade abstrata formada inteiramente por uma névoa negra rodopiante,
seu corpo vagamente humanoide, mas em constante mudança,
uma grande máscara tradicional Noh emergindo da névoa como seu rosto,
sem corpo sólido, apenas fumaça densa moldando braços e tronco,
névoa negra fluindo e se dissolvendo no ar circundante,
paisagem montanhosa escura abaixo,
luar difuso e suave cortando a névoa,
realismo altamente cinematográfico, simbólico e minimalista,
fotograma de filme, paleta de cores suaves, visual de lente de 35mm
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964578069_xx3xnm_HA9j2qyaMAAD7lj.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt de Geração de Personagem Inimigo Abstrato Gigante (Passo 2) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [iX](https://x.com/iX00AI)
- **Fonte:** [Twitter Post](https://x.com/iX00AI/status/2021944552731685101)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9957)**

---

### No. 70: Quadrinhos / Storyboard - Geração de Vídeos de Rotina Matinal usando o Kling 3.0

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um prompt de vídeo detalhado gerado pelo assistente da Freepik (GPT-5) com base em uma imagem da Nano Banana Pro, usado para criar uma sequência de curta-metragem com Kling 3.0. O prompt descreve três cenas focadas em movimentos suaves de câmera, closes de rituais matinais e uma conclusão cinematográfica.

#### 📝 Prompt

```
Cena 1
Use um movimento suave de dolly para se aproximar da janela, fazendo a transição de um plano geral para um plano médio do sujeito respirando fundo na luz da manhã. Concentre-se em movimentos sutis, como o relaxamento dos ombros e as reações dos dedos, criando uma atmosfera adorável com sons naturais distantes (pássaros cantando, vento) sobrepostos a uma delicada música de piano. Faça um crossfade para um close-up onde a luz da janela se reflete nas pontas dos dedos.

Cena 2
Use close-ups focando em xícaras fumegantes e pequenos objetos para seguir ritmicamente os movimentos das mãos (levantar a xícara, mexer com uma colher, etc.). Use uma combinação de câmera lenta e leve time-lapse para expressar calor e inocência, sobrepondo efeitos sonoros como respiração e pequenas risadas. O vapor preenche a tela e se dissolve, levando à próxima cena.

Cena 3
A câmera se afasta para mostrar a cena completa, concluindo com o leve movimento do sujeito pronto para sair. Mostre a atmosfera persistente através do ritmo dos passos e gestos das mãos, concluindo cinematicamente com uma silhueta contraluz e tons de cores suaves. A música desaparece suavemente, deixando a sensação persistente da vida cotidiana.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964577252_29693p_HA7BRmUaMAASstR.jpg" width="600" alt="Quadrinhos / Storyboard - Geração de Vídeos de Rotina Matinal usando o Kling 3.0 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964577426_90m0yz_HA7BRKBagAAapve.jpg" width="600" alt="Quadrinhos / Storyboard - Geração de Vídeos de Rotina Matinal usando o Kling 3.0 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964577404_n9hur8_HA7BQzZa4AAXLYg.jpg" width="600" alt="Quadrinhos / Storyboard - Geração de Vídeos de Rotina Matinal usando o Kling 3.0 - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [空想写真家](https://x.com/KusoPhoto)
- **Fonte:** [Twitter Post](https://x.com/KusoPhoto/status/2021805656643449018)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9956)**

---

### No. 71: Quadrinhos / Storyboard - Prompt de Vídeo de Ação Cinematográfica: Fada Banana vs. Zumbis

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um prompt detalhado de geração de vídeo para Vidu AI, criando uma cena de ação cinematográfica onde uma garota fada-banana luta contra zumbis usando apenas bananas como armas em um espaço interno fantástico repleto de decorações de banana. O prompt inclui instruções específicas para personagem, cenário, ação, trabalho de câmera, iluminação e estilo.

#### 📝 Prompt

```
Use a mulher da imagem anexa como personagem principal.
O cenário é um espaço interno fantástico cercado por bananas, idêntico à imagem anexa.
Zumbis atacam um após o outro em um espaço forrado com bananeiras e objetos gigantes de banana.
A garota fada da banana rapidamente pega as bananas ao seu redor e as joga em rápida sucessão.
A única arma são as bananas.
As bananas voam retas enquanto giram em alta velocidade, atingindo as cabeças dos zumbis.
O momento do impacto é em câmera lenta.
Fortes efeitos de onda de choque, rastros de luz, desfoque de movimento dinâmico.
Os zumbis atingidos são arremessados, desabando enquanto sacodem as decorações de banana ao redor.
A garota pula em uma banana gigante e joga bananas com precisão enquanto gira.
Enfatize o impacto com um *hero shot* em ângulo baixo.
Câmera de rastreamento dinâmica seguindo as bananas voadoras.

Direção da Câmera:
・*Dolly-in* em alta velocidade em direção à garota
・Tremor intenso estilo câmera na mão quando os zumbis se aproximam
・Câmera lenta no impacto da banana
・*Tracking shot* suave seguindo as bananas voadoras
・Ângulo baixo tenso

Iluminação:
Forte contraste
Luz de contorno enfatizando os contornos
Contraste com a fantástica luz dourada do interior

Estilo:
Ação Cinematográfica de Anime
Alta definição
Animação suave
Forte desfoque de movimento
Composição dinâmica
Profundidade de campo

Atmosfera:
Tensão
Emocionante
Heroico

Sem texto
Sem legendas
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770878363155_j0p2xp_HAwN8BubgAAK_vy.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt de Vídeo de Ação Cinematográfica: Fada Banana vs. Zumbis - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770878363300_ma64sk_HAwN8BxbUAASFKU.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt de Vídeo de Ação Cinematográfica: Fada Banana vs. Zumbis - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770878363149_3ccar2_HAwN8BwbAAAka5J.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt de Vídeo de Ação Cinematográfica: Fada Banana vs. Zumbis - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [うみつる](https://x.com/umitsuru_fire)
- **Fonte:** [Twitter Post](https://x.com/umitsuru_fire/status/2021718579994042687)
- **Publicado:** 11 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9851)**

---

### No. 72: Quadrinhos / Storyboard - Prompt para Criação de Carrossel de Anúncios B2B no Meta

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Uma instrução de alto nível para o Nano Banana Pro gerar uma série de imagens adequadas para um formato de anúncio em carrossel, solicitando especificamente a criação de um criativo de história em quadrinhos para publicidade B2B no Meta.

#### 📝 Prompt

```
Basta dar instruções como transformar a história do carrossel em um criativo de quadrinhos
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792216643_s630gq_HAwXm7pbwAA1wnn.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt para Criação de Carrossel de Anúncios B2B no Meta - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792216650_nszbj7_HAwXm7uaAAYaPf8.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt para Criação de Carrossel de Anúncios B2B no Meta - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792217138_bg1ebr_HAwXm7rbkAAgDsS.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt para Criação de Carrossel de Anúncios B2B no Meta - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770792217710_wfri6e_HAwXm76bsAA10BZ.jpg" width="600" alt="Quadrinhos / Storyboard - Prompt para Criação de Carrossel de Anúncios B2B no Meta - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [二平燎平｜BtoBマーケ×運用型広告｜ハチワレ](https://x.com/BtoB_hachiware)
- **Fonte:** [Twitter Post](https://x.com/BtoB_hachiware/status/2021016299359567957)
- **Publicado:** 10 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9747)**

---

### No. 73: Quadrinhos / Storyboard - Cena Animada em 3D de Pintinhos e um Monstro em Vitórias-Régias

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma imagem em estilo de filme de animação 3D cinematográfico e ultradetalhado. Ele mescla dois conceitos: dois pequenos pintinhos fofos vistos por trás em uma vitória-régia flutuante, e um grande monstro roxo costurado dominando o quadro, ambientado em um exuberante lago de selva com névoa suave.

#### 📝 Prompt

```
Dois pequenos e fofos pintinhos vistos por trás, em pé juntos em uma vitória-régia verde flutuante, com as costas totalmente voltadas para a câmera, mantendo suas proporções e silhuetas exatas.

Os pintinhos estão posicionados no primeiro plano inferior da cena, enquanto o grande monstro roxo costurado permanece dominante no quadro e sutilmente abaixa o olhar.

Ambiente exuberante de lagoa na selva com vitórias-régias flutuantes, névoa suave perto da superfície da água e luz natural quente.

Estilo de filme de animação 3D cinematográfico, ultra detalhado e de alta qualidade, texturas suaves e realistas, sem distorção, sem mudança de estilização.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706187406_vbk20t_HAuYy9dacAEDAlc.jpg" width="600" alt="Quadrinhos / Storyboard - Cena Animada em 3D de Pintinhos e um Monstro em Vitórias-Régias - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Zio.ron | KIND 💫](https://x.com/zioaxie)
- **Fonte:** [Twitter Post](https://x.com/zioaxie/status/2020876867150954931)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9584)**

---

### No. 74: Quadrinhos / Storyboard - Gato Gigante Cinematográfico Persegue Mulher Minúscula

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON estruturado para uma cena cinematográfica 3D fotorrealista ambientada em uma cozinha, apresentando uma disparidade de tamanho. Uma mulher minúscula (com uma referência de rosto) está correndo pelo chão segurando um pastor alemão assustado, enquanto é perseguida por um gato cinza gigante e fofo. Ele especifica iluminação dramática quente, profundidade de campo rasa e realismo de nível Pixar.

#### 📝 Prompt

```
{
  "scene": {
    "type": "cinemática 3D fotorrealista",
    "setting": "cozinha",
    "lighting": "dramática e quente",
    "camera": {
      "depth_of_field": "rasa",
      "motion_blur": true,
      "focus": "nítido"
    },
    "props": "espalhados"
  },
  "subjects": [
    {
      "identity": "mulher",
      "size": "minúscula",
      "action": "correndo pelo chão de madeira",
      "holding": "pastor alemão assustado",
      "face_reference": "usar o mesmo rosto da imagem de referência sem alterações"
    },
    {
      "identity": "gato",
      "size": "gigante",
      "appearance": {
        "fur": "cinza fofo",
        "eyes": "amarelos"
      },
      "action": "perseguindo a mulher e o cachorro"
    }
  ],
  "style": {
    "realism": "nível Pixar",
    "detail": "ultradetalhado",
    "resolution": "8K"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706157565_gdcs4d_HAt7RPwb0AAeYc2.png" width="600" alt="Quadrinhos / Storyboard - Gato Gigante Cinematográfico Persegue Mulher Minúscula - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Ana | The AI Girl](https://x.com/WealthEmpireHQ)
- **Fonte:** [Twitter Post](https://x.com/WealthEmpireHQ/status/2020844396699390340)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9544)**

---

### No. 75: Quadrinhos / Storyboard - Cena Cinematográfica Detalhada de Wuxia: Corvo Sombrio vs. Geada Azul

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt extremamente detalhado e com múltiplas cenas, projetado para geração de vídeo ou imagem cinematográfica, com foco em um estilo Wuxia (fantasia de artes marciais chinesas). Ele descreve cinco tomadas de câmera distintas, ações dos personagens, elementos visuais (chuva forte, templo antigo, relâmpagos), movimentos de câmera (Dolly Shot, Crane Up, Bullet Time), diálogo e efeitos sonoros para um confronto dramático entre dois personagens, Dark Raven e Azure Frost.

#### 📝 Prompt

```
**Estilo Geral:** Estilo de fantasia Wuxia chinês, qualidade cinematográfica, desfoque de movimento, templo antigo abandonado sob chuva forte, céu sombrio, relâmpagos ocasionalmente iluminando gotas de chuva e beirais quebrados, a imagem é cheia de poder e velocidade.

• **Cena 1 (0-3 segundos): Dark Raven arrasta sua espada, Azure Frost desce**
• **Visuais:** A chuva cai torrencialmente. Dark Raven veste uma armadura preta pesada emanando uma aura roxa sinistra, arrastando uma enorme espada de ferro escuro acorrentada com uma mão. A lâmina raspa o chão de pedra, criando faíscas deslumbrantes e ondulações. Seus olhos são sinistros enquanto ele olha para frente. Imediatamente depois, Azure Frost desce levemente dos beirais quebrados do templo antigo como uma folha caindo. Sua roupa justa branca e ciano é afiada, seu rabo de cavalo alto voa, e a longa espada azul em sua mão é desembainhada com um som de 'zheng', sua aura fria empurrando para trás a cortina de chuva circundante. Os dois se encaram na chuva.
• **Cinematografia:** Plano de acompanhamento de ângulo extremamente baixo rastreando o caminho da espada, então a câmera recua rapidamente para mostrar a visão completa do confronto no pátio chuvoso — um preto e pesado, o outro ciano e leve.
• **Diálogo/Efeitos Sonoros:** Dark Raven (baixo e rouco): "{argument name="Dark Raven dialogue" default="Você está além da redenção."}"
• **Efeitos Sonoros:** Raspagem de metal pesado, chuva torrencial, vento.

• **Cena 2 (3-6 segundos): Grande espada varre, espada leve ataca como um flash**
• **Visuais:** Dark Raven de repente exerce força, balançando a grande espada com os dois braços. Uma energia de espada negra em forma de crescente rasga a cortina de chuva e varre. Gotas de chuva evaporam em seu caminho, e o chão de pedra é arado. Os olhos de Azure Frost se estreitam. Tocando a superfície da água com o dedo do pé, seu corpo dispara como uma pipa, executando um salto lateral ágil no ar, evitando por pouco a energia da espada. Ao mesmo tempo, usando o impulso de sua descida, a luz fria da ponta de sua espada se condensa, atingindo diretamente a garganta de Dark Raven como um meteoro.
• **Cinematografia:** Cortes rápidos. Primeiro, um plano de acompanhamento lateral (Dolly Shot) captura a energia da espada negra cortando inúmeras gotas de chuva em câmera lenta, então muda para uma visão de ângulo alto, mostrando a trajetória graciosa da evasão aérea e contra-ataque de Azure Frost.
• **Efeitos Sonoros:** Assobio pesado da grande espada cortando o ar, som de 'chichi' da energia da espada evaporando, som de roupas rasgando o vento.

• **Cena 3 (6-9 segundos): Confronto no ar, faíscas voam**
• **Visuais:** Dark Raven balança sua grande espada para trás, colidindo precisamente com a longa espada descendente de Azure Frost! "Clang—!" O imenso poder da grande espada colide ferozmente com a ágil aura fria da longa espada, irrompendo em faíscas azul-brancas deslumbrantes e uma onda de choque que afasta toda a chuva circundante. Dark Raven pressiona com sua vantagem de força, enquanto Azure Frost usa seu jogo de pés leve, tocando a grande espada com o dedo do pé, usando a força para dar um salto para trás e resolver a imensa pressão.
• **Cinematografia:** Plano orbital (Bullet Time). A câmera se centraliza no ponto de colisão da arma, girando 360 graus rapidamente, finalmente congelando em um close-up do momento de faíscas máximas e as duas forças se contrapondo.
• **Diálogo/Efeitos Sonoros:** Azure Frost (fria e firme): "{argument name="Azure Frost dialogue" default="O mal não prevalecerá!"}"
• **Efeitos Sonoros:** Grande rugido de colisão de metal, zumbido de confronto de poder.

• **Cena 4 (9-12 segundos): Sombras azuis contínuas, parede negra defende**
• **Visuais:** No momento em que ela aterrissa, Azure Frost lança um ataque. Sua figura se transforma em um rastro ciano, sua longa espada apunhala rapidamente, transformando-se instantaneamente em várias luzes de espada cianas ferozes atacando Dark Raven de diferentes ângulos. A aura fria das pontas das espadas deixa rastros de geada no ar. Dark Raven solta um rugido baixo, balançando a pesada grande espada em uma barreira impenetrável, formando um escudo de energia de espada roxo-preto. Em meio aos densos sons de 'ding-dang', as luzes de espada cianas são todas bloqueadas, mas o poderoso impacto ainda força Dark Raven a recuar três passos, cada passo esmagando os tijolos de pedra sob seus pés.
• **Cinematografia:** Plano de acompanhamento manual de um único take (Shaky Cam). A câmera segue de perto a trajetória de ataque de Azure Frost, com um leve tremor acompanhando cada apunhalada, então rapidamente se move para a defesa e recuo de Dark Raven, criando um forte senso de imersão.
• **Efeitos Sonoros:** Som denso e nítido das pontas das espadas atingindo a barreira, som de tijolos de pedra rachando, passos pesados e ofegantes.

• **Cena 5 (12-15 segundos): Colisão final, engolindo o universo**
• **Visuais:** Dark Raven está enfurecido, injetando toda a sua energia roxa na grande espada, cravando-a no chão! Boom! Uma espessa coluna de luz roxo-preta dispara para o céu, agitando as nuvens acima. Azure Frost não mostra medo, derramando toda a sua energia fria em sua espada. Homem e espada se tornam um, transformando-se em um enorme e puro fluxo de luz ciano, descendo como um cometa, atingindo diretamente o centro da coluna de luz. Os dois colidem com um rugido! O tempo parece parar, seguido por uma luz branca explosiva e ofuscante e uma onda de ar circular que varre toda a chuva, detritos e folhas mortas em todo o pátio.
• **Cinematografia:** Zoom out rápido de close-up. Primeiro, cortes rápidos entre close-ups dos olhos frios de Dark Raven e dos olhos determinados de Azure Frost, então a câmera sobe e recua rapidamente como um foguete (Crane Up), transformando-se em uma visão aérea distante, mostrando a chocante cena completa da luz branca em expansão e da onda de ar varrendo as ruínas do templo antigo. A imagem congela no pico da luz branca.
• **Diálogo/Efeitos Sonoros:** (Antes da colisão) O rugido de Dark Raven e o grito claro de Azure Frost se entrelaçam.
• **Efeitos Sonoros:** Zumbido de convergência de energia, explosão estrondosa, seguido por todos os sons desaparecendo, deixando apenas o eco da chuva recuando.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706236748_k3nyz6_HArlGrtaIAEz-bU.jpg" width="600" alt="Quadrinhos / Storyboard - Cena Cinematográfica Detalhada de Wuxia: Corvo Sombrio vs. Geada Azul - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770706236742_vjdtu2_HArlGrybAAE558O.jpg" width="600" alt="Quadrinhos / Storyboard - Cena Cinematográfica Detalhada de Wuxia: Corvo Sombrio vs. Geada Azul - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [李岳](https://x.com/liyue_ai)
- **Fonte:** [Twitter Post](https://x.com/liyue_ai/status/2020680415896567886)
- **Publicado:** 9 de fevereiro de 2026
- **Idiomas:** zh

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9643)**

---

### No. 76: Quadrinhos / Storyboard - Ana de Armas fotorrealista como Mulher-Aranha em um banheiro doméstico

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente detalhado e fotorrealista, projetado para gerar um plano médio de Ana de Armas em um body preto justo, inspirado no Homem-Aranha, em um ambiente de banheiro doméstico. O prompt especifica detalhes técnicos como resolução 8k, lente de 35mm e iluminação interna suave para alcançar um estilo de fotografia de celebridade.

#### 📝 Prompt

```
{
  "prompt_data": {
    "positive_prompt": "Plano médio fotorrealista de {argument name=\"character\" default=\"Ana de Armas\"} em um banheiro doméstico, vestindo um body preto justo sem mangas inspirado no Homem-Aranha. O traje apresenta gola alta, um padrão de teia de aranha cinza escuro e um grande emblema de aranha no peito. Ela tem cabelo castanho escuro preso em um rabo de cavalo alto e bagunçado com mechas soltas emoldurando o rosto. Ela está apoiando uma das mãos em uma bancada de granito salpicado de vermelho e preto. Ao fundo, há uma porta de madeira com um painel de vidro fosco e um pôster emoldurado de uma revista em quadrinhos vintage dos Vingadores pendurado em uma parede branca. Iluminação interna suave e natural, resolução 8k, textura de pele altamente detalhada, fotografado com lente de 35mm.",
    "negative_prompt": "desenho animado, ilustração, renderização 3d, anime, esboço, pintura, baixa qualidade, artefatos jpeg, desfoque, anatomia ruim, dedos extras, mãos deformadas, vesgo, texto, marca d'água, assinatura, feio, rosto distorcido",
    "subject_details": {
      "character": "Ana de Armas",
      "outfit": "Body preto da Mulher-Aranha, gola alta, sem mangas, textura de teia de aranha, logotipo no peito, meias pretas até a coxa visíveis",
      "hair_style": "Castanho escuro, rabo de cavalo alto, ondas bagunçadas",
      "pose": "De pé, de frente, mão apoiada na bancada, contato visual direto"
    },
    "environment_details": {
      "setting": "Banheiro",
      "elements": [
        "Bancada de granito vermelho",
        "Porta de madeira com inserção vertical de vidro fosco",
        "Pôster emoldurado de revista em quadrinhos dos Vingadores (capa do Capitão América)",
        "Toalheiro prateado",
        "Paredes brancas"
      ]
    },
    "technical_settings": {
      "style": "Realismo, Fotografia de Celebridades",
      "lighting": "Iluminação interna difusa suave",
      "aspect_ratio": "9:16",
      "camera_angle": "Nível dos olhos"
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619696412_ddxrmu_HAnoTyoacAEl96i.jpg" width="600" alt="Quadrinhos / Storyboard - Ana de Armas fotorrealista como Mulher-Aranha em um banheiro doméstico - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619696500_flcohd_HAnod9kaYAA0rtM.jpg" width="600" alt="Quadrinhos / Storyboard - Ana de Armas fotorrealista como Mulher-Aranha em um banheiro doméstico - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Shourya](https://x.com/ShouryaAI)
- **Fonte:** [Twitter Post](https://x.com/ShouryaAI/status/2020401570115166362)
- **Publicado:** 8 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9456)**

---

### No. 77: Quadrinhos / Storyboard - Fluxo de Trabalho de Engenharia de Prompt Nanobanana

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um usuário descreve seu fluxo de trabalho para criar prompts Nanobanana de alta qualidade usando uma ferramenta personalizada. O processo envolve definir o assunto (por exemplo, urso polar e panda em patins), gerar a imagem inicial, realizar anotações detalhadas (rotulando partes como pose, fundo, rosto, vestuário) com base nos nomes dos arquivos e, finalmente, adicionar informações composicionais e de cor para a geração final. Isso destaca a importância da especificação detalhada da linguagem para um prompting eficaz.

#### 📝 Prompt

```
① Crie um "{argument name="character 1" default="Urso Polar"}" e um "{argument name="character 2" default="Panda"}" usando patins de gelo, e o local do fundo. A entrada normal baseada em chat também é aceitável. Seja gerando tudo de uma vez ou separadamente, o processo é o mesmo.

② Faça anotações na imagem.
Esta é a parte mais problemática, então a transformei em uma ferramenta.
Com base no nome do arquivo, crio um prompt que organiza "qual parte de qual imagem referenciar".
(Pose / Fundo / Rosto / Roupa, etc.)

③ Adicione informações suplementares, como composição e esquema de cores para a geração final.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619737797_xj5d3j_HAmaJHFaAAAPDFJ.jpg" width="600" alt="Quadrinhos / Storyboard - Fluxo de Trabalho de Engenharia de Prompt Nanobanana - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619737787_y8efis_HAmaN7pbsAAFcmD.jpg" width="600" alt="Quadrinhos / Storyboard - Fluxo de Trabalho de Engenharia de Prompt Nanobanana - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619737805_5qjy6g_HAmaMa2acAYMRUE.jpg" width="600" alt="Quadrinhos / Storyboard - Fluxo de Trabalho de Engenharia de Prompt Nanobanana - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770619738587_agd864_HAmaPYDakAAdbMm.jpg" width="600" alt="Quadrinhos / Storyboard - Fluxo de Trabalho de Engenharia de Prompt Nanobanana - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [ターさん](https://x.com/CEs7J0Mfn8x37k5)
- **Fonte:** [Twitter Post](https://x.com/CEs7J0Mfn8x37k5/status/2020320685948879098)
- **Publicado:** 8 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9514)**

---

### No. 78: Quadrinhos / Storyboard - Modelo de Ilustração de Pôster de História em Quadrinhos

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um modelo de prompt JSON estruturado para Nano Banana Pro, projetado para gerar uma ilustração de pôster de história em quadrinhos dinâmica e moderna (proporção de tela 16:9) com uma colagem de painéis de quadrinhos, efeitos de meio-tom e iluminação dramática. Inclui espaços reservados para o personagem principal, título e conteúdo específico do painel, e exige a preservação rigorosa da identidade a partir de uma imagem de referência.

#### 📝 Prompt

```
{
  "meta": {
    "purpose": "Ilustração de pôster de história em quadrinhos para narrativa de ficção científica viral ou graphic novels",
    "style": "Quadrinhos/graphic novel moderna com meio-tom e efeitos dinâmicos, resolução 4K"
  },
  "reference_image": {
    "use": true,
    "identity_preservation": "strict",
    "face_similarity": "high"
  },
  "canvas": {
    "aspect_ratio": "16:9",
    "orientation": "pôster horizontal"
  },
  "title_text": {
    "text": "{argument name=\"title text\" default=\"ZOOM!!! OU Seu Título\"}",
    "position": "top_center",
    "style": "letras de quadrinhos em negrito, fonte grossa desenhada à mão",
    "color": "branco creme com contorno preto",
    "effects": ["relevo 3D", "sombra de tinta", "textura de meio-tom"]
  },
  "main_character": {
    "subject": "{argument name=\"main character\" default=\"Piloto espacial com implante metálico OU Seu herói\"}",
    "pose": "[ex: Heroico e zangado OU Ação dinâmica]",
    "lighting": "iluminação de contorno dramática",
    "render_style": "Ilustração de quadrinhos de Anime japonês"
  },
  "comic_panels": [
    {
      "position": "top_left",
      "subject": "[ex: Close-up extremo atrás de vidro rachado]",
      "expression": "[ex: Zangado]",
      "panel_effect": "[ex: Explosão, efeito sonoro CRAAACK]"
    },
    {
      "position": "top_right",
      "subject": "[ex: Boca do piloto aberta]",
      "expression": "[ex: Preocupado]",
      "speech_text": "[ex: NÃOOO!]"
    },
    {
      "position": "bottom_left",
      "subject": "[ex: Perfil de nave espacial]",
      "speech_text": "[ex: WHAAA?!]",
      "motion_lines": true
    },
    {
      "position": "bottom_right",
      "subject": "[ex: Piloto assustado]",
      "speech_text": "[ex: LÁZARO!]",
      "panel_effect": "[ex: Explosão estelar]"
    }
  ],
  "background": {
    "style": "colagem de painéis de quadrinhos",
    "colors": ["laranja", "amarelo", "azul", "verde-azulado"],
    "elements": ["pontos de meio-tom", "respingos de tinta", "linhas de ação", "formas de explosão"],
    "bottom_scene": "[ex: Campo de asteroides com veias de ouro]"
  },
  "art_style": {
    "genre": "história em quadrinhos moderna",
    "influences": ["Capas da Marvel", "Pôsteres da DC", "Pop-art"],
    "line_work": "contornos limpos e ousados",
    "shading": "suave e pictórico com meio-tom"
  },
  "render_quality": {
    "detail_level": "alto",
    "sharpness": "nítido",
    "color_grading": "cinemático vibrante"
  },
  "constraints": {
    "no_blur": true,
    "no_extra_faces": true,
    "no_watermark": true
  },
  "negative_prompt": ["baixa qualidade", "borrado", "membros extras", "rosto distorcido", "anatomia ruim", "foto realista"]
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770532808397_ujmk1l_HAkaf_pXYAAe3ik.jpg" width="600" alt="Quadrinhos / Storyboard - Modelo de Ilustração de Pôster de História em Quadrinhos - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770532808377_1ecwqa_HAkaf_cXUAA3che.jpg" width="600" alt="Quadrinhos / Storyboard - Modelo de Ilustração de Pôster de História em Quadrinhos - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770532809361_jx3iu6_HAkaf_gXgAA_XAA.jpg" width="600" alt="Quadrinhos / Storyboard - Modelo de Ilustração de Pôster de História em Quadrinhos - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770532809700_lpzdgw_HAkaf_hW4AASiEO.jpg" width="600" alt="Quadrinhos / Storyboard - Modelo de Ilustração de Pôster de História em Quadrinhos - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Shah](https://x.com/ai_with_shah)
- **Fonte:** [Twitter Post](https://x.com/ai_with_shah/status/2020175080429371542)
- **Publicado:** 7 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9340)**

---

### No. 79: Marketing de Produto - Retrato de Beleza de Estúdio em High-Key (Cabelo ao Vento, Corset Nude)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON detalhado para gerar um retrato de beleza de estúdio em alto-contraste com um estilo editorial inspirado em K-beauty. Ele especifica uma mulher com cabelo preto longo e esvoaçante, usando um corpete de glitter nude-bege, enfatizando nitidez limpa e nítida, pele macia e luminosa, e um fundo branco mínimo.

#### 📝 Prompt

```
{
  "generation_request": {
    "meta_data": {
      "task_type": "high_key_studio_beauty_portrait_no_text",
      "language": "en",
      "priority": "highest",
      "version": "v1.0_HIGH_KEY_WIND_HAIR_NUDE_CORSET"
    },
    "input": {
      "mode": "text_to_image",
      "notes": "Retrato de beleza em estúdio com iluminação high-key. Sem texto, sem logotipo, sem marca d'água."
    },
    "output": {
      "aspect_ratio": "4:5",
      "resolution": "ultra_high",
      "num_images": 1,
      "sharpness": "clean_crisp",
      "grain": "very_subtle"
    },
    "scene": {
      "environment": "fundo de estúdio minimalista branco sem emendas (high-key), visual editorial limpo",
      "composition": "enquadramento de retrato fechado 3/4 do peito para cima, sujeito posicionado ligeiramente à direita, olhando para a esquerda (fora da câmera), espaço negativo elegante",
      "style": "editorial inspirado em K-beauty, luxo moderno"
    },
    "subject": {
      "person": "mulher adulta",
      "hair": "cabelo preto liso muito longo, brilho natural, mechas sopradas pelo vento cruzando o rosto, fluxo dinâmico",
      "makeup": {
        "skin": "pele luminosa suave e natural, poros realistas, sem retoques pesados",
        "eyes": "sombra esfumada marrom suave, delineador sutil, cílios naturais",
        "lips": "lábio gradiente rosa-nude suave"
      },
      "wardrobe": {
        "top": "corpete espartilho nude-bege com glitter com barbatanas visíveis e brilho sutil, painéis estruturados semitransparentes"
      },
      "pose": "um braço ligeiramente levantado para fora do quadro como se estivesse ajeitando o cabelo, ombros relaxados, linha do pescoço elegante"
    },
    "lighting": {
      "style": "iluminação de beleza de estúdio high-key",
      "key_light": "grande softbox frontal-esquerda, sombras muito suaves",
      "fill_light": "preenchimento forte para renderização de pele limpa",
      "background_light": "fundo branco uniformemente iluminado, sem gradientes",
      "specular": "realces controlados nas maçãs do rosto e clavícula"
    },
    "camera": {
      "lens": "lente de retrato 85mm",
      "aperture": "f/2.8",
      "depth_of_field": "rasa a moderada, olhos nítidos como navalha, fundo perfeitamente suave",
      "color": "brancos neutros, tom de pele preciso"
    },
    "negative_prompt": "texto, tipografia, logotipo, marca d'água, dedos extras, mãos distorcidas, anatomia deformada, pele plástica excessivamente suavizada, HDR pesado, brilho de IA, desenho animado, baixa resolução, desfoque"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310083408_nqzddq_HBTdJmbawAAAFDf.jpg" width="600" alt="Marketing de Produto - Retrato de Beleza de Estúdio em High-Key (Cabelo ao Vento, Corset Nude) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Özge Döner](https://x.com/astronomerozge1)
- **Fonte:** [Twitter Post](https://x.com/astronomerozge1/status/2023485359632326814)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10244)**

---

### No. 80: Marketing de Produto - Pôster Editorial de Beleza e Moda (Composição Dupla em Vermelho)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente detalhado, projetado para gerar um pôster editorial de alta qualidade de beleza e moda. Ele especifica um layout de composição dupla com um retrato de fundo com foco suave e uma figura nítida em primeiro plano, ambientado em um fundo gradiente vermelho escuro profundo, otimizado para a estética de campanhas de maquiagem de luxo, sem texto ou logotipos.

#### 📝 Prompt

```
{
  "generation_request": {
    "meta_data": {
      "task_type": "editorial_beauty_fashion_poster_no_text",
      "language": "pt",
      "priority": "highest",
      "version": "v1.0_GLAM_RED_DUAL_COMPOSITION_NO_TEXT"
    },
    "input": {
      "mode": "text_to_image",
      "notes": "Crie uma composição editorial de beleza e moda de alta qualidade inspirada em um pôster de campanha de maquiagem. Sem texto, sem tipografia, sem logotipos, sem marcas d'água."
    },
    "output": {
      "aspect_ratio": "4:5",
      "resolution": "ultra_high",
      "num_images": 1,
      "sharpness": "high",
      "grain": "subtle_analog"
    },
    "scene": {
      "background": "fundo gradiente vermelho escuro profundo desvanecendo para quase preto na parte inferior, fundo de estúdio suave",
      "composition": "layout editorial de dupla exposição: um grande retrato glamouroso em close-up com foco suave no fundo e uma pose de corpo inteiro em pé no primeiro plano, composição centralizada, camadas de profundidade dramáticas"
    },
    "subject": {
      "person": "mulher adulta",
      "beauty_style": {
        "skin": "pele com brilho nude impecável, contorno suave, maçãs do rosto iluminadas",
        "eyes": "sombra esfumada, cílios definidos, delineador gatinho nítido",
        "lips": "lábios nude brilhantes",
        "hair": "cabelo escuro elegante puxado para trás, penteado limpo e elegante"
      },
      "wardrobe": {
        "dress": "vestido midi coquetel preto justo com alças finas, elegante e minimalista",
        "shoes": "saltos altos pretos",
        "accessories": "brincos statement brilhantes"
      },
      "pose": {
        "foreground_pose": "pose em pé confiante, uma mão no quadril, corpo ligeiramente angulado, olhando para o lado",
        "background_pose": "grande close-up de beleza com olhar suave para a câmera, efeito de movimento ligeiramente borrado"
      }
    },
    "lighting": {
      "style": "iluminação de beleza cinematográfica de estúdio",
      "key_light": "luz frontal difusa suave realçando as maçãs do rosto e a textura da pele",
      "rim_light": "luz de contorno quente sutil separando o sujeito do fundo vermelho",
      "mood": "luxo, glamour, campanha de maquiagem profissional"
    },
    "camera": {
      "lens": "lente de retrato de 85mm para close-up, 50mm para corpo inteiro",
      "depth_of_field": "rasa para retrato de fundo, moderada para figura em primeiro plano",
      "quality": "fotografia editorial de alta qualidade"
    },
    "restrictions": {
      "no_text": true,
      "no_logo": true,
      "no_watermark": true,
      "no_typography": true
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310082614_huqk3l_HBTX12XWgAA4ceC.jpg" width="600" alt="Marketing de Produto - Pôster Editorial de Beleza e Moda (Composição Dupla em Vermelho) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Özge Döner](https://x.com/astronomerozge1)
- **Fonte:** [Twitter Post](https://x.com/astronomerozge1/status/2023479529692655685)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10242)**

---

### No. 81: Marketing de Produto - Foto de Produto de Smartphone Futurista Ultra Premium

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt detalhado para gerar uma foto de produto comercial ultra-premium de um smartphone carro-chefe futurista flutuando sobre uma superfície reflexiva, seguido por um prompt para uma visualização em vista explodida de seus componentes internos, projetado para publicidade de tecnologia de ponta.

#### 📝 Prompt

```
Foto de produto comercial ultra-premium de um smartphone carro-chefe futurista flutuando sobre uma superfície reflexiva. Ângulo de três quartos, bordas metálicas elegantes, tela de ponta a ponta brilhando suavemente. Iluminação de estúdio dramática, fundo gradiente escuro, sutis feixes de luz, reflexos ultralimpídos, estilo de publicidade de tecnologia premium.

Imagem 2: Visualização em vista explodida mostrando componentes internos separados verticalmente — tela de vidro, bateria, chip processador, módulo de câmera, chassi — cada um rotulado com blocos em negrito sem serifa, codificação de cores com detalhes em neon, conectores limpos, fundo de tecnologia escuro.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310069622_rkdepq_HBSjqM4akAEu497.jpg" width="600" alt="Marketing de Produto - Foto de Produto de Smartphone Futurista Ultra Premium - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [𝐌](https://x.com/Strength04_X)
- **Fonte:** [Twitter Post](https://x.com/Strength04_X/status/2023422222057328812)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10220)**

---

### No. 82: Marketing de Produto - Geração de Layout de Página de Scrapbook de Moda

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 Descrição

Um prompt detalhado para gerar um layout de página de scrapbook ou colagem de moda usando o modelo Nano Banana Pro dentro da ferramenta Lovart. O prompt especifica a composição, detalhes do assunto, elementos decorativos como clipes e fita, plano de fundo e estilos de renderização técnica, visando um visual tátil e editorial.

#### 📝 Prompt

```
Obra-prima, altíssima qualidade, alta resolução, (plano de corpo inteiro: 1.5), layout de página de scrapbook de moda, estilo colagem, [Palavra-chave de Tema/Estética]

[Assunto]: Foto de moda de corpo inteiro em plano aberto de [Descrição do Personagem]. [Pose e Ação]. Vestindo [Detalhes da Roupa], [Acessórios], (sapatos visíveis: 1.3), físico perfeito da cabeça aos pés.

[Composição]: A imagem é projetada como um [Metáfora de Layout: Zine DIY / Dossiê de Campo / Mood Board], com o personagem principal centralizado e cercado por (3 fotos polaroid diferentes: 1.3). Cada uma dessas fotos mostra diferentes detalhes de [Tema]: (1 close-up de [Detalhes do Rosto/Maquiagem]: 1.2), 1 macro de [Detalhes do Tecido/Textura/Arma]: 1.2), (1 detalhe de [Detalhes do Sapato/Acessório]: 1.2). Isso garante que as fotos inseridas não se sobreponham e sejam únicas.

[Decoração]: Elementos de scrapbooking [Estilo], papel [Espessura do Papel] amarrado com [Tipo de Clipe: Clipe Prateado / Clipe Dourado / Clipe Enferrujado], fita [Tipo de Fita: Washi / Durex / Crepe], [Tipo de Rabisco: Seta / Estrela / Grafite] desenhado à mão, anotações de texto manuscritas em [Tipo de Tinta] (ex: [Texto Curto 1], [Texto Curto 2]), [Adesivos/Carimbos], textura de papel rasgado.
Nota: As anotações de texto estão em japonês.

[Fundo]: (Uma pilha bagunçada de [Tipo de Papel: Papel em Branco / Papelão / Mapa / Pasta]: 1.4), camadas de bordas de papel sob a folha principal, profundidade e sombra realistas entre as camadas de papel, colocadas em [Material e Cor da Superfície].

[Técnico]: [Estilo de Iluminação], [Atmosfera], foco nítido, fotografia editorial, 8k, textura tátil, renderização de material realista.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310092658_hio6vm_HBCQ5qXawAIdehh.jpg" width="600" alt="Marketing de Produto - Geração de Layout de Página de Scrapbook de Moda - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310093023_58bk46_HBCQ5yVa8AAhsS5.jpg" width="600" alt="Marketing de Produto - Geração de Layout de Página de Scrapbook de Moda - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Lovart 公式 (ラブアート)](https://x.com/lovart_jp)
- **Fonte:** [Twitter Post](https://x.com/lovart_jp/status/2023321458085368091)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** ja

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10262)**

---

### No. 83: Marketing de Produto - Macrofotografia de Trabalhadores em Miniatura Limpando Cinzeiro

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt estruturado para gerar uma fotografia macro cinematográfica ultrarrealista simbolizando o abandono do tabagismo, apresentando trabalhadores da construção em miniatura limpando um cinzeiro gigante cheio de bitucas de cigarro e cinzas, enfatizando a profundidade de campo rasa e a iluminação de estúdio quente e direcional.

#### 📝 Prompt

```
{
  "style": "fotografia macro cinematográfica ultrarrealista",
  "subject": "operários de construção em miniatura limpando um cinzeiro gigante cheio de bitucas de cigarro e cinzas",
  "composition": "ângulo de três quartos de cima para baixo, assunto centralizado, corte justo, enquadramento estilo anúncio",
  "lighting": "luz de estúdio direcional quente com sombras suaves e raios volumétricos sutis",
  "camera": {
    "lens": "macro 85mm",
    "aperture": "f/2.8",
    "depth_of_field": "muito rasa",
    "focus": "operário da frente e bitucas de cigarro"
  },
  "textures": "cinzas de alta definição, superfície de cinzeiro de cerâmica, textura realista de papel e tabaco",
  "mood": "sério, simbólico, metáfora de limpeza",
  "color_grading": "tons cinematográficos neutros quentes",
  "quality": "fotorrealista, nível de publicidade comercial",
  "effects": ["partículas de micro poeira", "granulação de filme natural"],
  "avoid": ["estilo cartoon", "pele de plástico", "saturação excessiva", "aparência de CGI"]
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310082083_blvucr_HBRH2g0aMAADZCC.jpg" width="600" alt="Marketing de Produto - Macrofotografia de Trabalhadores em Miniatura Limpando Cinzeiro - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Maercih](https://x.com/Maercihh)
- **Fonte:** [Twitter Post](https://x.com/Maercihh/status/2023321151129436314)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10241)**

---

### No. 84: Marketing de Produto - Editorial de Alta Costura com Ana de Armas em Paris

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt projetado para gerar uma imagem editorial de alta moda e fotorrealista de uma jovem mulher que se assemelha a Ana de Armas. A cena é uma varanda de luxo em um terraço em Paris com a Torre Eiffel visível, apresentando iluminação cinematográfica dramática e detalhes específicos de guarda-roupa, como um blazer-vestido azul-marinho risca de giz e batom escuro.

#### 📝 Prompt

```
Use o mesmo rosto da imagem de referência sem alterar as características faciais

mulher jovem deslumbrante com cabelo longo loiro platinado, maquiagem glamorosa pesada, olhos azuis, lábios carnudos com batom escuro, expressão sedutora com a língua ligeiramente para fora, segurando óculos pretos na frente da boca, vestido blazer azul marinho risca de giz com decote profundo e gargantilha, saia muito curta, vista até a coxa, posando em uma varanda de luxo na cobertura, Torre Eiffel ao fundo, céu dramático e nublado de Paris, estilo editorial de alta moda, iluminação cinematográfica, ultra detalhado, fotorrealista
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310084021_hqma47_HBQ802tbYAAJ5y8.jpg" width="600" alt="Marketing de Produto - Editorial de Alta Costura com Ana de Armas em Paris - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Pervez Hussain](https://x.com/pervez0123)
- **Fonte:** [Twitter Post](https://x.com/pervez0123/status/2023309033139265783)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10245)**

---

### No. 85: Marketing de Produto - Ensaio Fotográfico de Alta Costura em Sala de Cubos de Jornal

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma fotografia de estúdio de alta-costura de uma mulher elegante sentada em uma sala completamente coberta por jornais vintage, enfatizando iluminação cinematográfica e detalhes ultrarrealistas.

#### 📝 Prompt

```
Um ensaio fotográfico de alta-costura em estúdio de uma mulher elegante sentada com confiança em uma cadeira bege moderna dentro de uma sala em formato de cubo totalmente coberta com jornais vintage, vestindo um top vermelho justo, minissaia branca, tênis vermelho e branco e óculos de sol pretos, pose relaxada com a mão tocando o cabelo, iluminação cinematográfica, fotografia de moda ultrarrealista, detalhes em 8K, foco nítido.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310069824_hu4sh4_HBQUUkOagAENd8i.jpg" width="600" alt="Marketing de Produto - Ensaio Fotográfico de Alta Costura em Sala de Cubos de Jornal - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310071265_nshbjr_HBQUWBRaMAAfp7O.jpg" width="600" alt="Marketing de Produto - Ensaio Fotográfico de Alta Costura em Sala de Cubos de Jornal - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Synthia](https://x.com/AIwithSynthia)
- **Fonte:** [Twitter Post](https://x.com/AIwithSynthia/status/2023264704052039700)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10223)**

---

### No. 86: Marketing de Produto - Close-up Cinematográfico de Homem em Trator Segurando Flor Silvestre

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente detalhado e complexo para gerar uma tomada em close-up ultra-fotorrealista e cinematográfica de um homem sentado dentro de um trator coberto de carpete em um deserto, segurando uma delicada flor silvestre branca, enfatizando uma perspectiva dramática de ângulo baixo, microdetalhes e uma paleta de cores suaves e tempestuosas.

#### 📝 Prompt

```
Fotografia cinematográfica em close-up ultradetalhada, ultra-fotorrealista, resolução 8K, tirada com uma Hasselblad H6D-400c de médio formato com uma lente de retrato de 100mm f/2.8. Nitidez impecável combinada com profundidade de campo cinematográfica rasa, iluminação de nível de filme, granulação sutil, visual de fotografia de blockbuster.
Cabelo preto, molhado e cacheado até o queixo. Preservar estritamente da primeira foto anexada, sem distorção. Usando óculos de sol retangulares pretos e um blazer preto oversized e volumoso.
Close-up extremo de um ângulo baixo dramático olhando para cima, perspectiva distorcida. Em primeiro plano, uma mão segurando uma delicada flor silvestre branca ligeiramente fora de foco. O homem está sentado dentro de um trator Belarus 82.1 completamente coberto de carpete, inclinando-se para fora da janela lateral. O trator está estacionado em uma vasta paisagem desértica sem vida que se estende até o horizonte.
Céu pesado e nublado, atmosfera de tempestade, luz suave e difusa rompendo as nuvens, paleta de cores suaves, tons cinematográficos dessaturados, gradação sutil de ciano e laranja.
Forte ênfase em microdetalhes faciais, poros, textura da pele, umidade nos fios de cabelo, rugas no tecido do blazer, fibras do carpete na carroceria do trator. Raios de luz volumétricos, névoa atmosférica, fotografia de moda editorial misturada com still de filme épico, realismo estilo IMAX, humor dramático, hiperdetalhado, ultra-nítido, 8K.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310071060_91tfsd_HBQL2ppaoAETIVT.jpg" width="600" alt="Marketing de Produto - Close-up Cinematográfico de Homem em Trator Segurando Flor Silvestre - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Dr. Samia](https://x.com/oye_samia)
- **Fonte:** [Twitter Post](https://x.com/oye_samia/status/2023255190179394040)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10221)**

---

### No. 87: Marketing de Produto - Editorial de Alta Costura com Desfoque de Movimento

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um editorial de revista de alta costura de um homem com aparência alpina parado, enquanto é cercado por silhuetas borradas de pessoas passando, enfatizando o contraste entre a aparência estática e o desfoque de movimento, com um fundo limpo, brilhante e ligeiramente abstrato.

#### 📝 Prompt

```
Uma sessão de fotos de alta costura de um homem com aparência alpina, na casa dos 25 anos, que está parado, olhando para a câmera, virando a cabeça para o centro, cercado por uma silhueta borrada de pessoas passando. Ele tem um olhar calmo e estóico no rosto e está usando um traje de assalto marrom com capuz. O fundo é limpo, brilhante e ligeiramente abstrato e enfatiza o contraste entre o desfoque de movimento e a aparência estática. Estilo de edição, composição de filme, fotografia de arte pura, textura de revista suave, alta resolução. --ar 4:5 --raw
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310081636_uncmso_HBQHKtzbsAA38vJ.jpg" width="600" alt="Marketing de Produto - Editorial de Alta Costura com Desfoque de Movimento - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [K](https://x.com/ChillaiKalan__)
- **Fonte:** [Twitter Post](https://x.com/ChillaiKalan__/status/2023250017247748395)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10240)**

---

### No. 88: Marketing de Produto - Fotografia Macro de Comida de Rua Flutuante

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma macrofotografia ultrarrealista de uma sobremesa ou lanche crocante partido no ar, com recheio pegajoso esticando entre as metades, em um cenário de mercado noturno com luzes bokeh quentes.

#### 📝 Prompt

```
Comida de rua flutuante ultrarrealista, sobremesa/salgado crocante partido no ar, recheio de caramelo/queijo pegajoso esticando entre as metades, migalhas e partículas de vapor voando, fundo de mercado noturno com luzes bokeh quentes, profundidade de campo rasa, iluminação dramática, fotografia macro de alimentos, alto detalhe, 8K, foco nítido, cinematográfico, vapor volumétrico.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310076605_gjp4i5_HBP_vpvaAAAQT51.jpg" width="600" alt="Marketing de Produto - Fotografia Macro de Comida de Rua Flutuante - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310076581_xnellc_HBP_vnaaYAAoT7V.jpg" width="600" alt="Marketing de Produto - Fotografia Macro de Comida de Rua Flutuante - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310076713_uwe4hk_HBP_vlla0AAQFFE.jpg" width="600" alt="Marketing de Produto - Fotografia Macro de Comida de Rua Flutuante - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310077863_vsy1xi_HBP_vzVa0AA9Sx-.jpg" width="600" alt="Marketing de Produto - Fotografia Macro de Comida de Rua Flutuante - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Taaruk](https://x.com/Taaruk_)
- **Fonte:** [Twitter Post](https://x.com/Taaruk_/status/2023241864363876515)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10232)**

---

### No. 89: Marketing de Produto - Tríptico Editorial de Moda Monocromática (Feminino)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um tríptico editorial de moda minimalista monocromático (três quadros cinematográficos empilhados) de uma jovem, com foco na preservação das características da modelo a partir de uma imagem de referência, e utilizando iluminação suave Rembrandt para transmitir força tranquila e elegância.

#### 📝 Prompt

```
Preserve o rosto, as proporções e as características externas da modelo como na referência. Um tríptico editorial de moda minimalista monocromático apresentando três quadros cinematográficos empilhados. A modelo é uma jovem mulher com cabelo escuro de comprimento médio, maquiagem natural e traços elegantes.

Quadro 1: Emocional e introspectiva, olhando para baixo com uma mão suavemente perto da clavícula, destacando as maçãs do rosto e a estrutura óssea com iluminação suave Rembrandt.
Quadro 2: Um close nítido de perfil enfatizando o nariz, os lábios e a mandíbula graciosa, com o olhar ligeiramente direcionado para cima para uma aparência elegante e confiante.
Quadro 3: Um retrato frontal e pensativo com ombros relaxados e contato visual direto, transmitindo força tranquila e elegância.
A composição é limpa e moderna, usando um top branco ajustado e joias douradas delicadas para continuidade visual. Qualidade de revista comercial, fotografado com uma câmera mirrorless de alta qualidade, com textura de pele autêntica, bokeh suave e sofisticação cinematográfica. Elegância feminina e sensibilidade de moda contemporânea.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310080127_vhedin_HBP-POtaUAAabga.jpg" width="600" alt="Marketing de Produto - Tríptico Editorial de Moda Monocromática (Feminino) - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310080160_6uys42_HBP-POvbwAA_kYK.jpg" width="600" alt="Marketing de Produto - Tríptico Editorial de Moda Monocromática (Feminino) - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Cherry 2.O](https://x.com/Mind_Boticni)
- **Fonte:** [Twitter Post](https://x.com/Mind_Boticni/status/2023240208700113185)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10236)**

---

### No. 90: Marketing de Produto - Tríptico Editorial de Moda Monocromática (Masculino)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um tríptico editorial de moda minimalista monocromático (três quadros cinematográficos empilhados) de um jovem, com foco em preservar as características do modelo a partir de uma imagem de referência, e utilizando iluminação Rembrandt para realçar a estrutura óssea e a elegância masculina.

#### 📝 Prompt

```
Preserve o rosto, as proporções e as características externas do modelo como na referência. Um tríptico editorial de moda minimalista monocromático apresentando três quadros cinematográficos empilhados. O sujeito é um jovem com cabelo escuro curto e barba bem cuidada. Quadro 1: Emocional e introspectivo, olhando para baixo com uma mão perto da clavícula, destacando a estrutura óssea com iluminação Rembrandt. Quadro 2: Um close de perfil nítido com foco no nariz, lábios e linha da mandíbula masculina, com o olhar ligeiramente para cima. Quadro 3: Um retrato frontal e pensativo com os ombros relaxados e contato visual direto. A composição é limpa e moderna, usando uma camiseta branca e um colar dourado para continuidade visual. Qualidade de revista comercial, câmera mirrorless de alta qualidade, poros de pele autênticos, bokeh suave e masculinidade elegante.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310072481_r7ak0h_HBP1Y-HbYAAMbLE.jpg" width="600" alt="Marketing de Produto - Tríptico Editorial de Moda Monocromática (Masculino) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Harboriis](https://x.com/harboriis)
- **Fonte:** [Twitter Post](https://x.com/harboriis/status/2023230471061315992)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10224)**

---

### No. 91: Marketing de Produto - Close-up de Publicidade de Lata de Sprite

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt técnico e altamente estruturado para gerar uma macrofotografia com qualidade de publicidade de uma lata clássica de Sprite de alumínio, detalhando condensação, dinâmica de fluidos (cítricos explodindo e respingos congelados), especificações do equipamento de iluminação e gradação de cores.

#### 📝 Prompt

```
{
  "image_request": {
    "metadata": {
      "product": "Sprite",
      "flavor_profile": "Limão-Lima",
      "quality": "Grau Publicitário"
    },
    "subject": {
      "primary": "Lata de alumínio clássica verde Sprite",
      "positioning": "Em pé, inclinação de 5 graus para frente",
      "branding": "Logotipo de alta fidelidade, centralizado, sem distorção",
      "surface_physics": {
        "temperature": "Gelado",
        "condensation": "Microgotículas densas",
        "gravity_effects": "Rastros verticais de umidade",
        "reflectivity": "Destaques especulares nítidos"
      }
    },
    "vfx_environment": {
      "particle_effects": [
        "Fatias frescas de limão explodindo para fora",
        "Fatias de lima em explosão radial em câmera lenta"
      ],
      "fluid_dynamics": {
        "state": "Salpicos congelados no ar",
        "properties": [
          "Bolhas de carbonatação efervescentes",
          "Arcos de líquido transparente refrativos",
          "Spray de microgotículas"
        ]
      },
      "background_layer": {
        "element": "Grande seção transversal de limão retroiluminada",
        "filter": "Desfoque gaussiano / Bokeh cremoso",
        "purpose": "Efeito de halo de profundidade de campo"
      }
    },
    "lighting_rig": {
      "key_light": "Preenchimento de estúdio de alto contraste",
      "backlight": "Brilho branco frio através do cítrico",
      "rim_light": "Definição de borda verde-limão elétrico",
      "global_illumination": "Realismo cinematográfico"
    },
    "render_settings": {
      "aspect_ratio": "1:1",
      "focus_mode": "Macro / Ultra-nítido na textura do alumínio",
      "color_grading": {
        "primary": "# (Verde Esmeralda)",
        "accent": "(Amarelo Limão)",
        "highlights": "(Prata Frio)"
      }
    },
    "negative_constraints": [
      "Sem sobreposições de texto",
      "Sem desfoque de movimento no objeto principal",
      "Sem suportes",
      "Sem bordas"
    ]
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310077277_mbqhvq_HBPprlUbMAAK_R1.jpg" width="600" alt="Marketing de Produto - Close-up de Publicidade de Lata de Sprite - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310076897_1qaetz_HBPprq6b0AA3fk2.jpg" width="600" alt="Marketing de Produto - Close-up de Publicidade de Lata de Sprite - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310077090_0gyile_HBPprjBbUAAQ4mv.jpg" width="600" alt="Marketing de Produto - Close-up de Publicidade de Lata de Sprite - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310078372_2rdo5i_HBPprw8bgAEjsqG.jpg" width="600" alt="Marketing de Produto - Close-up de Publicidade de Lata de Sprite - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Meem](https://x.com/mehvishs25)
- **Fonte:** [Twitter Post](https://x.com/mehvishs25/status/2023217617411150063)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10233)**

---

### No. 92: Imagem Principal de E-commerce - Prompt de Anúncio de Produto Miniatura Hiper-Realista

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt de macrofotografia versátil, projetado para criar anúncios de produtos em miniatura hiper-realistas. Ele usa espaços reservados para o produto, material e cor de fundo, enfatizando mockups de alta qualidade, iluminação profissional e profundidade de campo rasa.

#### 📝 Prompt

```
macro fotografia, estilo de publicidade minimalista, uma miniatura hiper-realista de {argument name="product" default="[PRODUCT]"} feita de {argument name="material" default="[MATERIAL]"}, delicadamente equilibrada entre o polegar e o indicador de uma pessoa contra um ciclorama contínuo e fosco de cor {argument name="background color" default="[BG_COLOR]"} sob um holofote profissional Top-Down_Spotlight que projeta sombras sutis e suaves, com a mão impecavelmente cuidada acentuando os contornos intrincados do objeto, enquanto a composição permanece perfeitamente centralizada com uma profundidade de campo rasa para destacar seu artesanato requintado
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223961364_iq65ey_HBO8adjaIAAXS9U.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Anúncio de Produto Miniatura Hiper-Realista - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223961241_yyns5u_HBO6yc9awAA10yL.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Anúncio de Produto Miniatura Hiper-Realista - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223961321_8sl55a_HBO6ycZXsAAe9Lz.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Anúncio de Produto Miniatura Hiper-Realista - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223961961_gehtxf_HBO9eUpWUAA0hlI.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Anúncio de Produto Miniatura Hiper-Realista - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Kris Kashtanova](https://x.com/icreatelife)
- **Fonte:** [Twitter Post](https://x.com/icreatelife/status/2023170582796542373)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10166)**

---

### No. 93: Imagem Principal de E-commerce - **Prompt de Edição de Imagem: Ajustando a Posição do Anel**

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt de texto para o Nano Banana editar uma imagem alterando a posição vertical de um anel no lado direito da imagem, deixando o anel do lado esquerdo intocado.

#### 📝 Prompt

```
mude a imagem 1 para que os anéis tenham o posicionamento da imagem 2. você só precisa mover o anel do lado direito para cima, não toque no anel do lado esquerdo. nenhuma outra alteração.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223986446_7m1xm5_HBKkeg_WQAAJI_O.jpg" width="600" alt="Imagem Principal de E-commerce - **Prompt de Edição de Imagem: Ajustando a Posição do Anel** - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Wirelyss 👁️‍🗨️💫](https://x.com/wirelyss)
- **Fonte:** [Twitter Post](https://x.com/wirelyss/status/2022860179432149356)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10216)**

---

### No. 94: Imagem Principal de E-commerce - Close-up de Objeto de Vidro Fundido Óptico com Cáusticas

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente técnico para gerar uma foto macro hero de altíssima proximidade de um assunto especificado, renderizado como vidro óptico fundido premium, focando em realces internos controlados, fortes cáusticas de arco-íris projetadas na superfície e preservando detalhes nítidos das bordas sem distorção.

#### 📝 Prompt

```
Tarefa: Uma foto macro de herói ultraclose de um {argument name="subject" default="SUBJECT"} como vidro óptico fundido premium com sombras diagonais de faixas de luz, cáusticas de arco-íris mais fortes e áreas limpas e legíveis com alto nível de detalhes (sem "mush" de refração). O objeto está TOTALMENTE visível e NÃO cortado. O objeto é colocado na superfície ou flutuando no ar em baixa altitude acima da superfície.
Estilo: Produto de luxo fotorrealista; fundo gradiente azul-acinzentado sem emendas #9FAFBC (frio, ligeiramente azul, baixa saturação); plano reflexivo brilhante; vidro óptico liso e transparente com bordas nítidas, realces internos controlados, brilhos sutis de estrelas; raias cáusticas pronunciadas + arcos prismáticos vívidos de arco-íris projetados na superfície a partir do objeto.
Enquadramento: close-up extremo, o objeto preenche ~90–95% do quadro, totalmente visível e não cortado.
Legibilidade (corrigir "mush"): preservar detalhes nítidos de face/borda — minimizar deformações internas, efeitos de lente e padrões cáusticos sobrepostos em características finas; manter o interior visualmente "silencioso" para que a escultura da superfície seja limpa.
Controle óptico: aparência de vidro de baixa distorção e baixa aberração (dispersão reduzida dentro do objeto) com fortes cáusticas externas na superfície.
Iluminação: faixas de luz suave diagonais amplas; sombra projetada longa e suave com penumbra lisa; as cáusticas do arco-íris devem ser mais fortes e numerosas ao redor da base e no chão. Cor branca limpa.
Controle de ambiente: apenas estúdio sem emendas; bandeiras cinza/pretas controlando reflexos; sem elementos de janela/sala.
Prompt negativo: refração excessiva, distorção pesada, efeito de lente, características faciais deformadas, realces caóticos, vidro leitoso/embaçado, reflexos aleatórios, janela, interior, canto de parede, facetado, poligonal, baixo polígono, texto, marca d'água, desordem.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137201725_ivabrq_HBIWOOIXUAE6yom.jpg" width="600" alt="Imagem Principal de E-commerce - Close-up de Objeto de Vidro Fundido Óptico com Cáusticas - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Neuromaniac](https://x.com/neuromania_ua)
- **Fonte:** [Twitter Post](https://x.com/neuromania_ua/status/2022703794451009537)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10103)**

---

### No. 95: Imagem Principal de E-commerce - Fotografia Ultra-Realista de Lata de Refrigerante OLIPOP

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt para gerar fotografia de produto comercial ultrarrealista, focando em uma lata de refrigerante cor pêssego pastel, cercada por pêssegos frescos e cubos de gelo grandes e altamente detalhados, enfatizando a condensação, as bolhas de carbonatação e uma iluminação de estúdio suave e difusa.

#### 📝 Prompt

```
Fotografia comercial ultrarrealista de um produto: uma lata de refrigerante cor pastel de {argument name="soda color" default="pêssego"} com o rótulo “OLIPOP – {argument name="flavor" default="Peaches & Cream"}” posicionada verticalmente no centro, cercada por pêssegos frescos inteiros na base e grandes cubos de gelo transparentes empilhados ao redor e cobrindo parcialmente a parte superior da lata, com gotas de condensação pesadas cobrindo a lata e a fruta, pequenas bolhas de carbonatação visíveis nos pêssegos, textura de gelo picado com bordas afiadas e reflexos gelados, iluminação de estúdio suave e difusa.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137195753_bgfnt4_HBH-uiOa0AAOC4p.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia Ultra-Realista de Lata de Refrigerante OLIPOP - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137195782_oh4xra_HBH-ukhawAAyv7P.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia Ultra-Realista de Lata de Refrigerante OLIPOP - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137195753_hr3um5_HBH-uiTakAQ2rfA.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia Ultra-Realista de Lata de Refrigerante OLIPOP - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [𝐌](https://x.com/Strength04_X)
- **Fonte:** [Twitter Post](https://x.com/Strength04_X/status/2022677800046797093)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10092)**

---

### No. 96: Imagem Principal de E-commerce - Anúncio de Produto de Skincare de Luxo Subaquático

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt ultrarrealista para gerar um anúncio macro de produto para um tubo de tratamento labial turquesa fosco, colocado debaixo d'água entre recifes de corais bioluminescentes, enfatizando a refração da luz fisicamente precisa, raios de luz (god rays) e estilo comercial de luxo.

#### 📝 Prompt

```
Anúncio de luxo de produtos para a pele subaquáticos ultrarrealistas.
Um tubo de tratamento labial turquesa fosco em pé, ligeiramente inclinado, centralizado no quadro. O tubo é de plástico liso e macio ao toque, com sutis realces especulares e textura de superfície realista. Tipografia branca elegante verticalmente, lendo "MODA SKIN" e um texto menor perto da parte inferior "Lip Treatment 15 ml". O texto é nítido, limpo e perfeitamente legível.
O produto é colocado entre densas formações de recifes de coral bioluminescentes em tons de verde-azulado, água, azul e violeta. Os galhos de coral cercam o tubo naturalmente sem cobrir o rótulo. Várias águas-vivas translúcidas flutuam ao redor do produto em diferentes profundidades, brilhando suavemente, com delicados tentáculos semitransparentes.
Fundo do oceano visível na parte inferior com textura arenosa e padrões realistas de luz cáustica subaquática. Fortes raios de luz volumétricos brilhando da superfície da água acima. Iluminação subaquática cinematográfica, alto contraste, atmosfera azul profunda, névoa sutil para profundidade. Foco nítido no produto, profundidade de campo rasa no coral de fundo.
Estilo de comercial de luxo para a pele, hiperdetalhado, fotorrealista, iluminação global, refração de luz subaquática fisicamente precisa, resolução 8k, fotografia macro de produto.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137192721_1drv56_HBHlTOiakAA95VP.jpg" width="600" alt="Imagem Principal de E-commerce - Anúncio de Produto de Skincare de Luxo Subaquático - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137192767_h16d7d_HBHlTPHaQAAoCmg.jpg" width="600" alt="Imagem Principal de E-commerce - Anúncio de Produto de Skincare de Luxo Subaquático - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137192788_fmd6g8_HBHlTOkbIAAQQ4W.jpg" width="600" alt="Imagem Principal de E-commerce - Anúncio de Produto de Skincare de Luxo Subaquático - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137194370_2miu6h_HBHlTO6aYAA97LH.jpg" width="600" alt="Imagem Principal de E-commerce - Anúncio de Produto de Skincare de Luxo Subaquático - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Oogie](https://x.com/oggii_0)
- **Fonte:** [Twitter Post](https://x.com/oggii_0/status/2022649838165463143)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10090)**

---

### No. 97: Imagem Principal de E-commerce - Integrar o headset VR no modelo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt de instrução simples usado para integrar um modelo específico de headset VR em um indivíduo em uma imagem, garantindo que o dispositivo seja usado naturalmente, preservando as texturas do tecido e a consistência da iluminação da imagem original.

#### 📝 Prompt

```
Faça o modelo usar o VR Headset (não altere o estilo do VR Headset) https://t.co/C0Gd0pGg5T
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050447522_0mo1hy_HBDZ_VbbwAEsfOS.jpg" width="600" alt="Imagem Principal de E-commerce - Integrar o headset VR no modelo - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Carolina Delgado](https://x.com/carolletta)
- **Fonte:** [Twitter Post](https://x.com/carolletta/status/2022355918143607004)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9994)**

---

### No. 98: Imagem Principal de E-commerce - Prompt de Fotografia de Produto para Difusor de Varetas de Luxo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt ultrarrealista para fotografia de produto premium, focando em um frasco de difusor de varetas de vidro de obsidiana profunda com rótulo dourado metálico. A cena é dramática e cinematográfica, apresentando condensação, rosas carmesim escuras e folhagem exuberante, usando iluminação de baixo contraste e profundidade de campo rasa para uma estética de campanha de fragrância de luxo.

#### 📝 Prompt

```
Fotografia de produto premium ultrarrealista de um frasco de difusor de varetas de vidro de obsidiana profunda rotulado como "MIDNIGHT OUD – Signature Reserve – NOIRÉ" em letras serifadas douradas metálicas refinadas. O frasco apresenta uma silhueta quadrada alta e suavemente arredondada com bordas chanfradas e um acabamento espelhado de alto brilho. Um sutil logotipo de brasão dourado em relevo está posicionado perto do centro superior, adicionando um detalhe de luxo discreto. Varetas difusoras finas de carvão fosco se elevam elegantemente do gargalo.
A superfície do vidro é revestida com condensação realista e gotículas de água espalhadas, como se tivessem sido capturadas momentos após uma névoa fria. O difusor está aninhado entre rosas carmesim escuras e pétalas espalhadas em tons de ameixa, em camadas com uma folhagem esmeralda exuberante que brilha com umidade. O cenário é rico e atmosférico, com um fundo botânico sombrio que se desvanece suavemente em um desfoque (profundidade de campo rasa com bokeh cremoso).
A iluminação é dramática e cinematográfica, apresentando iluminação de baixo contraste com uma suave luz de contorno para acentuar as curvas do frasco. Tons frios sutis, verdes florestais profundos e tons de azul-marinho criam um ambiente misterioso e sofisticado. A tipografia metálica e o brasão em relevo captam destaques delicados para uma sensação de campanha de fragrância de luxo sofisticada.
Composição: Proporção de retrato vertical 4:5, produto principal centralizado e ligeiramente angulado para dimensão. Flores em primeiro plano emolduram sutilmente a base do frasco, enquanto a folhagem de fundo se dissolve na escuridão.
Foco na textura: Gotas de condensação ultradetalhadas, vidro laqueado reflexivo, texturas de rosa aveludadas e varetas foscas macias.
Estilo: Publicidade de fragrâncias para casa de luxo, estética de macrofotografia, lente de 85 mm, abertura f/2, foco nítido no produto, contraste dramático, sombras ricas, detalhes ultrarrealistas em 8K, acabamento editorial premium.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050467413_pzxehl_HBDDIkMa8AE0V3Z.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Fotografia de Produto para Difusor de Varetas de Luxo - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050467371_zb9h1o_HBDDIjrbkAALB6r.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Fotografia de Produto para Difusor de Varetas de Luxo - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050467413_14omz7_HBDDImJb0AAdufN.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Fotografia de Produto para Difusor de Varetas de Luxo - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050468222_5y34ww_HBDDIo-aUAEqhX5.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Fotografia de Produto para Difusor de Varetas de Luxo - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Johnn](https://x.com/john_my07)
- **Fonte:** [Twitter Post](https://x.com/john_my07/status/2022330789908951445)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10032)**

---

### No. 99: Imagem Principal de E-commerce - Prompt de Escultura de Origami Ultra-Hiperdetalhada

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente detalhado para gerar uma imagem ultra-fotorrealista de uma escultura de origami de um personagem humano, enfatizando dobras nítidas, precisão geométrica, textura de papel específica e estética de fotografia de produto de luxo com iluminação cinematográfica.

#### 📝 Prompt

```
Escultura de origami ultra-hiperdetalhada de um personagem humano, meticulosamente dobrada à mão a partir de papel artesanal premium com vincos ultra-nítidos e afiados como navalhas e textura de fibra visível. Cada dobra forma planos geométricos precisos que esculpem a estrutura facial, a postura e a expressão emocional com simetria matemática. Tesselações complexas em camadas e padrões de microdobras definem sutilmente contornos e profundidade.
A superfície do papel apresenta um acabamento fosco suave com difusão de luz delicada — sem tons pretos, usando estritamente a paleta de cores exata da foto de referência, traduzida em gradientes de papel em camadas. As bordas são limpas e nitidamente definidas, com uma sutil espessura do papel visível ao longo das dobras.
Colocado em um pedestal de estúdio minimalista de alta qualidade com uma superfície neutra e lisa. A luz do dia suave e direcional de um lado cria sombras realistas e uma suave luz ambiente refletida. Leve profundidade de campo para uma sensação de fotografia de produto premium.
Estética de colecionável de designer de luxo — qualidade de exibição de museu, instalação de arte conceitual em papel, detalhe macro ultra-fotorrealista, foco nítido, resolução 8K, composição quadrada de 1080×1080, alto alcance dinâmico, iluminação cinematográfica, iluminação global, renderização de estúdio profissional.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050432799_oodyfi_HBCwTGbbYAAmZB3.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Escultura de Origami Ultra-Hiperdetalhada - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Cherry 2.O](https://x.com/Mind_Boticni)
- **Fonte:** [Twitter Post](https://x.com/Mind_Boticni/status/2022310162636394751)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9967)**

---

### No. 100: Imagem Principal de E-commerce - Prompt de Fotografia de Produto Retrô-Futurista

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um modelo de prompt para gerar objetos retrô-futuristas altamente detalhados, enfatizando o design da era espacial dos anos 1950–1960, materiais específicos (cromo, tons pastel) e configurações de fotografia de produto profissional com iluminação de estúdio suave.

#### 📝 Prompt

```
Retrofuturismo altamente detalhado {argument name="object name" default="[OBJECT NAME]"}, inspirado no design da era espacial dos anos 1950-1960, silhueta aerodinâmica, elementos de cromo polido, detalhes geométricos marcantes, tons pastel, medidores analógicos e detalhes mecânicos, leve envelhecimento da superfície para autenticidade, posicionado sobre um bloco de madeira antigo com textura de grão de madeira, isolado contra um fundo liso de cor clara {argument name="background color" default="[BACKGROUND COLOR]"}, iluminação de estúdio natural suave, sombras delicadas, profundidade de campo rasa, fotografia de produto profissional, ultrarrealista, detalhes em 4k.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050434122_mievnx_HBB3TJ8WAAArAhz.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Fotografia de Produto Retrô-Futurista - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Shams](https://x.com/ShamsAmin56)
- **Fonte:** [Twitter Post](https://x.com/ShamsAmin56/status/2022249589508899309)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9970)**

---

### No. 101: Imagem Principal de E-commerce - Prompts de Moda e Produtos para o Dia dos Namorados Duplo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Duas prompts separadas para gerar imagens com o tema do Dia dos Namorados: uma para um ensaio editorial de alta costura de uma mulher em um vestido de cetim vermelho, e outra para um anúncio de perfume de luxo apresentando um frasco de cristal em um pedestal de veludo.

#### 📝 Prompt

```
Ensaio fotográfico editorial de moda de uma mulher em um elegante vestido longo de cetim vermelho segurando um buquê de rosas bordô escuras, fundo de estúdio minimalista em tom marfim, efeito de vento no cabelo e no tecido, iluminação de alta-costura, estética de revista de luxo.

Anúncio de perfume de luxo para o Dia dos Namorados, frasco de perfume de cristal colocado em um pedestal de veludo vermelho, cercado por pétalas de rosa espalhadas e pingentes de coração dourados, névoa rosa suave girando em torno do frasco, superfície reflexiva brilhante, holofote dramático, fotografia editorial de luxo, paleta rica em vermelho e dourado, 1080x1080.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050441469_yhknw3_HBBNavGa0AACPNo.jpg" width="600" alt="Imagem Principal de E-commerce - Prompts de Moda e Produtos para o Dia dos Namorados Duplo - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050441502_e4lv6o_HBBNZ-wbsAQEkAD.jpg" width="600" alt="Imagem Principal de E-commerce - Prompts de Moda e Produtos para o Dia dos Namorados Duplo - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Synthia](https://x.com/AIwithSynthia)
- **Fonte:** [Twitter Post](https://x.com/AIwithSynthia/status/2022201717371347334)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9984)**

---

### No. 102: Imagem Principal de E-commerce - Conceito de Prompt para Embalagem de Frutas em Papelão Ondulado

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um modelo de prompt para gerar fotografia de produto de alta qualidade de embalagens criativas de frutas feitas de papelão ondulado, intrincadamente moldadas como a própria fruta, apresentando padrões impressos minimalistas e detalhes ecológicos.

#### 📝 Prompt

```
Uma fotografia profissional de alta qualidade de um design de embalagem estrutural criativo para {argument name="fruit name" default="[Nome da Fruta]"}. A embalagem é feita de papelão ondulado premium, intrincadamente trabalhada na forma literal de uma gigante e estilizada {argument name="shape" default="[Forma, por exemplo, esférica, curva, alongada]"} {argument name="fruit name 2" default="[Nome da Fruta]"}.

A superfície exterior apresenta um padrão impresso vibrante e sofisticado de {argument name="pattern description" default="[Descrição do Padrão, por exemplo, hexágonos geométricos, linhas onduladas orgânicas, pontilhado, arte botânica em linha ou sulcos horizontais]"} minimalistas, imitando a casca natural da fruta em uma paleta duo-tone de [Cor 1] e [Cor 2].

Apresenta janelas recortadas inteligentes que revelam o [Produto Real Dentro] armazenado no interior. Tipografia moderna e minimalista na lateral dizendo "[NOME]". Inclui detalhes ecológicos como um pequeno logotipo de reciclagem e um [Detalhe em Papelão Ondulado 3D: Caule/Folha Verde/Coroa] no topo. Iluminação de estúdio suave com sombras delicadas, colocado sobre um fundo pastel sólido e limpo [Cor do Fundo]. Resolução 8k, fotorrealista, composição cinematográfica, estética de design industrial.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050443055_p4smk1_HBBLtEEbYAA05so.jpg" width="600" alt="Imagem Principal de E-commerce - Conceito de Prompt para Embalagem de Frutas em Papelão Ondulado - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [ΛRMIN | AI](https://x.com/Arminn_Ai)
- **Fonte:** [Twitter Post](https://x.com/Arminn_Ai/status/2022199501168038032)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9986)**

---

### No. 103: Imagem Principal de E-commerce - Prompt de Fotografia de Produto Chrome Ripple Flow

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt de fotografia de produto complexo focado em gerar um produto flutuante com acabamentos em preto fosco e prata metálico, posicionado centralmente em uma superfície de fundo única, contínua e ondulada, apresentando uma textura fina canelada e um gradiente de cor duotônico sem emendas.

#### 📝 Prompt

```
{
  "image_generation_request": {
    "subject": "{argument name=\"product name\" default=\"PRODUCT\"}",
    "product_finish": {
      "primary": "preto fosco com absorção sutil de luz",
      "secondary": "prata metálico polido com reflexos espelhados",
      "treatment": "duotônico — corpo preto fosco com detalhes, acabamentos, bordas ou painéis embutidos em prata metálico"
    },
    "composition": {
      "placement": "bem ao centro, visão completa, flutuando suspenso dentro do ambiente de superfície dobrada",
      "scale": "o produto ocupa aproximadamente 30-40% do quadro",
      "constraints": [
        "o produto deve estar totalmente visível, sem cortes",
        "sem pedestais, suportes, plataformas ou planos de chão",
        "as dobras da superfície enquadram o produto, mas nunca obscurecem mais de 10% dele",
        "o produto é o elemento mais nítido da cena"
      ]
    },
    "background_environment": {
      "description": "Uma única superfície ondulante contínua que preenche todo o quadro, dobrando-se sobre e ao redor de si mesma em grandes ondas volumosas — como uma enorme folha de seda metálica plissada ou um único painel de metal usinado que foi suavemente torcido e drapeado. NÃO são múltiplas fitas ou fios separados. É UMA superfície conectada.",
      "base_color": "{argument name=\"deep background color\" default=\"INSERIR COR DE FUNDO PROFUNDA visível nas fendas — ex: preto puro, azul marinho\"}",
      "surface_color_1": "{argument name=\"gradient color A\" default=\"INSERIR COR DE GRADIENTE A — ex: lavanda suave, cobre quente, rosa pérola\"}",
      "surface_color_2": "[INSERIR COR DE GRADIENTE B — ex: índigo profundo, azul cobalto, violeta]",
      "color_behavior": "As duas cores se misturam em um gradiente suave e contínuo através da superfície única, mudando com base na curvatura da superfície e no ângulo da luz. Onde a superfície está voltada para a luz, ela mostra a cor_1; onde se curva para longe, ela transita para a cor_2. A transição é perfeita, sem bordas duras ou listras.",
      "surface_texture": {
        "type": "finas nervuras paralelas em relevo na superfície — como os sulcos de um disco de vinil ou tecido de acordeão finamente plissado",
        "rib_description": "linhas paralelas extremamente finas, uniformes e bem espaçadas que seguem a direção do fluxo da superfície. As nervuras são uma TEXTURA na superfície, não objetos separados. Elas criam um micro-relevo corrugado sutil que capta a luz ao longo de cada pequena crista.",
        "rib_density": "muito alta — aproximadamente 50-100 linhas visíveis por polegada de superfície, criando um grão linear denso",
        "rib_depth": "rasa — as nervuras são detalhes sutis da superfície, não cortes profundos. Elas criam uma alternância suave de luz e sombra na superfície"
      },
      "surface_form": {
        "fold_style": "dobras grandes, suaves e volumosas como seda pesada drapeada — curvas amplas e abrangentes com torções suaves",
        "fold_count": "3-5 dobras principais visíveis, cada uma larga e generosa, NÃO muitas fitas pequenas emaranhadas",
        "fold_behavior": "as dobras se sobrepõem suavemente, encaixando-se umas sob as outras com transições suaves. Onde as dobras se encontram, elas criam profundidade"
      }
    }
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964542027_zvtlha_HA-HvY7XwAAasmn.jpg" width="600" alt="Imagem Principal de E-commerce - Prompt de Fotografia de Produto Chrome Ripple Flow - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Lloyd Creates](https://x.com/lloydcreates)
- **Fonte:** [Twitter Post](https://x.com/lloydcreates/status/2021984673216209395)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9864)**

---

### No. 104: Imagem Principal de E-commerce - Editorial de Produto: Bucket Hat de Luxo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma fotografia editorial de luxo de um chapéu bucket fictício. Ele especifica a estrutura do chapéu (coroa suavemente estruturada, aba com inclinação suave para baixo), material (algodão escovado premium em marrom expresso profundo) e branding mínimo (pequeno bordado de estrela âmbar). A iluminação é estilo retrato cinematográfico com sombras profundas e realces quentes, simulando grão de filme analógico.

#### 📝 Prompt

```
Chapéu bucket fictício premium com coroa suavemente estruturada.
Altura da coroa equilibrada, nem muito alta nem muito rasa.
A aba tem uma leve inclinação para baixo com uma borda arredondada.
O tecido é algodão escovado premium em marrom espresso profundo.
O bordado frontal é um pequeno símbolo de estrela costurado em linha âmbar quente.
Sem outras marcas.

Iluminação de retrato cinematográfica com uma única luz lateral suave.
Sombras profundas e realces quentes.
O fundo é um gradiente âmbar a marrom escuro.
Granulação de filme analógico, fotografia editorial de luxo.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964572965_tzzjt5_HA9l3nLawAAFeAO.jpg" width="600" alt="Imagem Principal de E-commerce - Editorial de Produto: Bucket Hat de Luxo - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Ege](https://x.com/egeberkina)
- **Fonte:** [Twitter Post](https://x.com/egeberkina/status/2021946771245871243)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9944)**

---

### No. 105: Imagem Principal de E-commerce - Fotografia de Produtos de Luxo: Difusor Black Oudh

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt altamente detalhado para gerar fotografia de produto de luxo ultrarrealista de um frasco difusor de varetas de vidro preto, coberto de condensação e colocado entre rosas escuras e folhagens, enfatizando iluminação cinematográfica de baixa intensidade e texturas ricas para uma estética de campanha de fragrâncias de alta qualidade.

#### 📝 Prompt

```
Fotografia de produto de luxo ultrarrealista de um frasco difusor de varetas de vidro preto, rotulado como “{argument name="product name" default="BLACK OUDH – Private Collection – RITUALS"}” em elegante tipografia serifada dourada. O frasco tem formato retangular curvo com bordas suaves, uma superfície brilhante e reflexiva, e um emblema dourado estilo lacre de cera centralizado perto do topo. Varetas difusoras pretas finas se estendem para cima a partir do gargalo do frasco.

O frasco está coberto por gotas de água e condensação realistas, como se tivesse sido recém-borrifado após a chuva. Ele está posicionado entre rosas pretas profundas e pétalas em tom bordô escuro com gotas de água visíveis, cercado por folhas verdes exuberantes. A cena é melancólica e dramática, com um fundo botânico escuro, suavemente desfocado (profundidade de campo rasa, efeito bokeh).

A iluminação é cinematográfica e de baixo contraste, com realces suaves e difusos refletindo na superfície de vidro molhada. A iluminação em tons frios (verdes profundos e azuis-meia-noite) realça a atmosfera escura e luxuosa. O emblema e as letras douradas captam sutilmente a luz, criando uma estética premium e de alta qualidade.

Composição: orientação vertical (proporção 4:5), posicionamento centralizado do produto, frasco ligeiramente inclinado repousando naturalmente entre as rosas. Rosas em primeiro plano emolduram parcialmente a base do frasco. O fundo é de folhagem escura que se esvai na sombra.

Ênfase na textura: gotas de água hiperdetalhadas, reflexos de vidro brilhante, pétalas de rosa aveludadas, varetas pretas foscas.

Estilo: publicidade de fragrâncias comerciais de alta qualidade, lente macro, 85mm, f/2.0, profundidade de campo rasa, fotorrealista, resolução 8K, foco nítido no frasco, contraste dramático, pretos ricos, estética de campanha de perfume de luxo.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964547661_c18d4f_HA9fhJXaYAAnrzU.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Luxo: Difusor Black Oudh - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964547646_kgwn4t_HA9fhJLbsAM7U_1.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Luxo: Difusor Black Oudh - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964547700_shy12b_HA9fhHvbsAIao2q.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Luxo: Difusor Black Oudh - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964548349_q60nr1_HA9fhKBbsAIMMuE.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Luxo: Difusor Black Oudh - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Oogie](https://x.com/oggii_0)
- **Fonte:** [Twitter Post](https://x.com/oggii_0/status/2021939791768826247)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9876)**

---

### No. 106: Imagem Principal de E-commerce - Fotografia de Produtos de Skincare de Verão na Praia

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt detalhado para gerar uma fotografia fotorrealista de produto, editada por IA, de um frasco conta-gotas de sérum cosmético deitado na areia da praia. O prompt especifica o ambiente (areia molhada e compactada, espuma do mar), os detalhes do produto (frasco de vidro vermelho, texto dourado) e a iluminação (luz solar natural brilhante, mas suave) para uma estética de verão de alto contraste e tons quentes.

#### 📝 Prompt

```
{
  "resolution": "8K UHD",
  "image_type": "Fotografia de produto fotorrealista editada por IA",
  "aspect_ratio": "retrato (aproximadamente 3:4)",
  "scene_environment": {
    "location": "costa de praia arenosa",
    "ground": {
      "material": "areia fina marrom-dourada",
      "texture": "areia molhada e compactada com grãos visíveis",
      "surface_details": [
        "pequenas depressões cheias de água",
        "padrões naturais irregulares de areia",
        "ondulações sutis causadas pela água recuante"
      ]
    },
    "water": {
      "type": "água do mar",
      "state": "rasa, em movimento",
      "foam": {
        "color": "branca",
        "texture": "bolhas finas de tamanhos variados",
        "distribution": "parcialmente cercando e fluindo ao redor do produto"
      },
      "motion": "lavagem suave das ondas com direção de fluxo visível"
    }
  },
  "primary_subject": {
    "object_type": "frasco conta-gotas de sérum cosmético",
    "position": "deitado na areia",
    "orientation": {
      "angle": "ligeiramente diagonal",
      "dropper_direction": "topo angulado para a parte superior esquerda do quadro"
    },
    "material": {
      "bottle": "vidro transparente",
      "finish": "brilhante",
      "cap": "tampa conta-gotas de plástico branco fosco"
    },
    "color": {
      "liquid_inside": "vermelho translúcido profundo",
      "bottle_tint": "vidro vermelho",
      "cap_color": "branco"
    },
    "surface_details": [
      "múltiplas gotas de água visíveis no vidro",
      "reflexos de luz nas bordas curvas",
      "refração sutil através do líquido"
    ],
    "shadow": {
      "presence": true,
      "direction": "estende-se diagonalmente para baixo",
      "edge": "suave, mas claramente definida"
    }
  },
  "branding_and_text": {
    "label_style": {
      "shape": "retangular",
      "border": "contorno dourado fino",
      "finish": "plano, limpo"
    },
    "text_color": "dourado",
    "readable_text": [
      "RED GLOW",
      "US WIETOLY",
      "RED GLOW",
      "BRONZING ELIXIR",
      "30 ml"
    ],
    "typography": {
      "style": "sans-serif moderno",
      "alignment": "centralizado",
      "case": "maiúsculas"
    }
  },
  "lighting": {
    "type": "luz solar natural",
    "direction": "do lado superior do quadro",
    "intensity": "brilhante, mas suave",
    "effects": [
      "reflexos especulares no vidro",
      "brilho na superfície da água",
      "definição clara da sombra"
    ]
  },
  "color_palette": {
    "dominant_colors": [
      "vermelho profundo",
      "areia dourada",
      "espuma branca"
    ],
    "contrast": "alto contraste entre o frasco vermelho e o fundo neutro",
    "tone": "quente"
  },
  "camera_and_composition": {
    "camera_angle": "de cima para baixo com ligeira perspectiva",
    "focus": "foco nítido no frasco e na areia próxima",
    "depth_of_field": "moderada, o fundo permanece detalhado",
    "framing": "assunto centralizado ligeiramente mais abaixo no quadro"
  },
  "post_processing_style": {
    "look": "realismo aprimorado por IA",
    "clarity": "alto micro-detalhe",
    "noise": "nenhum visível"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964567308_3j591y_HA8TNZOaYAA2t_j.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Skincare de Verão na Praia - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964567383_m9jjlm_HA8TNc_bYAA6kWh.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Skincare de Verão na Praia - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964567345_d7rxr5_HA8TNavbAAA1nWC.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Skincare de Verão na Praia - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964567934_z8g08c_HA8TNjabsAQ8xu_.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia de Produtos de Skincare de Verão na Praia - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [ShaHid WaNii](https://x.com/meng_dagg695)
- **Fonte:** [Twitter Post](https://x.com/meng_dagg695/status/2021855897837064331)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9930)**

---

### No. 107: Imagem Principal de E-commerce - Fotografia Ultra-Realista de Produtos de Skincare em Areia Molhada da Praia

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt detalhado para gerar fotografia de produto ultrarrealista de um frasco de elixir bronzeador posicionado diagonalmente em areia molhada de praia, capturando uma onda suave do oceano, espuma do mar e luz dourada do sol em uma composição cinematográfica flat lay de cima para baixo.

#### 📝 Prompt

```
Fotografia de produto de verão ultrarrealista de um produto de bronzeamento chamado "{argument name="product name" default="Golden Glow - Bronzing Elixir"}", frasco retangular fosco em tom bronzeado quente com tampa branca limpa, posicionado diagonalmente na areia molhada da praia enquanto uma onda suave do oceano o atinge, espuma do mar delicada e pequenas bolhas envolvendo a base, água fluindo parcialmente sobre o rótulo, textura fina da areia visível sob a água rasa e clara, luz solar dourada projetando reflexos naturais e sombras suaves, ondulações de água altamente detalhadas e padrões de espuma realistas, estética de verão fresca, branding minimalista limpo centralizado e nítido, iluminação de praia quente na hora dourada, composição cinematográfica de cima para baixo, reflexos naturais na superfície molhada, estilo de campanha de beleza editorial, ultradetalhado, fotorrealista 8K, gradação de cores suave e quente, anúncio de luxo de cuidados com a pele. Proporção 4.5
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964560151_p210er_HA8A4DfaYAAGZt0.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia Ultra-Realista de Produtos de Skincare em Areia Molhada da Praia - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964560110_t40uhm_HA8A4F4WMAARMkG.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia Ultra-Realista de Produtos de Skincare em Areia Molhada da Praia - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964560140_37h06k_HA8A4DIWkAASP3u.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia Ultra-Realista de Produtos de Skincare em Areia Molhada da Praia - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964560958_m79uuv_HA8A4Dga4AAcXO2.jpg" width="600" alt="Imagem Principal de E-commerce - Fotografia Ultra-Realista de Produtos de Skincare em Areia Molhada da Praia - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Yaseen Khan Gul](https://x.com/YaseenK7212)
- **Fonte:** [Twitter Post](https://x.com/YaseenK7212/status/2021835757183209806)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9915)**

---

### No. 108: Imagem Principal de E-commerce - Foto de Estúdio Premium de Bebida Gelada de Mirtilo e Menta

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente estruturado para gerar uma fotografia comercial ultrarrealista de um drink gelado de mirtilo com menta. Ele detalha o copo, o gradiente do líquido, o gelo, as guarnições e os elementos ambientais (superfície escura reflexiva, fundo azul-marinho). A iluminação é especificada como uma configuração de estúdio profissional com luz principal suave e difusa e luz de contorno fria para um estilo de anúncio temperamental, cinematográfico e de alto contraste.

#### 📝 Prompt

```
{
  "meta": {
    "title": "Bebida Gelada de Mirtilo e Hortelã – Estúdio Premium",
    "version": "1.0",
    "type": "text-to-image",
    "style": "Fotografia de bebida ultrarrealista"
  },
  "scene": {
    "subject": "Copo alto e transparente tipo highball cheio de soda azul de mirtilo e hortelã",
    "glass": "Copo facetado transparente com gotas de condensação",
    "liquid": "Bebida vibrante em gradiente azul (azul profundo na parte inferior, clareando no topo)",
    "ice": "Grandes cubos de gelo cristalinos preenchendo o copo",
    "garnish": [
      "Folhas de hortelã frescas dentro e no topo",
      "Mirtilos inteiros dentro da bebida",
      "Mirtilos repousando ao redor da base",
      "Canudo de madeira clara inclinado dentro do copo"
    ],
    "effects": [
      "Vapor suave e nebuloso subindo do topo",
      "Pequenas bolhas no líquido",
      "Gotículas de água na superfície do copo",
      "Leve textura de respingo na superfície inferior"
    ]
  },
  "environment": {
    "background": "Fundo em gradiente azul-marinho escuro a preto",
    "surface": "Superfície preta brilhante e reflexiva com mirtilos e folhas de hortelã espalhados",
    "atmosphere": "Sombrio, cinematográfico, alto contraste"
  },
  "lighting": {
    "type": "Iluminação de estúdio profissional",
    "setup": [
      "Luz principal suave e difusa vinda da esquerda",
      "Luz de contorno fria vinda da direita para realçar as bordas do copo",
      "Luz de fundo sutil para visibilidade do vapor"
    ],
    "highlights": "Reflexos nítidos no gelo e no copo",
    "shadows": "Sombras profundas e dramáticas"
  },
  "camera": {
    "angle": "Close-up ao nível dos olhos",
    "lens": "Lente macro 85mm",
    "aperture": "f/2.8",
    "depth_of_field": "Pequena profundidade de campo, mirtilos do fundo desfocados",
    "resolution": "8K ultra-detalhado",
    "focus": "Foco nítido no centro do copo e nas folhas de hortelã"
  },
  "quality_tags": [
    "hiper-realista",
    "fotorrealista",
    "fotografia comercial de bebidas",
    "detalhes nítidos",
    "cinematográfico",
    "alto alcance dinâmico",
    "estilo de anúncio editorial de bebida"
  ]
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964567216_nl1oqo_HA7guOTbMAAU4PR.jpg" width="600" alt="Imagem Principal de E-commerce - Foto de Estúdio Premium de Bebida Gelada de Mirtilo e Menta - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964567300_zoetcw_HA7guP6a4AAXC4I.jpg" width="600" alt="Imagem Principal de E-commerce - Foto de Estúdio Premium de Bebida Gelada de Mirtilo e Menta - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964567353_wwbx4n_HA7guM9bwAAdh8D.jpg" width="600" alt="Imagem Principal de E-commerce - Foto de Estúdio Premium de Bebida Gelada de Mirtilo e Menta - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1770964568000_qdmw4w_HA7guO7bsAIsP2A.jpg" width="600" alt="Imagem Principal de E-commerce - Foto de Estúdio Premium de Bebida Gelada de Mirtilo e Menta - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Johnn](https://x.com/john_my07)
- **Fonte:** [Twitter Post](https://x.com/john_my07/status/2021800373007372290)
- **Publicado:** 12 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9932)**

---

### No. 109: Ativo de Jogo - Diorama em Miniatura de Mago em uma Caixa

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt altamente detalhado para gerar um diorama em miniatura de fantasia cinematográfica ultra-realista. O conceito principal é uma torre de biblioteca de mago de dois níveis, onde a arquitetura é perfeitamente integrada em uma caixa antiga aberta e ornamentada, apresentando um mago trabalhando, livros flutuantes e iluminação dramática.

#### 📝 Prompt

```
ASSUNTO: Uma torre de biblioteca de mago em miniatura de dois níveis onde a própria caixa antiga ornamentada e aberta forma a arquitetura, o recipiente da base atuando como a câmara completa do térreo com as paredes da caixa servindo diretamente como as paredes estruturais de pedra ou madeira, apresentando um mago entusiasmado trabalhando ativamente em uma mesa mágica com livros flutuantes e runas brilhantes, a cena totalmente integrada à estrutura da caixa e não um cômodo separado colocado dentro, não uma moldura de parede ou moldura de exibição
AMBIENTE: A base da caixa ornamentada é a superfície e fundação do térreo, seus lados internos transformados nas paredes do térreo contendo portas esculpidas e aberturas de janelas que são cortadas perfeitamente nas laterais da caixa, perfeitamente alinhadas e misturando-se às esculturas ornamentais externas, um primeiro andar mezanino construído acima com grades e prateleiras presas diretamente às paredes da caixa, conectado por uma escada em espiral, o interior da tampa aberta atuando como o teto abobadado da torre com símbolos arcanos tênues
DETALHES: Caixa antiga intrincada esculpida em estilo barroco ou gótico com painéis gravados, dobradiças claramente visíveis, ornamentação externa continuando logicamente na arquitetura interna, portas e janelas precisamente cortadas nas laterais da caixa seguindo os padrões decorativos, junções estruturais em miniatura críveis onde as vigas encontram as paredes do recipiente, texturas ultrafinas em livros, grão de madeira, blocos de pedra, glifos mágicos, livros levitando, páginas de pergaminho e partículas mágicas flutuantes cercando o mago
ESTILO: Fotografia de diorama em miniatura de fantasia cinematográfica ultrarrealista, realismo artesanal de nível de museu, detalhes macro extremos, materiais fisicamente críveis, forte integração arquitetônica de recipiente e estrutura, otimizado para Nano Banana Pro
ILUMINAÇÃO: Brilho mágico quente do feitiço ativo do mago combinado com um suave feixe de luz fria vindo de cima, raios sutis atingindo as aberturas das janelas nas paredes da caixa, poeira volumétrica e trilhas de partículas brilhantes aumentando a profundidade e a escala
COR: Prateleiras em mogno profundo, cremes de pergaminho envelhecido, luz mágica âmbar quente, azuis e violetas mágicos em tons de joia, cinzas de pedra suaves, tons de bronze antigo ou madeira escura esculpida da caixa ornamentada totalmente preservados
CÂMERA: Close-up macro ligeiramente elevado de frente olhando para a caixa aberta para que as paredes integradas do térreo, as aberturas de portas cortadas, o mezanino, a escada em espiral e o mago trabalhando sejam todos claramente visíveis, profundidade de campo rasa centrada no mago e na integração estrutural
PROPORÇÃO DA TELA: 4:3
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310084989_zxt1rs_HBTgzVfacAAb7a5.jpg" width="600" alt="Ativo de Jogo - Diorama em Miniatura de Mago em uma Caixa - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Artingent](https://x.com/artingent)
- **Fonte:** [Twitter Post](https://x.com/artingent/status/2023489333278502982)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10247)**

---

### No. 110: Ativo de Jogo - Plano de Personagem em Perspectiva de Baixo para Cima (Preservação da Semelhança)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt detalhado para gerar uma cena cinematográfica, com perspectiva de baixo para cima, de um personagem (Besta/criatura), focando na distorção extrema de escala usando uma lente ultra grande-angular, preservação rigorosa da semelhança e dos materiais da imagem de referência, e iluminação dramática de contorno para cima.

#### 📝 Prompt

```
Uma tomada cinematográfica em perspectiva de baixo para cima do personagem, capturada do nível do solo, com a câmera quase tocando a superfície abaixo dele. Lente ultra-wide de 14–18mm. A câmera está angulada acentuadamente para cima, fazendo com que o personagem se eleve massivamente no quadro.

Preservação da Semelhança:

Manter as proporções exatas, formato dos olhos, estilização e identidade material da referência. Não humanizar ou reinterpretar a anatomia. A exacerbação da perspectiva deve vir apenas do posicionamento da câmera, não de um redesenho.

Composição:

A parte mais baixa do personagem domina o primeiro plano devido à proximidade com a lente. Botas, pés, vestimenta inferior ou forma da base aparecem grandes e imponentes. A parte superior do corpo recua dramaticamente para cima, em direção ao céu ou ao fundo. A cabeça é posicionada perto do terço superior do quadro, ligeiramente fora do centro.

Pose:

Postura firme. Pés plantados firmemente. Um pé ligeiramente mais próximo da lente para realçar a distorção da escala. Parte superior do corpo calma e controlada. Sem movimento exagerado. O domínio vem da quietude.

Comportamento da Câmera:

Distância muito próxima ao elemento em primeiro plano. Leve inclinação do horizonte para criar tensão. Primeiro plano nítido, parte superior ligeiramente suavizada pela queda da profundidade de campo.

Iluminação:

Forte luz de contorno ascendente capturando as bordas da silhueta inferior. Luz lateral secundária esculpindo o volume. Névoa atmosférica sutil acima para criar separação de profundidade. As sombras caem para baixo em direção à lente.

Fundo:

Gradiente semelhante ao céu, grande espaço vazio acima. Raios de luz ou névoa volumétrica subindo. Sem aparência de estúdio plano.

Detalhe da Superfície:

Texturas em primeiro plano extremamente nítidas. Identidade material preservada exatamente. Sem desgaste adicional, a menos que já presente.

Emoção:

Monumental. Imóvel. O espectador se sente fisicamente abaixo do personagem. Poder apenas através da perspectiva.

Prompt negativo:

Sem distorção anatômica, sem membros esticados além do efeito da lente, sem acessórios adicionados, sem simetria centralizada, sem iluminação neutra de estúdio.
ar 1:1
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771310078632_vgig27_HBQocdsXQAAUEFS.jpg" width="600" alt="Ativo de Jogo - Plano de Personagem em Perspectiva de Baixo para Cima (Preservação da Semelhança) - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Edizkan ⭕🦇](https://x.com/edizkan_)
- **Fonte:** [Twitter Post](https://x.com/edizkan_/status/2023294351451795908)
- **Publicado:** 16 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10234)**

---

### No. 111: Ativo de Jogo - Prompt de Grade de Emoções de Personagens 3D no Estilo Pixar

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 Descrição

Um prompt para gerar uma grade de 6 painéis de uma garota animada em 3D no estilo Pixar, mostrando diferentes emoções contra fundos sólidos e coloridos, visando qualidade de filme de animação.

#### 📝 Prompt

```
Menina animada em estilo Pixar 3D mostrada em uma grade de 6 painéis, a mesma personagem com cabelo castanho curto e olhos azuis grandes, diferentes emoções ({argument name="emotion 1" default="happy"}, {argument name="emotion 2" default="shocked"}, {argument name="emotion 3" default="angry"}, carinhosa, confiante, polegar para cima), fundos sólidos coloridos (amarelo, azul, vermelho, rosa, roxo, verde), iluminação de estúdio suave, renderização 3D suave, cores vibrantes, ultra detalhada, 4K, qualidade de filme de animação.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223955641_bk7or2_HBNENwUaIAAiT6D.jpg" width="600" alt="Ativo de Jogo - Prompt de Grade de Emoções de Personagens 3D no Estilo Pixar - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Taaruk](https://x.com/Taaruk_)
- **Fonte:** [Twitter Post](https://x.com/Taaruk_/status/2023035676791603643)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10154)**

---

### No. 112: Ativo de Jogo - Prompt de Retrato Cosplay Fotorrealista da Batgirl (Anatomia Exagerada)

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente explícito para gerar um retrato fotorrealista de uma mulher (semelhança com Megan Fox) em um body inspirado na Batgirl com proporções de ampulheta exageradas (seios grandes, quadris largos). Ele especifica os detalhes do traje (preto/roxo/amarelo, gola halter), pose (peso deslocado, mão na bancada de granito) e ambiente (banheiro interno com pôster de quadrinhos), usando prompts negativos para garantir proporções físicas e sem estilo.

#### 📝 Prompt

```
{
  "subject": {
    "desc": "Semelhança com Megan Fox, pele clara, cabelo liso e comprido castanho-escuro/preto sobre os ombros/costas, rosto simétrico com lábios cheios, sobrancelhas definidas, olhos verde-avelã, pequena máscara da Batgirl cobrindo os olhos",
    "apparel": {
      "item": "Body inspirado na Batgirl",
      "style": "Frente única sem mangas, pernas de corte alto",
      "color": "Base preta com detalhes roxos brilhantes, acabamento amarelo nas pernas, grande emblema de morcego amarelo no peito",
      "details": "Tecido elástico justo enfatizando as curvas, meias pretas/roxas"
    },
    "anatomy": {
      "body_type": "Ampulheta voluptuosa exagerada",
      "bust": "Seios grandes, cheios e volumosos com forte projeção para frente, bem contidos",
      "hips": "Quadris muito largos, coxas grossas, cintura estreita",
      "skin": "Pele clara e suave com variação de tom natural"
    }
  },
  "pose": {
    "posture": "Em pé, peso deslocado para o quadril direito (esquerda do espectador) para inclinação pélvica, tronco ligeiramente angulado em direção à câmera",
    "limbs": {
      "right_arm": "Estendido para baixo, mão apoiada na bancada de granito",
      "left_arm": "Pendurado naturalmente ao lado, parcialmente obscurecido pelo quadril",
      "head": "Leve inclinação, virada para frente"
    },
    "gaze": "Contato visual direto, expressão suave, neutra, confiante e sedutora"
  },
  "environment": {
    "location": "Banheiro interno",
    "elements": [
      "Bancada de granito salpicado verde/preto (primeiro plano esquerdo)",
      "Porta de madeira com painel de vidro fosco alto (fundo direito)",
      "Toalheiro (fundo esquerdo)",
      "Grande pôster em quadrinhos da Mulher Maravilha em paredes pretas, pequeno letreiro de néon 'KeorUnreal'"
    ]
  },
  "camera": {
    "shot": "Médio (da coxa para cima), vertical 3:4",
    "angle": "Nível dos olhos ligeiramente frontal",
    "lens": "Retrato 50-85mm",
    "dof": "Moderado, assunto nítido, fundo distinto ligeiramente suave",
    "framing": "Assunto centralizado"
  },
  "lighting": "Iluminação artificial interna suave e difusa, superior/ligeiramente frontal, iluminação uniforme, sombras suaves sob os seios/quadris, realces nos contornos do corpo e brilho do tecido",
  "mood": "Confiante, calma, sedutora, atmosfera doméstica íntima e casual",
  "style": "Fotografia fotorrealista de smartphone, texturas de tecido/pele detalhadas de alta fidelidade, gradação de cores natural, proporções físicas não estilizadas",
  "colors": "Traje preto com detalhes vibrantes em amarelo/roxo dominantes, granito verde/preto, madeira quente, paredes neutras, contraste/saturação natural",
  "quality": "Foco nítido de alta definição nos olhos/rosto/padrão do traje, baixo ruído, granulação mínima",
  "negative_prompt": "busto pequeno/reduzido/achatado, seios levantados, tronco/quadris afilados, média de proporção, pele plástica/aerografada, embelezamento, estilização, achatamento de profundidade, distorção ampla, selfies no espelho, telefone na mão, reflexos"
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223969490_wbzq70_HBM9X_ragAAdazt.jpg" width="600" alt="Ativo de Jogo - Prompt de Retrato Cosplay Fotorrealista da Batgirl (Anatomia Exagerada) - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223969574_zd9aob_HBM9X8lXUAE8zUE.jpg" width="600" alt="Ativo de Jogo - Prompt de Retrato Cosplay Fotorrealista da Batgirl (Anatomia Exagerada) - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223969753_55uv22_HBM9YCtXcAAMMET.jpg" width="600" alt="Ativo de Jogo - Prompt de Retrato Cosplay Fotorrealista da Batgirl (Anatomia Exagerada) - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771223970447_a71ju3_HBM9YKub0AE2QK5.jpg" width="600" alt="Ativo de Jogo - Prompt de Retrato Cosplay Fotorrealista da Batgirl (Anatomia Exagerada) - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [KeorUnreal](https://x.com/KeorUnreal)
- **Fonte:** [Twitter Post](https://x.com/KeorUnreal/status/2023028159415808332)
- **Publicado:** 15 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10183)**

---

### No. 113: Ativo de Jogo - Gerador de Cena de Encontro Íntimo para Vários Personagens

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt complexo e com múltiplos personagens, projetado para gerar uma cena de encontro íntimo ultra-fotorrealista. Ele exige a referência a vários personagens/objetos e a manutenção fiel de seus estilos de arte e ambientes originais, ao mesmo tempo em que mistura seus planos de fundo em um cenário 3D coeso e romântico.

#### 📝 Prompt

```
composição íntima em close-up de TODOS OS PERSONAGENS REFERENCIADOS em seu estilo de arte exato e roupas exatas, com os personagens sentados um de frente para o outro em um ambiente de encontro aconchegante que se encaixa no ambiente de todos os personagens. se o personagem for um objeto, personifique esse objeto fielmente.

local de encontro ultra-fotorrealista formado pelos cenários de todos os personagens, enquanto a atividade e a culinária são definidas pelos estilos, cores e moodboards de todos os personagens.
todos os personagens envolvidos em uma interação natural de "se conhecer" com linguagem corporal relaxada, mostrando conexão genuína e diversão.
iluminação atmosférica quente complementando as paletas de cores e humores de todos os personagens, recursos ambientais fotorrealistas flutuando por toda a cena, combinando contextualmente com o tipo de cenário, com corações suaves que se encaixam nas vibrações e estilo de arte de todos os personagens.

renderização do ambiente em qualidade 3D fotorrealista completa, enquanto todos os personagens mantêm seus estilos de arte nativos sem se misturar, fundo suavemente borrado com efeitos bokeh destacando a atmosfera íntima do encontro, ambiente aconchegante e convidativo com temperatura de cor quente, alta resolução, alta qualidade, alto detalhe, cenário romântico e confortável onde todos os personagens se sentem naturalmente em casa, iluminação volumétrica criando profundidade e calor, composição da cena enfatizando a conexão entre todos os personagens, sem multidões, ambiente privado e íntimo, momento espontâneo de experiência e descoberta compartilhadas, anatomia precisa.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137206837_x5qef4_HBH_q2RakAUhngo.jpg" width="600" alt="Ativo de Jogo - Gerador de Cena de Encontro Íntimo para Vários Personagens - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137206887_no1dbq_HBINwwWaYAAdnGA.jpg" width="600" alt="Ativo de Jogo - Gerador de Cena de Encontro Íntimo para Vários Personagens - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137206962_qasgjm_HBIXswuakAADt8W.jpg" width="600" alt="Ativo de Jogo - Gerador de Cena de Encontro Íntimo para Vários Personagens - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137208004_ji6x7g_HBIfR6yaoAANGn5.jpg" width="600" alt="Ativo de Jogo - Gerador de Cena de Encontro Íntimo para Vários Personagens - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [KiriKev](https://x.com/0xKiriKev)
- **Fonte:** [Twitter Post](https://x.com/0xKiriKev/status/2022714144626216989)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10116)**

---

### No. 114: Ativo de Jogo - Grade de Personagens 3D no Estilo Pixar

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar um personagem masculino jovem animado em 3D, no estilo Pixar, exibido em uma grade de 6 painéis, com cada painel apresentando uma expressão facial e uma roupa diferentes em um fundo de cor sólida.

#### 📝 Prompt

```
Um personagem masculino jovem animado em 3D, estilo Pixar, exibido em um layout de grade de 6 painéis, cada painel apresentando uma expressão facial e um traje diferentes. Fundos de cores sólidas e brilhantes (amarelo, azul, vermelho, rosa, roxo, verde). O personagem tem cabelo castanho ondulado e macio, olhos grandes e expressivos, pele lisa e proporções de desenho animado estilizadas.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137187878_dit8pw_HBIKky2akAENzde.jpg" width="600" alt="Ativo de Jogo - Grade de Personagens 3D no Estilo Pixar - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Taaruk](https://x.com/Taaruk_)
- **Fonte:** [Twitter Post](https://x.com/Taaruk_/status/2022690823062884582)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10079)**

---

### No. 115: Ativo de Jogo - Soldadinhos de Brinquedo em uma Casca de Ovo Gigante

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt detalhado para gerar uma fotografia macro ultrarrealista de soldadinhos de brinquedo coloniais britânicos em miniatura escalando e fazendo rapel em uma casca de ovo gigante e rachada, brilhando com gema laranja, criando uma cena de aventura dramática.

#### 📝 Prompt

```
Pequenos soldados de brinquedo coloniais britânicos em uniformes cáqui e capacetes coloniais escalando e fazendo rapel em uma casca de ovo gigante rachada. O ovo está quebrado, brilhando com uma gema laranja brilhante por dentro. Alguns soldados descem com cordas, outros ficam em fragmentos da casca ou usam ferramentas como picaretas. Pedaços de casca quebrada jazem como rochas no chão, com pequenas esferas de gema ao longe. A luz dourada do pôr do sol brilha de dentro do ovo, criando uma cena de aventura dramática e cinematográfica. Diorama em miniatura ultrarrealista, macrofotografia, profundidade de campo rasa, texturas detalhadas.
Negative prompt:
borrado, baixa resolução, desenho animado, anime, ilustração, figuras deformadas, soldados modernos, armas futuristas, texto, marca d'água, iluminação plana
Estilo: fotografia em miniatura fotorrealista
Proporção da imagem: 4:3 ou 3:2
Iluminação: brilho dourado quente vindo de dentro do ovo
Câmera: close-up macro em ângulo baixo
Detalhe: ultradetalhado
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137209047_mi3jzp_HBIB2yVacAAIt0r.jpg" width="600" alt="Ativo de Jogo - Soldadinhos de Brinquedo em uma Casca de Ovo Gigante - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137209225_8g1occ_HBIB3OGbEAARAVc.jpg" width="600" alt="Ativo de Jogo - Soldadinhos de Brinquedo em uma Casca de Ovo Gigante - Image 2">
</div>

#### 📌 Detalhes

- **Autor:** [Johnn](https://x.com/john_my07)
- **Fonte:** [Twitter Post](https://x.com/john_my07/status/2022681234481254915)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10118)**

---

### No. 116: Ativo de Jogo - Streetwear de Leopardo-das-Neves Antropomórfico 3D

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt para gerar uma renderização 3D hiper-realista e ultra-detalhada de um personagem de leopardo-das-neves antropomórfico vestindo streetwear moderno de luxo (jaqueta bomber, moletom techwear, calças utilitárias). Ele especifica a pose, o cenário (estúdio moderno) e a iluminação (luz principal suave cinematográfica, luz de contorno na pele) para uma composição de moda editorial.

#### 📝 Prompt

```
Personagem 3D de leopardo-das-neves antropomórfico de corpo inteiro, ultradetalhado, com anatomia semirrealista e pelo realista, vestindo streetwear moderno de luxo: jaqueta bomber oversized cinza-carvão, moletom techwear, calças utilitárias sob medida, tênis premium de cano alto e acessórios de metal minimalistas. Pose de moda natural e confiante, leve movimento como se estivesse no meio de uma sessão de fotos.
Estúdio moderno e limpo com fundo gradiente suave e reflexos sutis no chão. Iluminação cinematográfica suave, luz de contorno no pelo, textura de tecido e sombras realistas. Renderização 3D hiper-realista, materiais com qualidade de filme, profundidade de campo, ray tracing, composição de moda editorial, resolução ultra-alta. Personagem 3D de cachorro antropomórfico de corpo inteiro, ultradetalhado, com anatomia semirrealista e pelo realista, vestindo streetwear moderno de luxo.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137216780_bl3490_HBH4-wgacAAuNtc.jpg" width="600" alt="Ativo de Jogo - Streetwear de Leopardo-das-Neves Antropomórfico 3D - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137216958_hn51bj_HBH5BdDakAIwYC2.jpg" width="600" alt="Ativo de Jogo - Streetwear de Leopardo-das-Neves Antropomórfico 3D - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137216966_6npd1t_HBH5RL0akAUeV9l.jpg" width="600" alt="Ativo de Jogo - Streetwear de Leopardo-das-Neves Antropomórfico 3D - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137217691_f1jt1k_HBH5dRka8AEQJE0.jpg" width="600" alt="Ativo de Jogo - Streetwear de Leopardo-das-Neves Antropomórfico 3D - Image 4">
</div>

#### 📌 Detalhes

- **Autor:** [Cherry 2.O](https://x.com/Mind_Boticni)
- **Fonte:** [Twitter Post](https://x.com/Mind_Boticni/status/2022672049312002290)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10135)**

---

### No. 117: Ativo de Jogo - Alterando o Personagem Troll para Fazer um Formato de Coração

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt de instrução simples para o Nano Banana Pro modificar uma imagem existente (presumivelmente gerada pelo Midjourney) mudando o personagem troll para fazer um formato de coração com as mãos e os dedos.

#### 📝 Prompt

```
Mude o personagem troll para fazer o formato de coração com as mãos e os dedos.
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137203621_6m7vs8_HBG00t9b0AAmmk1.jpg" width="600" alt="Ativo de Jogo - Alterando o Personagem Troll para Fazer um Formato de Coração - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Michael Rabone](https://x.com/michaelrabone)
- **Fonte:** [Twitter Post](https://x.com/michaelrabone/status/2022596687701688573)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10108)**

---

### No. 118: Ativo de Jogo - Renderização Macro de Personagem de Abelha Peluda com Gota de Mel

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt detalhado para gerar uma renderização macro cinematográfica ultradetalhada de um adorável personagem de abelha miniatura peluda voando no ar e segurando um recipiente de gota de mel translúcido e brilhante, enfatizando o realismo do personagem com qualidade Pixar, composição vertical e forte isolamento do objeto através de uma profundidade de campo rasa.

#### 📝 Prompt

```
Render macro cinematográfico ultradetalhado de um adorável personagem de abelha miniatura peluda voando no ar, segurando um recipiente brilhante e translúcido de gota de mel com pequenas pernas pretas curvadas, a abelha tem pelo macio amarelo-dourado com listras pretas, olhos grandes e brilhantes que parecem de vidro, pequenas antenas delicadas e asas semitransparentes congeladas no meio do batimento, personalidade expressiva e encantadora, realismo de personagem estilizado com qualidade Pixar

composição vertical 9:16, objeto centralizado ligeiramente acima do meio, otimizado para visualização em dispositivos móveis, forte profundidade vertical e direção de movimento

fundo com desfoque de movimento dinâmico com folhagem verde riscada e cores naturais suaves para enfatizar a velocidade e o voo, rastros de movimento verticais, profundidade de campo rasa, objeto perfeitamente nítido enquanto o fundo está fortemente desfocado, bokeh cremoso, forte isolamento do objeto

luz solar quente iluminando o pelo da abelha, iluminação de contorno suave ao redor das bordas, dispersão subsuperficial nas asas, gota de mel brilhando em âmbar com translucidez, refração e viscosidade realistas, materiais fisicamente precisos, iluminação global

aparência de fotografia macro, lente macro de 100mm, abertura f/1.8, detalhes extremos em fibras individuais de pelo, orientação de retrato cinematográfico, qualidade de filme de animação premium, renderização octane, qualidade unreal engine, estilo nano banana pro, ultralimpo, alto realismo, resolução 8k, proporção de aspecto 9:16
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137204725_1gspem_HBFrdBDakAAkfyb.jpg" width="600" alt="Ativo de Jogo - Renderização Macro de Personagem de Abelha Peluda com Gota de Mel - Image 1">
</div>

#### 📌 Detalhes

- **Autor:** [Abby](https://x.com/Abby_Ai_x)
- **Fonte:** [Twitter Post](https://x.com/Abby_Ai_x/status/2022515874029318296)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10109)**

---

### No. 119: Ativo de Jogo - Retrato de Desenho Animado 3D de Billie Eilish

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente detalhado para gerar um retrato renderizado 3D semirrealista de personagem em resolução 8K, retratando uma jovem mulher parecida com Billie Eilish, com cabelo verde-escuro penteado em maria-chiquinhas altas, vestindo uma camiseta verde oversized, e apresentando detalhes faciais e acessórios específicos.

#### 📝 Prompt

```
{
  "image_type": "retrato digital renderizado em 3D",
  "resolution_target": "8K",
  "aspect_ratio": "3:4",
  "camera_framing": {
    "shot_type": "primeiro plano médio",
    "orientation": "vertical",
    "subject_position": "o sujeito ocupa o centro-esquerda do quadro",
    "crop": "cabeça até o torso superior visível"
  },
  "camera_angle": {
    "head_pose": "perfil de três quartos",
    "face_direction": "virado para a direita do espectador",
    "eye_direction": "olhando ligeiramente para a câmera"
  },
  "subject": {
    "gender_presentation": "feminino",
    "age_appearance": "jovem adulta",
    "skin_tone": "tom de pele claro",
    "facial_features": {
      "face_shape": "ligeiramente alongado com contornos suaves",
      "forehead": "lisa, larga",
      "eyes": {
        "color": "verde",
        "shape": "grandes, arredondados",
        "eyelashes": "visíveis, espessura natural"
      },
      "eyebrows": "escuras, grossas, arqueadas naturalmente",
      "nose": {
        "shape": "pequeno a médio",
        "piercing": "piercing de argola prateada na narina esquerda"
      },
      "mouth": {
        "expression": "sorriso sutil",
        "lips": "preenchimento médio, tom rosa natural"
      },
      "freckles": "sardas visíveis no nariz e nas bochechas",
      "marks": "pequena marca semelhante a um arranhão na bochecha direita"
    }
  },
  "hair": {
    "color": "verde escuro",
    "style": "duas maria-chiquinhas altas",
    "parting": "partido ao meio",
    "texture": "liso com fios soltos e esvoaçantes",
    "hair_ties": "elásticos verdes",
    "loose_strands": "vários fios finos emoldurando o rosto"
  },
  "ears_and_jewelry": {
    "ears_visible": true,
    "ear_piercings": "brinco de argola dourada pequena visível na orelha direita",
    "neckwear": [
      {
        "type": "gargantilha",
        "material": "couro preto",
        "details": "tachas prateadas"
      }
    ],
    "necklaces": [
      {
        "material": "ouro",
        "style": "corrente fina",
        "pendant": "anel circular pequeno"
      },
      {
        "material": "ouro",
        "style": "corrente mais grossa",
        "pendant": "pingente em forma de cadeado"
      }
    ]
  },
  "clothing": {
    "top": {
      "type": "camiseta oversized",
      "color": "verde",
      "fabric_appearance": "algodão macio",
      "graphics": "símbolo abstrato preto no peito",
      "fit": "solto"
    }
  },
  "pose_and_body": {
    "shoulders": "ligeiramente angulados",
    "neck": "alongado, relaxado",
    "posture": "ereta com inclinação casual"
  },
  "lighting": {
    "type": "iluminação de estúdio suave",
    "direction": "frente-esquerda",
    "shadows": "sombras suaves definindo os contornos faciais",
    "contrast": "moderado"
  },
  "background": {
    "color": "cinza claro neutro",
    "texture": "gradiente suave",
    "depth": "profundidade de campo rasa",
    "distractions": "nenhuma"
  },
  "render_style": {
    "style": "renderização de personagem 3D semi-realista",
    "skin_detail": "textura de pele altamente detalhada",
    "material_quality": "shaders de tecido e metal realistas",
    "edg": "bordas suaves"
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137185980_fczb60_HBFc96FbQAAquvF.jpg" width="600" alt="Ativo de Jogo - Retrato de Desenho Animado 3D de Billie Eilish - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137185945_p5gbcn_HBFc92NbwAAZ__8.jpg" width="600" alt="Ativo de Jogo - Retrato de Desenho Animado 3D de Billie Eilish - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771137186338_kyp30q_HBFc9_uagAApfxA.jpg" width="600" alt="Ativo de Jogo - Retrato de Desenho Animado 3D de Billie Eilish - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [ShaHid WaNii](https://x.com/meng_dagg695)
- **Fonte:** [Twitter Post](https://x.com/meng_dagg695/status/2022499940686270475)
- **Publicado:** 14 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=10075)**

---

### No. 120: Ativo de Jogo - Prompt para Cena de Arte Surreal em Miniatura de Ovo

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 Descrição

Um prompt JSON altamente detalhado para gerar uma cena em miniatura surreal e cinematográfica, apresentando um ovo gigante rachado em uma floresta nebulosa, com minúsculos trabalhadores humanos ativamente removendo e coletando a gema escorrendo, enfatizando texturas fotorrealistas e alto contraste.

#### 📝 Prompt

```
{
  "resolution": "8K",
  "aspect_ratio": "3:4",
  "style": "cena em miniatura cinematográfica de alto detalhe, realismo surreal editado por IA",
  "scene_overview": {
    "environment": "floresta nebulosa com árvores sem folhas",
    "ground": "superfície de terra irregular coberta com pequenas rochas e pedras",
    "atmosphere": "fundo nebuloso, suave, em tons frios com desfoque suave de profundidade de campo"
  },
  "main_subject": {
    "object": "ovo gigante rachado",
    "position": "centro do quadro",
    "scale": "enorme em comparação com as figuras humanas ao redor",
    "shell": {
      "color": "marrom claro",
      "texture": "áspera, rachada, aberta na parte superior frontal",
      "edges": "bordas irregulares da casca com espessura visível"
    },
    "interior": {
      "egg_white": "clara opaca, textura irregular, aderindo ao interior da casca",
      "yolk": {
        "color": "amarelo dourado vívido",
        "texture": "brilhante, suave, semilíquida",
        "state": "parcialmente intacta, mas fluindo ativamente para baixo"
      }
    },
    "motion": {
      "yolk_flow": "fluxo espesso de gema escorrendo da abertura do ovo para o chão",
      "pooling": "gema formando uma poça brilhante na base"
    }
  },
  "human_figures": {
    "count": 5,
    "scale": "miniatura em comparação com o ovo",
    "appearance": {
      "gender": "não identificável",
      "faces": "não claramente visíveis",
      "build": "média",
      "posture": "poses de trabalho ativas"
    },
    "clothing": {
      "helmets": "capacetes de segurança laranja e branco",
      "tops": "jaquetas de trabalho azuis e laranjas",
      "pants": "calças de trabalho escuras",
      "footwear": "botas de trabalho"
    },
    "tools": [
      "pá",
      "balde de metal",
      "carrinho de mão",
      "ferramenta de perfuração ou tipo martelete",
      "escada encostada no ovo"
    ],
    "actions": [
      "uma figura pá gema",
      "uma figura coletando gema com um balde",
      "uma figura operando uma ferramenta perto do ovo",
      "uma figura em uma escada inspecionando o ovo",
      "uma figura posicionada perto de um carrinho de mão"
    ]
  },
  "composition": {
    "camera_angle": "nível dos olhos com figuras em miniatura",
    "framing": "composição vertical com foco central no ovo",
    "depth_of_field": "rasa, árvores de fundo borradas",
    "foreground": "pedras, gema escorrendo, trabalhadores",
    "background": "floresta densa de árvores altas e nuas desaparecendo na névoa"
  },
  "lighting": {
    "type": "iluminação difusa suave",
    "direction": "iluminado uniformemente de cima e da frente",
    "highlights": "reflexos fortes na gema",
    "shadows": "sombras suaves sob as figuras e o ovo"
  },
  "color_palette": {
    "primary_colors": [
      "amarelo dourado",
      "marrom",
      "cinza",
      "verde suave"
    ],
    "contrast": "alto contraste entre a gema brilhante e os tons suaves da floresta"
  },
  "visual_quality": {
    "sharpness": "detalhe extremo na casca do ovo, textura da gema e trabalhadores",
    "realism": "texturas fotorrealistas com tema surreal",
    "no": null
  }
}
```

#### 🖼️ Imagens geradas

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050440833_gd3hbw_HBDBtp7aQAAP2Aj.jpg" width="600" alt="Ativo de Jogo - Prompt para Cena de Arte Surreal em Miniatura de Ovo - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050440871_wygb5h_HBDBtucawAAA7Nu.jpg" width="600" alt="Ativo de Jogo - Prompt para Cena de Arte Surreal em Miniatura de Ovo - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1771050441465_50xsmq_HBDBt4TbMAANWZU.jpg" width="600" alt="Ativo de Jogo - Prompt para Cena de Arte Surreal em Miniatura de Ovo - Image 3">
</div>

#### 📌 Detalhes

- **Autor:** [ShaHid WaNii](https://x.com/meng_dagg695)
- **Fonte:** [Twitter Post](https://x.com/meng_dagg695/status/2022329236233810298)
- **Publicado:** 13 de fevereiro de 2026
- **Idiomas:** en

**[👉 Experimente agora →](https://youmind.com/pt-BR/nano-banana-pro-prompts?id=9983)**

---

---

## 📚 Mais prompts disponíveis

<div align="center">

### 🎯 9314 mais prompts não mostrados aqui

Due to GitHub's content length limitations, we can only display the first 120 regular prompts in this README.

**[👉 Ver todos os prompts na nossa galeria web](https://youmind.com/pt-BR/nano-banana-pro-prompts)**

The gallery features:

✨ Layout de grade Masonry bonito

🔍 Busca de texto completo e filtros

🌍 Suporte para 17 idiomas

📱 Experiência otimizada para mobile

</div>

---

## 🤝 Como contribuir

Acolhemos contribuições! Você pode enviar prompts através de:

### 🐛 GitHub Issue

1. Click [**Enviar novo prompt**](https://github.com/YouMind-OpenLab/awesome-nano-banana-pro-prompts/issues/new?template=submit-prompt.yml)
2. Preencha o formulário com os detalhes do prompt e a imagem
3. Envie e aguarde a revisão da equipe
4. Se aprovado (adicionaremos o rótulo `approved`), será sincronizado automaticamente com o CMS
5. Seu prompt aparecerá no README em 4 horas

**Nota:** Aceitamos apenas envios via GitHub Issues para garantir o controle de qualidade.

Veja [CONTRIBUTING.md](docs/CONTRIBUTING.md) para diretrizes detalhadas.

---

## 📄 Licença

Licenciado sob [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

---

## 🙏 Agradecimentos

- [Payload CMS](https://payloadcms.com/)
- [youmind.com](https://youmind.com)

---

## ⭐ Histórico de estrelas

[![Star History Chart](https://api.star-history.com/svg?repos=YouMind-OpenLab/awesome-nano-banana-pro-prompts&type=Date)](https://star-history.com/#YouMind-OpenLab/awesome-nano-banana-pro-prompts&Date)

---

<div align="center">

**[🌐 Ver na galeria web](https://youmind.com/pt-BR/nano-banana-pro-prompts)** •
**[📝 Enviar um prompt](https://github.com/YouMind-OpenLab/awesome-nano-banana-pro-prompts/issues/new?template=submit-prompt.yml)** •
**[⭐ Dar estrela a este repositório](https://github.com/YouMind-OpenLab/awesome-nano-banana-pro-prompts)**

<sub>🤖 Este README é gerado automaticamente. Última atualização: 2026-02-18T05:19:07.726Z</sub>

</div>
